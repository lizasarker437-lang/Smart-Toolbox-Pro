# Smart Toolbox Pro — Floating Controls Update 1.2.5-alpha8

## Four feature cards in the floating panel
All feature controls are now grouped inside their corresponding card. No independent settings are listed underneath the four cards.

1. **Night Screen card:** ON/OFF, darkness slider (0–95%), system display brightness slider (0–255), and the WRITE_SETTINGS permission action.
2. **Thermal Monitor card:** ON/OFF and live battery temperature / Android thermal status.
3. **Master Volume card:** ON/OFF and master gain slider (0 to +10 dB).
4. **Document Scanner card:** open/close action.

Removed from the bottom of the panel:
- Floating Icon Settings
- Hide Floating Icon
- Close Panel

A compact × control in the top header closes the panel.

## Floating Icon Settings
- Auto-hide delay: 1–60 seconds.
- Floating bubble size: 24–76 dp.
- Collapsed side-tab thickness: 6–26 dp.
- Opacity: 30–100%.
- Independent sidebar ON/OFF, quick-panel toggle and saved position.

## Technical notes
- System display brightness uses `Settings.System.SCREEN_BRIGHTNESS` and `SCREEN_BRIGHTNESS_MODE_MANUAL`. Android's `WRITE_SETTINGS` special access must be granted by the user. After granting access, the app applies the saved slider level.
- Thermal readout uses Android battery temperature (`BatteryManager.EXTRA_TEMPERATURE`) and Android thermal status where available. CPU/GPU temperature is not claimed.
- Master Volume ON/OFF is independent from the Equalizer/Bass Boost/Virtualizer service state. Turning Master OFF releases only the master `LoudnessEnhancer`; supported EQ effects can remain active.
- Global audio effects remain subject to Android and phone-manufacturer restrictions.

## Build status
Static validation is performed on Java source files, XML, manifest, workflow YAML, feature wiring and source component mappings. Android SDK/Gradle are not installed in this workspace; GitHub Actions must complete `:app:assembleDebug` for final compile verification.
