# Smart Toolbox Pro — Floating Controls Update 1.2.6-alpha9

## Integrated controls in the marked rows
1. **Night Screen:** ON/OFF switch, darkness slider (0–95%) and system display-brightness slider (0–255) in one feature card.
2. **Thermal Monitor:** ON/OFF switch and live battery temperature / Android thermal status in one feature card.
3. **Master Volume Boost:** ON/OFF switch and master gain slider (0 to +10 dB) in one feature card.
4. **Document Scanner:** open/close action.

The feature sliders are inline in the same card as their ON/OFF switch. They are not separate nested cards. The former bottom actions remain removed. The panel has a compact × close control in its top header.

## Automatic close behavior
- Reuses the Auto-hide delay from Floating Icon Settings (1–60 seconds).
- Timer begins when the panel opens.
- Timer restarts after a feature action, panel touch/scroll, and slider release.
- Timer pauses while the user is actively dragging a slider.
- On expiry, the quick panel always closes; if Auto-hide is enabled, the floating bubble also collapses to the edge handle.
- No separate Cancel button is required.
- If the user disables Auto-hide in Floating Icon Settings, the panel still closes after the timer; only the bubble's edge collapse is disabled.

## Floating Icon Settings
- Auto-hide delay: 1–60 seconds.
- Floating bubble size: 24–76 dp.
- Collapsed side-tab thickness: 6–26 dp.
- Opacity: 30–100%.
- Independent sidebar ON/OFF, quick-panel toggle and saved position.

## Technical notes
- System display brightness uses `Settings.System.SCREEN_BRIGHTNESS` and `SCREEN_BRIGHTNESS_MODE_MANUAL`. Android's `WRITE_SETTINGS` special access must be granted by the user.
- Thermal readout uses Android battery temperature (`BatteryManager.EXTRA_TEMPERATURE`) and Android thermal status where available. CPU/GPU temperature is not claimed.
- Master Volume ON/OFF is independent from Equalizer/Bass Boost/Virtualizer effects. Turning Master OFF releases only the master `LoudnessEnhancer`; supported EQ effects can remain active.
- Global audio effects remain subject to Android and phone-manufacturer restrictions.

## Build status
Static validation is performed on Java source files, XML, manifest, workflow YAML, feature wiring and source component mappings. Android SDK/Gradle are not installed in this workspace; GitHub Actions must complete `:app:assembleDebug` for final compile verification.
