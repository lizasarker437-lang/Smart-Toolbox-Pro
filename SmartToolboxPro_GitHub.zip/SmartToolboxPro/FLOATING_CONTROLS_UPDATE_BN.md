# Smart Toolbox Pro — Floating Controls Update 1.2.4-alpha7

## Floating panel controls
1. Night Screen ON/OFF.
2. Night Screen darkness slider (0–95% black overlay).
3. Display brightness slider (0–255 / 0–100%). Requires Android Modify system settings permission.
4. Master Volume Boost ON/OFF.
5. Master Volume level slider (0 to +10 dB). Does not change Android's media-volume slider.
6. Thermal Monitor ON/OFF.
7. Live battery temperature and Android thermal status directly in the panel while monitoring is ON.
8. Existing Document Scanner quick action.

## Floating Icon Settings
- Auto-hide delay: 1–60 seconds.
- Floating bubble size: 24–76 dp.
- Collapsed side-tab thickness: 6–26 dp.
- Opacity: 30–100%.
- Independent sidebar ON/OFF, quick-panel toggle and saved position.

## Technical notes
- System display brightness uses `Settings.System.SCREEN_BRIGHTNESS` and `SCREEN_BRIGHTNESS_MODE_MANUAL`. Android's `WRITE_SETTINGS` special access must be granted by the user. After granting access, the app applies the saved slider level.
- Thermal readout uses Android battery temperature (`BatteryManager.EXTRA_TEMPERATURE`) and Android thermal status where available. CPU/GPU temperature is not claimed.
- Master Volume ON/OFF is independent from the Equalizer/Bass Boost/Virtualizer service state. Turning Master OFF releases only the master `LoudnessEnhancer`; supported EQ effects can remain active.
- Global audio effects remain subject to Android and phone-manufacturer restrictions.

## Build status
Static validation performed on all Java source files, XML, manifest, workflow YAML, feature wiring and source component mappings. Android SDK/Gradle are not installed in this workspace; GitHub Actions must complete `:app:assembleDebug` for final compile verification.
