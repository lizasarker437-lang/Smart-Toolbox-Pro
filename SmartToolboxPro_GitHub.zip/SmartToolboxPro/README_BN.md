# Smart Toolbox Pro — Version 1.2.9-alpha12

## নতুন Floating Quick Controls
- স্ক্রিনের বাম বা ডান পাশের চিকন ট্যাব থেকে **ভেতরের দিকে Swipe** করলে সরাসরি Quick Control Panel খুলবে।
- ট্যাপে Quick Panel খোলার ব্যবস্থাও থাকবে।
- প্যানেল খোলার পর ৩ সেকেন্ড ব্যবহার না করলে সেটি স্বয়ংক্রিয়ভাবে বন্ধ হবে।
- এর আগেই প্যানেলের বাইরের স্ক্রিনে ট্যাপ করলে Android-এর outside-touch event পাওয়া সাপেক্ষে সঙ্গে সঙ্গে বন্ধ হবে। অন্য অ্যাপের ট্যাপ দখল করবে না।
- অটো-হাইড ON থাকলে প্যানেল বন্ধ হওয়ার সঙ্গে সঙ্গে আইকনটি আগের পাশের চিকন ট্যাবে ফিরে যাবে। OFF থাকলে প্যানেল বন্ধ হলেও আইকন দেখা যাবে।
- আইকন হাইড হওয়ার সময় আগের মতো **১–৬০ সেকেন্ড** আলাদাভাবে পরিবর্তন করা যাবে। প্যানেলের সময় নির্দিষ্ট ৩ সেকেন্ড।
- Android-এর সিস্টেম Navigation Gesture স্ক্রিনের খুব কাছে থাকলে কিছু ফোনে অগ্রাধিকার পেতে পারে।

## Notification Controls — নতুন সেকশন
- অ্যাপের হোম পেজে **Notification Controls** কার্ড আছে।
- অ্যাপের নোটিফিকেশন অনুমতির অবস্থা দেখা যাবে। Android 13+ এ প্রয়োজন হলে অনুমতি চাওয়া যাবে।
- অ্যাপের সম্পূর্ণ Notification Settings খোলার বাটন থাকবে।
- অন্যান্য অ্যাপের নোটিফিকেশন নিয়ন্ত্রণের জন্য Android-এর **All apps notification settings** খোলা যাবে (Android 13+); অনুমতি ছাড়াই অন্য অ্যাপের নোটিফিকেশন পড়া হবে না।
- Floating Icon, Night Screen, Thermal Monitor, Extra Volume & Equalizer—এই চারটি নোটিফিকেশন চ্যানেল আলাদা করে নিয়ন্ত্রণের জন্য সরাসরি Android Settings-এ যাওয়ার বাটন থাকবে।
- Background foreground service-এর ongoing status Android-এর নিয়ম অনুযায়ী দেখাতে হতে পারে; শুধু চ্যানেল নোটিফিকেশন বন্ধ করলেই ফিচার বন্ধ হবে না। অন্য অ্যাপের নোটিফিকেশন এই অ্যাপ পড়বে না।

## আগের ফিচারগুলি অপরিবর্তিত
- Night Screen: ০–৯৫% Darkness / warm filter। ফোনের মূল Brightness Slider ফ্লোটিং প্যানেলে নেই।
- Master Extra Volume ও Equalizer: ৫-band Equalizer, Bass, Virtualizer, প্রিসেট। সাপোর্ট ফোনভেদে আলাদা।
- ফোনের নিজস্ব Media Volume-এর Plus/Minus ফ্লোটিং প্যানেলে।
- Temperature Monitor: ব্যাটারি তাপমাত্রা / Android Thermal Status।
- Document Scanner: Camera/Gallery, PDF ও OCR।
- Floating Icon Settings: আইকন ON/OFF, সাইজ, স্বচ্ছতা, সাইডবার পুরুত্ব, আইকন অটো-হাইডের সময়।

## GitHub Build
- Android Gradle Plugin 8.7.3 / Gradle 8.9 / JDK 17 / compileSdk 35।
- Repository-র `build-apk.yml` workflow দিয়ে `:app:assembleDebug` চালাবে।
- Build সফল হলে `SmartToolboxPro-debug-apk` artifact-এ APK পাওয়া যাবে।
- Build ব্যর্থ হলে নতুন workflow `SmartToolboxPro-build-errors` নামে লগ সংরক্ষণ করবে।

## যাচাইয়ের সীমা
এখানে Android SDK ও Gradle নেই; পূর্ণ APK Build হয়নি। Java source, XML, manifest, workflow এবং আলাদা EdgeSwipeLogic টেস্ট যাচাই করা হয়েছে। প্রকৃত APK কম্পাইল এবং ফোনে outside-touch আচরণ GitHub ও ফোনে পরীক্ষা করতে হবে।
