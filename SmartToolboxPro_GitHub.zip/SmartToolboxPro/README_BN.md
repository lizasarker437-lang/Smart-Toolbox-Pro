# SR Smart Toolbox Pro — Version 1.4.5-alpha20

**Created by Shahriar Rahman**  
**YouTube:** https://www.youtube.com/@SRCreation-farm  
**Facebook:** https://fb.com/srcreation.farm

## App identity
- App name: **SR Smart Toolbox Pro**
- Application ID: `com.smarttoolbox.pro` (unchanged for update compatibility)
- Developer / brand owner: Shahriar Rahman
- Version: `1.4.5-alpha20` (`versionCode 20`)

## Features
- Night Screen with extra darkness and warm filter.
- System-wide Extra Volume, five-band equalizer, Bass Boost and Virtualizer where supported.
- Native media volume +/- controls in the floating panel.
- Thermal Monitor.
- QR / Barcode Scanner with copy, share and safe web-link opening.
- Floating edge sidebar and 3-second Quick Panel auto-close.
- Android Notification Controls (now accessed through the top-right three-dot menu).
- SR Video Library: phone video list, search by video/folder name, folder filter, sort by newest/name/duration and per-video resume status (requires user-granted video permission).
- SR Video Player (new): local multi-select playlist, secure HTTPS / RTSP streams, HLS, DASH and SmoothStreaming modules, playback speed, repeat, shuffle, seek gestures, external subtitles, audio/subtitle track selection, aspect ratio, full-screen landscape mode, brightness and media-volume sliders, PiP, background audio playback notification (video remains visible in PiP), service-based sleep timer, favorites, history and resume point.
- Player UI: supplied MX Player reference-inspired full-screen black layout, transparent top/bottom controls, auto-hide, custom seek bar, previous/play-pause/next, tap-to-show, double-tap seek, swipe brightness/volume/seek, screenshot, audio-only, lock, aspect ratio and PiP.

## Video format support — important
The player uses AndroidX Media3 ExoPlayer 1.11.1. Media3 extractors cover containers including MP4, WebM, Matroska/MKV, AVI, MPEG-TS, MPEG-PS, FLV, Ogg, WAV and FLAC, plus HLS/DASH/SmoothStreaming with their matching modules. Actual playback still depends on the audio/video codecs and profiles supported by the Android device; a recognized container does not guarantee every codec inside it. A clear playback error is shown when the file, codec, network, or device decoder is unsupported.

External subtitles: SRT, WebVTT, SSA/ASS and TTML.

Network URLs: HTTPS and RTSP are accepted. Cleartext HTTP URLs are intentionally rejected for safer network handling.

## Video Player architecture
- `VideoPlayerActivity` provides the SR-styled player interface.
- `VideoPlaybackService` hosts ExoPlayer + MediaSessionService so audio/media playback can continue outside the Activity.
- `MediaController` connects the UI to the service and is released with the Activity lifecycle.
- The Video Library queries Android MediaStore after the user grants video access; Android 14+ also supports selecting a limited set of videos. Separately, the system file picker can open video/subtitle documents without broad storage permission.
- Picture-in-Picture is declared as optional and only starts on supported Android devices.

## Build toolchain
- JDK 17
- Android Gradle Plugin 8.10.0
- Gradle 8.11.1
- compileSdk 36, targetSdk 35, minSdk 26
- Android SDK platform 36 and build-tools 35.0.0
- AndroidX Media3 1.11.1 (stable)

## GitHub Actions build
The repository workflow accepts the root source ZIP (`SmartToolboxPro_GitHub.zip`) and extracts the Android project before building. It runs pure-Java tests and source checks, then executes `:app:assembleDebug`. On success, download the `SR-Smart-Toolbox-Pro-debug-apk` artifact from Actions.

## Verification limits
ZIP integrity, source wiring, XML, workflow syntax, and pure-Java helper tests were checked in this workspace. This workspace does not have Android SDK / Gradle installed, so a full APK compile, install, real video playback, codec compatibility, PiP, and background playback still need to be verified by GitHub Actions and on a physical Android device.

## প্রতিটি ভিডিওর Resume Playback
- MediaStore থেকে ফোনে ইনডেক্স করা ভিডিওগুলো অ্যাপের লাইব্রেরিতে দেখা যাবে; অনুমতির ওপর নির্ভর করে সবগুলো অথবা শুধু নির্বাচিত ভিডিও দেখা যাবে।
- ভিডিওর নাম, ফোল্ডার ও দৈর্ঘ্য দেখাবে; সার্চ, ফোল্ডার ফিল্টার এবং Sort থাকবে।
- প্রতিটি ভিডিও আলাদাভাবে শেষ দেখা অবস্থান মনে রাখবে। ভিডিওতে ট্যাপ করলে মাঝপথে থাকলে আগের অবস্থান থেকে চালু হবে।
- কোনো ভিডিওতে Long Press করলে Start from beginning নির্বাচন করা যাবে।
- ভিডিও প্রায় শেষ হয়ে গেলে পরেরবার শুরু থেকে চলবে।
- ভিডিও বন্ধ করে বের হওয়ার সময় অবস্থান সংরক্ষণ হয়; প্লে চলার সময় নিয়মিত সংরক্ষণ হয়।
- Android 13+ এ READ_MEDIA_VIDEO অনুমতি, Android 14+ এ Selected Video Access অথবা All Video Access, পুরোনো Android এ READ_EXTERNAL_STORAGE প্রয়োজন।
- কোনো ভিডিও MediaStore-এ ইনডেক্স না হলে, সিস্টেম File Picker দিয়ে খোলা যাবে।

## Home Screen / ⋮ Smart Menu
The home page now focuses on Night Screen, System-Wide Extra Volume, Thermal Monitor, QR / Barcode Scanner and SR Video Player. Tap **⋮** at the top-right for **Floating Icon Settings**, **Notification Controls**, **Android App Settings** and **About Shahriar Rahman**. The previous standalone settings/notification/About home cards have been removed without deleting their underlying screens. The app ID remains `com.smarttoolbox.pro` so update compatibility is preserved, subject to signing.

## New in 1.4.5-alpha20: Smart folder browser & Theme Settings
- Video Player now opens in Folders view with folder cards, counts, search, folder list/grid toggle and filtered videos.
- All Videos and Continue Watching shortcuts; persistent per-video resume positions unchanged.
- Theme Settings in home ⋮ menu offers Midnight Gold, Ocean Blue, Emerald Green, Royal Purple and Light Day.
- Theme choice is saved across app restarts; immersive video background remains black by design.

## 1.4.5-alpha20 — Video Library Compile Fix + Animated Floating Icon
- Fixed missing `status` and `adapter` fields in `VideoLibraryActivity` that caused repeated `cannot find symbol` errors.
- Added native swipe-reveal slide/fade/scale animation for the floating icon from either edge (270ms) and a quick panel slide/fade (200ms).
- Retained the 3-second quick-panel timeout and independent floating icon auto-hide preferences.
- Added source-AST regression tests to GitHub Actions before compiling APK.
- See `VIDEO_LIBRARY_ANIMATION_FIX_BN.md`.
