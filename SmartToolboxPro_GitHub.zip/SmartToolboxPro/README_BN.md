# Smart Toolbox Pro — Version 1.2.8-alpha11

## Floating Sidebar — নতুন Swipe ব্যবস্থা
- Floating bubble স্ক্রিনের ডান বা বাম পাশে অটোমেটিক লুকিয়ে গিয়ে ছোট একটি Edge Tab দেখাবে।
- বাম Edge Tab থেকে **ডান দিকে সোয়াইপ** করলে Bubble বের হবে।
- ডান Edge Tab থেকে **বাঁ দিকে সোয়াইপ** করলে Bubble বের হবে।
- Edge Tab-এ **ট্যাপ** করলে Bubble এবং Quick Control Panel খুলবে।
- Swipe করে Bubble বের করে সেটিতে ট্যাপ করলেও Quick Panel খুলবে।
- ব্যবহার শেষে Floating Icon Settings-এ নির্ধারিত ১–৬০ সেকেন্ড পরে Panel অটো-ক্লোজ হবে। Auto-hide চালু থাকলে Bubble আবার **আগের পাশেই** Edge Tab হিসেবে চলে যাবে।
- Edge Tab-এর দৃশ্যমান পুরুত্ব ৬–২৬ dp রাখা যায়। খুব চিকন Tab হলেও Swipe ধরার জন্য প্রায় ৩২ dp Touch Area থাকবে। কিছু ফোনে Android-এর Back Gesture / System Gesture-এর সঙ্গে সংঘাত হতে পারে।
- Floating Icon-এর সাইজ ২৪–৭৬ dp, Opacity ৩০–১০০% এবং Sidebar ON/OFF অ্যাপ থেকে নিয়ন্ত্রণ করা যাবে।

## Floating Quick Panel — চারটি প্রধান ফিচার
1. **Night Screen:** ON/OFF এবং Extra Darkness ০–৯৫%। **ফোনের নিজস্ব Brightness Slider এবং Modify System Settings Permission সরিয়ে দেওয়া হয়েছে**।
2. **Thermal Monitor:** ON/OFF এবং Android থেকে পাওয়া লাইভ ব্যাটারি তাপমাত্রা ও Thermal Status।
3. **Master Volume Boost:** ON/OFF এবং আগের Extra Gain ০–১০ dB। একই কার্ডে ফোনের **Media Volume `−` ও `+` বাটন** আছে—এগুলো আলাদাভাবে Android-এর নিজস্ব Media Volume এক ধাপ কমায়/বাড়ায়।
4. **Document Scanner:** Scanner Open / Close।

## Extra Volume & Equalizer
- Master Boost এবং ফোনের Media Volume **দুটি পৃথক নিয়ন্ত্রণ**।
- Master Boost/Equalizer/Bass Boost/Virtualizer-এর System-wide প্রভাব Android ও ফোন প্রস্তুতকারকের অনুমতি/সাপোর্টের ওপর নির্ভর করে।
- `+` ও `−` বাটন `AudioManager.adjustStreamVolume(STREAM_MUSIC, ...)` ব্যবহার করে; Ringtone বা Call Volume পরিবর্তন করে না।
- যেসব ফোনে Media Volume Fixed, সেখানে বাটন কাজ নাও করতে পারে।
- অত্যধিক Gain ব্যবহার করলে শব্দ বিকৃত হতে পারে এবং শ্রবণক্ষতি হতে পারে।

## Android Permission
- `SYSTEM_ALERT_WINDOW`: Night Screen Overlay এবং Floating Sidebar।
- `MODIFY_AUDIO_SETTINGS`: Audio controls।
- `FOREGROUND_SERVICE_SPECIAL_USE`: User-started foreground services।
- **`WRITE_SETTINGS` আর প্রয়োজন নেই।**

## GitHub-এ APK Build
আগের Repository-এর root-এ থাকা workflow যদি ZIP Extract করে Build চালায়, তাহলে এই ফাইলটি `SmartToolboxPro_GitHub.zip` নামে পুরোনোটির পরিবর্তে আপলোড করুন।
GitHub Actions-এর কাজ সফল হলে Artifacts থেকে APK পাবেন।

## Testing অবস্থা
ZIP, XML, Java syntax-structure, source references এবং Workflow-এর লোকাল যাচাই করা হয়েছে। এই পরিবেশে Android SDK ও Gradle অনুপস্থিত থাকায় **সম্পূর্ণ APK Build পরীক্ষা করা যায়নি**। GitHub Actions-এর পরবর্তী রানই প্রকৃত Compile Test।
