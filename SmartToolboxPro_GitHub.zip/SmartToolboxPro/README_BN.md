# SR Smart Toolbox Pro — Version 1.4.1-alpha16

**Created by Shahriar Rahman**  
**YouTube:** https://www.youtube.com/@SRCreation-farm  
**Facebook:** https://fb.com/srcreation.farm

## App identity
- App name: **SR Smart Toolbox Pro**
- Application ID: `com.smarttoolbox.pro` (unchanged for update compatibility)
- Developer / brand owner: Shahriar Rahman
- Version: `1.4.1-alpha16` (`versionCode 16`)

## Features
- Night Screen with extra darkness and warm filter.
- System-wide Extra Volume, five-band equalizer, Bass Boost and Virtualizer where supported.
- Native media volume +/- controls in the floating panel.
- Thermal Monitor.
- QR / Barcode Scanner with copy, share and safe web-link opening.
- Floating edge sidebar and 3-second Quick Panel auto-close.
- Android Notification Controls.
- SR Video Player (new): local multi-select playlist, secure HTTPS / RTSP streams, HLS, DASH and SmoothStreaming modules, playback speed, repeat, shuffle, seek gestures, external subtitles, audio/subtitle track selection, aspect ratio, full-screen landscape mode, brightness and media-volume sliders, PiP, background audio playback notification (video remains visible in PiP), service-based sleep timer, favorites, history and resume point.\n- Player UI: supplied MX Player reference-inspired full-screen black layout, transparent top/bottom controls, auto-hide, custom seek bar, previous/play-pause/next, tap-to-show, double-tap seek, swipe brightness/volume/seek, screenshot, audio-only, lock, aspect ratio and PiP.

## Video format support — important
The player uses AndroidX Media3 ExoPlayer 1.11.1. Media3 extractors cover containers including MP4, WebM, Matroska/MKV, AVI, MPEG-TS, MPEG-PS, FLV, Ogg, WAV and FLAC, plus HLS/DASH/SmoothStreaming with their matching modules. Actual playback still depends on the audio/video codecs and profiles supported by the Android device; a recognized container does not guarantee every codec inside it. A clear playback error is shown when the file, codec, network, or device decoder is unsupported.

External subtitles: SRT, WebVTT, SSA/ASS and TTML.

Network URLs: HTTPS and RTSP are accepted. Cleartext HTTP URLs are intentionally rejected for safer network handling.

## Video Player architecture
- `VideoPlayerActivity` provides the SR-styled player interface.
- `VideoPlaybackService` hosts ExoPlayer + MediaSessionService so audio/media playback can continue outside the Activity.
- `MediaController` connects the UI to the service and is released with the Activity lifecycle.
- Android's Storage Access Framework opens video/subtitle documents; no broad storage permission is requested.
- Picture-in-Picture is declared as optional and only starts on supported Android devices.

## Build toolchain
- JDK 17
- Android Gradle Plugin 8.10.0
- Gradle 8.11.1
- compileSdk 36, targetSdk 35, minSdk 26
- Android SDK platform 36 and build-tools 35.0.0
- AndroidX Media3 1.11.1 (stable)

## GitHub Actions build
The repository workflow accepts the root source ZIP (`SmartToolboxPro_GitHub.zip`) and extracts the Android project before building. It runs pure-Java tests and source checks, then executes `:app:assembleDebug`. On success, download the `SR-Smart-Toolbox-Pro-debug-apk` artifact from Actions.

## Verification limits
ZIP integrity, source wiring, XML, workflow syntax, and pure-Java helper tests were checked in this workspace. This workspace does not have Android SDK / Gradle installed, so a full APK compile, install, real video playback, codec compatibility, PiP, and background playback still need to be verified by GitHub Actions and on a physical Android device.
