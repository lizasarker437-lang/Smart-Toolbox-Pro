# Smart Toolbox Pro — Android Studio Project

এটি চারটি টুলকে একটি Android অ্যাপে একত্র করার প্রথম Alpha সংস্করণ।

## অন্তর্ভুক্ত ফিচার

### 1) Night Screen
- অন্য অ্যাপের ওপর dim overlay চালু/বন্ধ
- 0–80% dim level slider
- Warm / blue-light style overlay
- Android Quick Settings-এর Night Screen tile
- Overlay permission নিজে থেকে Settings থেকে অনুমোদন করতে হবে

### 2) Volume Controls
- Media, ringtone ও notification volume slider
- Media volume-এর 40%, 60%, 80% ও Max preset
- Android-এর নির্ধারিত সর্বোচ্চ ভলিউম অতিক্রম করে স্পিকারকে জোর করে boost করে না

### 3) Thermal Monitor
- Battery temperature (যদি ডিভাইস রিপোর্ট করে)
- Android 10+ thermal status listener
- Normal, Light, Moderate, Severe, Critical, Emergency status
- CPU/GPU-এর সরাসরি তাপমাত্রা সব ফোনে Android প্রকাশ করে না; অনুপলব্ধ reading দেখানো হয় না

### 4) Document Scanner
- ফোনের Camera app দিয়ে ছবি তোলা
- Gallery থেকে একাধিক ছবি বাছাই
- একাধিক ছবিকে PDF-এ রূপান্তর
- প্রথম পৃষ্ঠার OCR text extraction ও copy
- Android 10+ এ PDF `Downloads/SmartToolboxPro` ফোল্ডারে সেভ হয়

## এখনো পরের সংস্করণে যোগ করতে হবে

- Camera preview-এর মধ্যে automatic document-edge detection ও auto crop
- Manual crop / perspective correction / scan filters
- Night Screen-এর schedule-based auto start/stop
- Advanced equalizer / bass processing (এগুলো global Android audio-তে সব ডিভাইসে সম্ভব নয়)
- আরও উন্নত thermal history chart ও floating status widget

## Build করার নিয়ম

1. কম্পিউটারে Android Studio (JDK 17 সহ) ইনস্টল করুন।
2. Android Studio থেকে **Open** নির্বাচন করে `SmartToolboxPro` ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হতে দিন। প্রথমবার Android Gradle Plugin, Android SDK 35 এবং ML Kit dependency ডাউনলোড হতে পারে।
4. Android SDK Platform 35 ইনস্টল না থাকলে SDK Manager থেকে ইনস্টল করুন।
5. ফোনে Developer options → USB debugging চালু করে USB দিয়ে যুক্ত করুন, অথবা Build → Build Bundle(s) / APK(s) → Build APK(s) নির্বাচন করুন।
6. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ পাওয়া যাবে।

## গুরুত্বপূর্ণ অনুমতি

- Night Screen: Android Settings-এ **Display over other apps** অনুমতি দিতে হবে।
- Scanner: Camera capture আলাদা Camera app দিয়ে হয়; Gallery import-এর জন্য Android document picker ব্যবহার করা হয়।
- Notification: Android 13+ এ notification permission না দিলে foreground service notification সীমিত হতে পারে।

## Build status

এই পরিবেশে Android SDK/Gradle build tool ইনস্টল করা নেই, তাই এখানে APK compile করা যায়নি। এটি Android Studio-তে খোলার উপযোগী source project; APK তৈরি করতে উপরের build ধাপ অনুসরণ করতে হবে।
