# SR Smart Toolbox Pro — Version 1.4.9-alpha24

**Created by Shahriar Rahman**  
**YouTube:** https://www.youtube.com/@SRCreation-farm  
**Facebook:** https://fb.com/srcreation.farm

## New v1.4.9-alpha24 — Compact Floating Quick Toolbox
- **পুরো রঙিন বারটাই ON/OFF:** Night Screen, Thermal Monitor ও Volume Boost-এর আলাদা ON/OFF Button সরানো হয়েছে। ধূসর = OFF, সবুজ = ON। বারটি ট্যাপ করলেই টগল হবে।
- **একই বারে Drag:** Night Screen-এর Darkness (০–৯৫%) এবং Volume Boost-এর Extra Gain (+0.0–10.0 dB) অনুভূমিকভাবে আঙুল টেনে পরিবর্তন করা যায়। আর নিচে আলাদা Darkness/Boost Slider নেই। Drag করতে করতে ভুল করে ফিচার ON/OFF হবে না। বন্ধ অবস্থায়ও লেভেল সেট করে পরে Tap করে চালু করা যায়।
- Thermal Monitor-এর লাইভ ব্যাটারি তাপমাত্রা একই বারে দেখানো হয় (আলাদা নিচের Description নেই)।
- ফোনের নিজস্ব Media Volume-এর `−` ও `+` ছোট কমপ্যাক্ট সারিতে রাখা হয়েছে, Extra Gain-এর থেকে আলাদা।
- QR/Barcode Scanner ও Video Player-কে সরু Action Row করা হয়েছে।
- 220–440 dp Width এবং 240–760 dp Height Settings আগের মতো আছে। প্যানেলের বাইরে কোনো কন্ট্রোল দেখাবে না: Rounded Outline Clipping, `ScrollView` এবং Screen Height Clamp দেওয়া হয়েছে। খুব ছোট করলে একই প্যানেলের ভেতর **উল্লম্বভাবে স্ক্রল** করে বাকি কন্ট্রোল পাওয়া যাবে; অপাঠ্য করে সব একসঙ্গে গুঁজে রাখা হয়নি।
- Edge Swipe Animation, 3-second Panel Auto Close, Tap Outside Close এবং Auto-hide আগের মতো আছে।

## Previous feature — Immersive Notification Bar and Background Audio on Demand
- ভিডিও খুলে Play করলে Android Immersive Mode চালু হয়ে Status/Notification Bar (এবং Navigation Bar) লুকায়। স্ক্রিনের উপর থেকে Swipe করলে System Bar অল্প সময়ের জন্য ফিরে আসে, পরে Android নিজে থেকে আবার লুকায়।
- AndroidX WindowInsetsControllerCompat দিয়ে `BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE` ব্যবহার করা হয়েছে; অন্য অ্যাপের Notification বন্ধ করা হয় না।
- Player-এর সাধারণ **Back** (স্ক্রিনের Back, Android Back Gesture) চাপলে Playback ও Audio দুটোই Stop হয় এবং Resume Position সংরক্ষিত থাকে।
- Player-এর **🎵 Background Audio** বাটনে চাপ দিলে ভিডিওর Player Activity বন্ধ হয়, কিন্তু Audio MediaSessionService-এ চলতে থাকে। আগে Pause থাকলে বাটন চাপলে Audio Play শুরু হয়।
- 🎵 বাটনের পর Media3-এর Media Notification থেকে Pause/Resume করা যাবে (নোটিফিকেশন Android অনুমতি/নিয়ম সাপেক্ষ)। পরে অ্যাপের Player-এ ফিরলে Stop করা যাবে।
- আগের **Audio-only display** (Player-এর ভেতরে ভিডিও লুকিয়ে অডিও চালানো) ফিচার Overflow Menu-তে রাখা হয়েছে।
- আগের PiP, Video Library, Folder, Theme, Resume, Floating Icon ও Toolbox sizing অপরিবর্তিত।

## Previous feature — Resizable Floating Toolbox Panel
- Home screen-এর **⋮ → Floating Icon Settings → Toolbox panel size** সেকশন থেকে Quick Control Panel-এর প্রস্থ ও সর্বোচ্চ উচ্চতা পরিবর্তন করা যায়।
- **Toolbox width:** 220–440 dp (default 292 dp)।
- **Maximum toolbox height:** 240–760 dp (default 580 dp)।
- Width/Height Slider ছেড়ে দিলে সেটিংস সংরক্ষিত হয় এবং Floating Control Service refresh হয়; পরেরবার প্যানেল খোলার সময় নতুন আকার দেখা যায়।
- Panel স্ক্রিনের বাইরে যাবে না; ছোট স্ক্রিনে নিজে থেকে ফিট হয়। প্রয়োজন হলে প্যানেলের ভেতর স্ক্রল করা যায়।
- **Reset toolbox size** বাটনে ডিফল্ট 292 × 580 dp-এ ফেরানো যায়।
- Floating **icon size** (24–76 dp) এবং Toolbox **panel size** আলাদাভাবে নিয়ন্ত্রিত হয়।
- আগের Auto-hide, 3-second panel close, swipe animation এবং সব টুল অপরিবর্তিত।

## New v1.4.6-alpha21 — Video Thumbnail List + Continue Last Video
- Folder video list now includes actual thumbnails, black duration overlays, titles and a three-dot options menu (Continue / Restart / Details).
- A floating Play (▶) button at the bottom right reopens the last watched video from its saved position, without a file picker.
- Thumbnail loading is asynchronous with bounded memory and recycled-image safety.
- Each video's independent resume position remains stored on-device.

## App identity
- App name: **SR Smart Toolbox Pro**
- Application ID: `com.smarttoolbox.pro` (unchanged for update compatibility)
- Developer / brand owner: Shahriar Rahman
- Version: `1.4.9-alpha24` (`versionCode 23`)

## Features
- Night Screen with extra darkness and warm filter.
- System-wide Extra Volume, five-band equalizer, Bass Boost and Virtualizer where supported.
- Native media volume +/- controls in the floating panel.
- Thermal Monitor.
- QR / Barcode Scanner with copy, share and safe web-link opening.
- Floating edge sidebar and 3-second Quick Panel auto-close.
- Android Notification Controls (now accessed through the top-right three-dot menu).
- SR Video Library: phone video list, search by video/folder name, folder filter, sort by newest/name/duration and per-video resume status (requires user-granted video permission).
- SR Video Player (new): local multi-select playlist, secure HTTPS / RTSP streams, HLS, DASH and SmoothStreaming modules, playback speed, repeat, shuffle, seek gestures, external subtitles, audio/subtitle track selection, aspect ratio, full-screen landscape mode, brightness and media-volume sliders, PiP, background audio playback notification (video remains visible in PiP), service-based sleep timer, favorites, history and resume point.
- Player UI: supplied MX Player reference-inspired full-screen black layout, transparent top/bottom controls, auto-hide, custom seek bar, previous/play-pause/next, tap-to-show, double-tap seek, swipe brightness/volume/seek, screenshot, audio-only, lock, aspect ratio and PiP.

## Video format support — important
The player uses AndroidX Media3 ExoPlayer 1.11.1. Media3 extractors cover containers including MP4, WebM, Matroska/MKV, AVI, MPEG-TS, MPEG-PS, FLV, Ogg, WAV and FLAC, plus HLS/DASH/SmoothStreaming with their matching modules. Actual playback still depends on the audio/video codecs and profiles supported by the Android device; a recognized container does not guarantee every codec inside it. A clear playback error is shown when the file, codec, network, or device decoder is unsupported.

External subtitles: SRT, WebVTT, SSA/ASS and TTML.

Network URLs: HTTPS and RTSP are accepted. Cleartext HTTP URLs are intentionally rejected for safer network handling.

## Video Player architecture
- `VideoPlayerActivity` provides the SR-styled player interface.
- `VideoPlaybackService` hosts ExoPlayer + MediaSessionService so audio/media playback can continue outside the Activity.
- `MediaController` connects the UI to the service and is released with the Activity lifecycle.
- The Video Library queries Android MediaStore after the user grants video access; Android 14+ also supports selecting a limited set of videos. Separately, the system file picker can open video/subtitle documents without broad storage permission.
- Picture-in-Picture is declared as optional and only starts on supported Android devices.

## Build toolchain
- JDK 17
- Android Gradle Plugin 8.10.0
- Gradle 8.11.1
- compileSdk 36, targetSdk 35, minSdk 26
- Android SDK platform 36 and build-tools 35.0.0
- AndroidX Media3 1.11.1 (stable)

## GitHub Actions build
The repository workflow accepts the root source ZIP (`SmartToolboxPro_GitHub.zip`) and extracts the Android project before building. It runs pure-Java tests and source checks, then executes `:app:assembleDebug`. On success, download the `SR-Smart-Toolbox-Pro-debug-apk` artifact from Actions.

## Verification limits
ZIP integrity, source wiring, XML, workflow syntax, and pure-Java helper tests were checked in this workspace. This workspace does not have Android SDK / Gradle installed, so a full APK compile, install, real video playback, codec compatibility, PiP, and background playback still need to be verified by GitHub Actions and on a physical Android device.

## প্রতিটি ভিডিওর Resume Playback
- MediaStore থেকে ফোনে ইনডেক্স করা ভিডিওগুলো অ্যাপের লাইব্রেরিতে দেখা যাবে; অনুমতির ওপর নির্ভর করে সবগুলো অথবা শুধু নির্বাচিত ভিডিও দেখা যাবে।
- ভিডিওর নাম, ফোল্ডার ও দৈর্ঘ্য দেখাবে; সার্চ, ফোল্ডার ফিল্টার এবং Sort থাকবে।
- প্রতিটি ভিডিও আলাদাভাবে শেষ দেখা অবস্থান মনে রাখবে। ভিডিওতে ট্যাপ করলে মাঝপথে থাকলে আগের অবস্থান থেকে চালু হবে।
- কোনো ভিডিওতে Long Press করলে Start from beginning নির্বাচন করা যাবে।
- ভিডিও প্রায় শেষ হয়ে গেলে পরেরবার শুরু থেকে চলবে।
- ভিডিও বন্ধ করে বের হওয়ার সময় অবস্থান সংরক্ষণ হয়; প্লে চলার সময় নিয়মিত সংরক্ষণ হয়।
- Android 13+ এ READ_MEDIA_VIDEO অনুমতি, Android 14+ এ Selected Video Access অথবা All Video Access, পুরোনো Android এ READ_EXTERNAL_STORAGE প্রয়োজন।
- কোনো ভিডিও MediaStore-এ ইনডেক্স না হলে, সিস্টেম File Picker দিয়ে খোলা যাবে।

## Home Screen / ⋮ Smart Menu
The home page now focuses on Night Screen, System-Wide Extra Volume, Thermal Monitor, QR / Barcode Scanner and SR Video Player. Tap **⋮** at the top-right for **Floating Icon Settings**, **Notification Controls**, **Android App Settings** and **About Shahriar Rahman**. The previous standalone settings/notification/About home cards have been removed without deleting their underlying screens. The app ID remains `com.smarttoolbox.pro` so update compatibility is preserved, subject to signing.

## New in 1.4.6-alpha21: Smart folder browser & Theme Settings
- Video Player now opens in Folders view with folder cards, counts, search, folder list/grid toggle and filtered videos.
- All Videos and Continue Watching shortcuts; persistent per-video resume positions unchanged.
- Theme Settings in home ⋮ menu offers Midnight Gold, Ocean Blue, Emerald Green, Royal Purple and Light Day.
- Theme choice is saved across app restarts; immersive video background remains black by design.

## 1.4.6-alpha21 — Video Library Compile Fix + Animated Floating Icon
- Fixed missing `status` and `adapter` fields in `VideoLibraryActivity` that caused repeated `cannot find symbol` errors.
- Added native swipe-reveal slide/fade/scale animation for the floating icon from either edge (270ms) and a quick panel slide/fade (200ms).
- Retained the 3-second quick-panel timeout and independent floating icon auto-hide preferences.
- Added source-AST regression tests to GitHub Actions before compiling APK.
- See `VIDEO_LIBRARY_ANIMATION_FIX_BN.md`.
