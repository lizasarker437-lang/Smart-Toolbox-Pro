# Smart Toolbox Pro — Version 1.2.0-alpha3

## 1) Floating Icon Settings
- Dedicated `Floating Icon Settings` section on the home screen.
- Enable/disable the floating ST bubble while any tool is active.
- Adjust bubble size from 40 dp to 76 dp.
- Adjust opacity from 30% to 100%.
- Enable/disable the quick control panel on tap.
- Drag the bubble to any screen position; its position is saved.
- Reset the saved position.
- Android `Display over other apps` permission is required.

## 2) Night Screen
- Adjustable black overlay from 0% to 95%.
- 90–95% provides an extra-dark screen.
- Warm filter and saved settings.
- Floating quick controls can turn dimming on/off.

## 3) System-Wide Extra Volume (best effort)
- Requests `LoudnessEnhancer` on Android global output mix (audio session 0).
- Gain control from 0 dB to +10 dB.
- Attempts to process sound from other apps, not only a selected audio file.
- Does not change the Android media-volume slider.
- Android documents global output-mix effects as deprecated/restricted on some configurations; device/OEM support is not guaranteed. The app checks whether it receives effect control and shows Unsupported if it cannot.
- It cannot exceed the physical speaker/headphone hardware limit. High gain can cause clipping, distortion or hearing damage. Start low.

## 4) Thermal Monitor
- Battery temperature and Android thermal status where available.
- Foreground monitoring service and persistent notification.
- Floating quick controls.

## 5) Document Scanner
- Camera/gallery scan, PDF export and OCR capabilities from the previous version.

## GitHub build
The project uses Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 and Android SDK 35. Use the repository's GitHub Actions workflow to compile `:app:assembleDebug` and download the `SmartToolboxPro-debug-apk` artifact.

## Verification status
Static checks included ZIP integrity, Java delimiter/syntax-structure checks, XML parsing, manifest declarations, workflow YAML parsing, service/class references and feature-specific source checks. A complete Android Gradle build was not executed in this environment because Android SDK and Gradle are not installed here. GitHub Actions must perform the final Android compile.
