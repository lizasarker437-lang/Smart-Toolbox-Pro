# Smart Toolbox Pro — Feature Update

এই সংস্করণে যোগ/পরিবর্তন করা হয়েছে:

## 1) Floating ST Control
- Night Screen, Thermal Monitor, Extra Audio অথবা Document Scanner সক্রিয় থাকলে ছোট `ST` bubble দেখায়।
- Bubble স্ক্রিনের যেকোনো দিকে টেনে নেওয়া যায়।
- Bubble চাপলে quick panel খুলবে।
- Panel থেকে Night Screen এবং Thermal Monitor ON/OFF করা যায়।
- Extra Audio playback বন্ধ করা বা Audio Booster খুলে নতুন ফাইল চালানো যায়।
- Document Scanner খোলা যায়।
- `Hide floating icon` চাপলে bubble লুকানো হয়।
- Floating bubble-এর জন্য Android-এর `Display over other apps` permission দরকার।

## 2) Extra-dark Night Screen
- Dim slider এখন 0–95% black overlay।
- 90–95% এ extra-dark mode।
- আগের level ও warm-filter setting সংরক্ষণ করা হয়।
- Floating panel থেকে Night Screen চালু/বন্ধ করা যায়।

## 3) Extra Volume Booster (অ্যাপের ভেতরে)
- পুরোনো system volume sliders সরানো হয়েছে।
- Audio file picker দিয়ে একটি audio file নির্বাচন করা যায়।
- Android `LoudnessEnhancer` দিয়ে নির্বাচিত audio file-এর playback gain 0–10 dB পর্যন্ত বাড়ানো যায়।
- Android-এর system media-volume slider পরিবর্তন করা হয় না।
- এই boost কেবল Smart Toolbox Pro-তে চালানো নির্বাচিত audio file-এ প্রযোজ্য; YouTube, game, calls বা অন্য app-এর sound system-wide boost করে না।
- ফোনের master volume এবং speaker hardware শেষ সীমা হিসেবে কাজ করে। অতিরিক্ত gain distortion বা শ্রবণক্ষতি করতে পারে।

## 4) Thermal Monitor
- Thermal status ও battery temperature foreground service-এ পর্যবেক্ষণ করা যায়।
- Notification থেকে Stop করা যায়।
- Floating panel থেকে ON/OFF করা যায়।

## Build
GitHub Actions workflow `Build Smart Toolbox Pro APK` চালিয়ে `SmartToolboxPro-debug-apk` artifact থেকে APK নামাতে হবে।

## Permissions
- `SYSTEM_ALERT_WINDOW`: floating bubble ও screen dim overlay।
- `FOREGROUND_SERVICE_SPECIAL_USE`: ব্যবহারকারীর চালু করা floating control, screen dimming ও thermal monitor services।
- `FOREGROUND_SERVICE_MEDIA_PLAYBACK`: নির্বাচিত audio file-এর background playback।
- `POST_NOTIFICATIONS`: foreground service notification দেখানো (Android 13+ এ notification permission প্রয়োজন হতে পারে)।

## Verification notes
এই সোর্সে ZIP integrity, Java file structural checks, XML parsing, Manifest service/permission declarations, dependency alignment, এবং system-volume setter অনুপস্থিতি যাচাই করা হয়েছে। এই পরিবেশে Android SDK/Gradle নেই, তাই পূর্ণ Android APK build এখানে চালানো হয়নি। GitHub Actions build-ই প্রকৃত compile verification।

---

# Smart Toolbox Pro — Android Studio Project

এটি চারটি টুলকে একটি Android অ্যাপে একত্র করার প্রথম Alpha সংস্করণ।

## অন্তর্ভুক্ত ফিচার

### 1) Night Screen
- অন্য অ্যাপের ওপর dim overlay চালু/বন্ধ
- 0–80% dim level slider
- Warm / blue-light style overlay
- Android Quick Settings-এর Night Screen tile
- Overlay permission নিজে থেকে Settings থেকে অনুমোদন করতে হবে

### 2) Volume Controls
- Media, ringtone ও notification volume slider
- Media volume-এর 40%, 60%, 80% ও Max preset
- Android-এর নির্ধারিত সর্বোচ্চ ভলিউম অতিক্রম করে স্পিকারকে জোর করে boost করে না

### 3) Thermal Monitor
- Battery temperature (যদি ডিভাইস রিপোর্ট করে)
- Android 10+ thermal status listener
- Normal, Light, Moderate, Severe, Critical, Emergency status
- CPU/GPU-এর সরাসরি তাপমাত্রা সব ফোনে Android প্রকাশ করে না; অনুপলব্ধ reading দেখানো হয় না

### 4) Document Scanner
- ফোনের Camera app দিয়ে ছবি তোলা
- Gallery থেকে একাধিক ছবি বাছাই
- একাধিক ছবিকে PDF-এ রূপান্তর
- প্রথম পৃষ্ঠার OCR text extraction ও copy
- Android 10+ এ PDF `Downloads/SmartToolboxPro` ফোল্ডারে সেভ হয়

## এখনো পরের সংস্করণে যোগ করতে হবে

- Camera preview-এর মধ্যে automatic document-edge detection ও auto crop
- Manual crop / perspective correction / scan filters
- Night Screen-এর schedule-based auto start/stop
- Advanced equalizer / bass processing (এগুলো global Android audio-তে সব ডিভাইসে সম্ভব নয়)
- আরও উন্নত thermal history chart ও floating status widget

## Build করার নিয়ম

1. কম্পিউটারে Android Studio (JDK 17 সহ) ইনস্টল করুন।
2. Android Studio থেকে **Open** নির্বাচন করে `SmartToolboxPro` ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হতে দিন। প্রথমবার Android Gradle Plugin, Android SDK 35 এবং ML Kit dependency ডাউনলোড হতে পারে।
4. Android SDK Platform 35 ইনস্টল না থাকলে SDK Manager থেকে ইনস্টল করুন।
5. ফোনে Developer options → USB debugging চালু করে USB দিয়ে যুক্ত করুন, অথবা Build → Build Bundle(s) / APK(s) → Build APK(s) নির্বাচন করুন।
6. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ পাওয়া যাবে।

## গুরুত্বপূর্ণ অনুমতি

- Night Screen: Android Settings-এ **Display over other apps** অনুমতি দিতে হবে।
- Scanner: Camera capture আলাদা Camera app দিয়ে হয়; Gallery import-এর জন্য Android document picker ব্যবহার করা হয়।
- Notification: Android 13+ এ notification permission না দিলে foreground service notification সীমিত হতে পারে।

## Build status

এই পরিবেশে Android SDK/Gradle build tool ইনস্টল করা নেই, তাই এখানে APK compile করা যায়নি। এটি Android Studio-তে খোলার উপযোগী source project; APK তৈরি করতে উপরের build ধাপ অনুসরণ করতে হবে।
