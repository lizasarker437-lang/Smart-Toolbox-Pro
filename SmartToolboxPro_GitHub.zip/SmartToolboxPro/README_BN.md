# Smart Toolbox Pro — Version 1.2.7-alpha10

## Floating quick panel — integrated feature controls
The three arrow-marked controls now keep ON/OFF and adjustment together in each feature card:
1. **Night Screen:** one ON/OFF switch plus the darkness slider and system display-brightness slider inside the same card.
2. **Thermal Monitor:** one ON/OFF switch plus the live temperature readout inside the same card.
3. **Master Volume Boost:** one ON/OFF switch plus the master gain slider inside the same card.
4. **Document Scanner:** open/close action in the fourth card.

The three feature sliders are no longer separate sub-cards; they are inline controls within their feature's main card. The former separate bottom actions remain removed. A compact × control is in the panel header.

## Automatic close after use
- The floating quick panel uses the Auto-hide delay configured in Floating Icon Settings (1–60 seconds).
- The countdown starts when the panel opens and restarts after feature actions, scrolling/touch activity, and slider release.
- Starting to drag a slider pauses the countdown; releasing it starts the countdown again.
- When the timer expires, the panel always closes automatically. The floating bubble also collapses to the edge handle only if Auto-hide is enabled.
- No separate Cancel action is required. Turning Auto-hide off keeps the bubble visible, but the panel still closes when its timer expires.

## Floating Icon Settings
- Auto-hide delay: 1–60 seconds.
- Bubble size: 24–76 dp.
- Collapsed edge-tab thickness: 6–26 dp.
- Icon opacity: 30–100%.
- Independent sidebar ON/OFF, quick-panel toggle and saved position.

## Extra Volume & Equalizer
- Global master output gain request from 0 dB to +10 dB.
- Five-band EQ: Bass, Low Mid, Mid, High Mid and Treble.
- Sound profiles: Balanced, Bass Boost, Vocal, Rock, Classical, Treble and Podcast.
- Separate Bass Boost and Virtualizer / Spatial Effect sliders.
- Android / OEM support for global audio effects varies; unsupported effects are reported.

## Other tools
- Night Screen adjustable black overlay from 0% to 95% and warm filter.
- Thermal Monitor background service.
- Document Scanner with camera/gallery scan, PDF export and OCR.

## Required special permissions
- `SYSTEM_ALERT_WINDOW`: floating sidebar and Night Screen overlay.
- `WRITE_SETTINGS`: global system display-brightness control from the floating panel.
- `FOREGROUND_SERVICE_SPECIAL_USE`: user-started foreground services.

## GitHub build
The project uses Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 and Android SDK 35. Use GitHub Actions workflow `Build Smart Toolbox Pro APK` to run `:app:assembleDebug` and download the `SmartToolboxPro-debug-apk` artifact.

## Verification status
Static checks include Java source delimiter/parser-structure checks, XML parsing, manifest declarations, workflow YAML parsing, manifest component/source mapping and feature-specific source assertions. A complete Android Gradle/APK build was not executed in this workspace because Android SDK and Gradle are not installed. GitHub Actions remains the final compile test.

## Java Compile Fix v1.2.7-alpha10
Restored missing `PanelSliderFormatter` and `PanelSliderListener` declarations in `FloatingControlService.java`. See `JAVA_COMPILE_FIX_BN.md`. Final APK compilation remains to be verified by GitHub Actions.
