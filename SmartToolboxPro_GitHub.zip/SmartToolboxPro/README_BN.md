# Smart Toolbox Pro — Version 1.2.5-alpha8

## Floating quick panel — four grouped feature cards
The floating quick panel contains exactly four main feature cards. Each card keeps its own controls together:
1. **Night Screen:** ON/OFF, black-overlay darkness slider, system display-brightness slider, and brightness permission action.
2. **Thermal Monitor:** ON/OFF plus live battery temperature and Android thermal status inside the same card.
3. **Master Volume Boost:** ON/OFF plus its own +0 to +10 dB gain slider in the same card.
4. **Document Scanner:** open/close action in the fourth card.

The previous separate controls below the four feature actions have been removed. The former bottom actions **Floating Icon Settings**, **Hide Floating Icon**, and **Close Panel** are no longer displayed. A small close (×) control is available in the panel header.

System brightness control requires Android's `Modify system settings` special access (`WRITE_SETTINGS`). The selected level is applied after permission is granted. Master Volume can be toggled independently of Equalizer/Bass/Virtualizer effects. Thermal temperature is the battery temperature reported by Android, not a fabricated CPU/GPU reading.

## Floating Icon Settings
- Auto-hide delay: 1–60 seconds.
- Bubble size: 24–76 dp.
- Collapsed edge-tab thickness: 6–26 dp.
- Icon opacity: 30–100%.
- Independent sidebar ON/OFF, quick-panel toggle and saved position.

## Extra Volume & Equalizer
- Global master output gain request from 0 dB to +10 dB.
- Five-band EQ: Bass, Low Mid, Mid, High Mid and Treble.
- Sound profiles: Balanced, Bass Boost, Vocal, Rock, Classical, Treble and Podcast.
- Separate Bass Boost and Virtualizer / Spatial Effect sliders.
- Android / OEM support for global audio effects varies; unsupported effects are reported.

## Other tools
- Night Screen adjustable black overlay from 0% to 95% and warm filter.
- Thermal Monitor background service.
- Document Scanner with camera/gallery scan, PDF export and OCR.

## Required special permissions
- `SYSTEM_ALERT_WINDOW`: floating sidebar and Night Screen overlay.
- `WRITE_SETTINGS`: global system display-brightness control from the floating panel.
- `FOREGROUND_SERVICE_SPECIAL_USE`: user-started foreground services.

## GitHub build
The project uses Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 and Android SDK 35. Use GitHub Actions workflow `Build Smart Toolbox Pro APK` to run `:app:assembleDebug` and download the `SmartToolboxPro-debug-apk` artifact.

## Verification status
Static checks include Java source delimiter/parser-structure checks, XML parsing, manifest declarations, workflow YAML parsing, manifest component/source mapping and feature-specific source assertions. A complete Android Gradle/APK build was not executed in this workspace because Android SDK and Gradle are not installed. GitHub Actions remains the final compile test.
