# Smart Toolbox Pro — Version 1.2.4-alpha7

## Floating quick controls
- Night Screen ON/OFF and black-overlay darkness slider are in the floating panel.
- Added a separate system Display brightness slider in the same panel.
- System brightness control requires Android's `Modify system settings` special access (`WRITE_SETTINGS`). The selected level is applied after permission is granted.
- Master Volume Boost has its own ON/OFF control and +0 to +10 dB level slider.
- Master Volume can be toggled independently of the Equalizer/Bass/Virtualizer effects.
- Thermal Monitor ON/OFF appears in the panel; live battery temperature and Android thermal status are shown directly below the controls while monitoring is active.
- Temperature is battery temperature supplied by Android, not a fabricated CPU/GPU reading.

## Floating Icon Settings
- Auto-hide delay is adjustable from 1 to 60 seconds.
- Bubble size is adjustable from 24 dp to 76 dp (previous minimum was 40 dp).
- Collapsed edge-tab thickness is adjustable from 6 dp to 26 dp.
- Icon opacity remains adjustable from 30% to 100%.
- The sidebar remains independently switchable when every tool is OFF.
- Android `Display over other apps` permission is required.

## Extra Volume & Equalizer
- Global master output gain request from 0 dB to +10 dB.
- Five-band EQ: Bass, Low Mid, Mid, High Mid and Treble.
- Sound profiles: Balanced, Bass Boost, Vocal, Rock, Classical, Treble and Podcast.
- Separate Bass Boost and Virtualizer / Spatial Effect sliders.
- Android / OEM support for global audio effects varies; unsupported effects are reported.

## Other tools
- Night Screen adjustable black overlay from 0% to 95% and warm filter.
- Thermal Monitor background service.
- Document Scanner with camera/gallery scan, PDF export and OCR.

## Required special permissions
- `SYSTEM_ALERT_WINDOW`: floating sidebar and Night Screen overlay.
- `WRITE_SETTINGS`: global system display-brightness control from the floating panel.
- `FOREGROUND_SERVICE_SPECIAL_USE`: user-started foreground services.

## GitHub build
The project uses Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 and Android SDK 35. Use GitHub Actions workflow `Build Smart Toolbox Pro APK` to run `:app:assembleDebug` and download the `SmartToolboxPro-debug-apk` artifact.

## Verification status
Static checks include Java source delimiter/parser-structure checks, XML parsing, manifest declarations, workflow YAML parsing, manifest component/source mapping and feature-specific source assertions. A complete Android Gradle/APK build was not executed in this workspace because Android SDK and Gradle are not installed. GitHub Actions remains the final compile test.
