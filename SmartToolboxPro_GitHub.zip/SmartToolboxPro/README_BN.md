# SR Smart Toolbox Pro — Version 1.3.1-alpha14

**Created by Shahriar Rahman**  
**YouTube:** https://www.youtube.com/@SRCreation-farm  
**Facebook:** https://fb.com/srcreation.farm

## App branding
- App display name and launcher label: **SR Smart Toolbox Pro**.
- Branded SR launcher icon.
- Home screen includes the developer profile entry.
- About the Developer screen shows Shahriar Rahman, creator / brand owner credits, and direct YouTube and Facebook buttons.
- App credits: © 2026 Shahriar Rahman. All rights reserved.
- Existing Android applicationId remains `com.smarttoolbox.pro` so this update can retain the same installed app identity.

## Features
- Night Screen: 0–95% darkness / warm filter. The phone's native brightness slider is not included in the floating panel.
- Master Extra Volume and Equalizer: five-band equalizer, Bass Boost, Virtualizer and presets where the phone supports global effects.
- Native Media Volume Plus / Minus in the floating panel.
- Thermal Monitor: battery temperature / Android Thermal Status.
- QR / Barcode Scanner: QR, EAN, UPC, Code 128, Code 39, PDF417, Aztec and other supported formats; Copy, Share and web-link open.
- Floating Icon Settings: icon ON/OFF, size, opacity, sidebar width and icon auto-hide delay.
- Notification Controls: Android notification settings shortcuts.

## Floating Quick Controls
- Swipe inward from the left or right edge tab to open the Quick Control Panel.
- Panel closes after 3 seconds without interaction, or on an outside tap when Android delivers the outside-touch event.
- If auto-hide is enabled, the floating bubble returns to the same edge.
- Icon auto-hide delay remains separately configurable from 1–60 seconds.

## GitHub Build
- Android Gradle Plugin 8.7.3 / Gradle 8.9 / JDK 17 / compileSdk 35.
- Use `.github/workflows/build-apk.yml` to run `:app:assembleDebug`.
- Successful builds upload `SR-Smart-Toolbox-Pro-debug-apk`.
- Failed builds upload `SR-Smart-Toolbox-Pro-build-errors`.

## Verification limits
The source package, Java structure, XML, manifest, workflow and ZIP integrity were checked. A full Android APK build and on-device test were not run in this workspace because Android SDK and Gradle are not installed. Run GitHub Actions and test the APK on a physical Android phone before release.
