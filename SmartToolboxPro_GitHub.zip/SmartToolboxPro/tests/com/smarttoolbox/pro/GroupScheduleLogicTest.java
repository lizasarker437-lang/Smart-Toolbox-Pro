package com.smarttoolbox.pro;
public final class GroupScheduleLogicTest {
    private static int checks;
    private static void verify(boolean ok, String message) { checks++; if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        long base = 1_700_000_000_000L;
        verify(!GroupScheduleLogic.validCount(1), "single is not group");
        verify(GroupScheduleLogic.validCount(2), "two recipients accepted");
        verify(GroupScheduleLogic.validCount(20), "max recipients accepted");
        verify(!GroupScheduleLogic.validCount(21), "over max rejected");
        verify(GroupScheduleLogic.scheduledAt(base, 0) == base, "first uses selected time");
        verify(GroupScheduleLogic.scheduledAt(base, 1) == base + 60_000L, "second staggered one minute");
        verify(GroupScheduleLogic.scheduledAt(base, 4) == base + 240_000L, "fifth staggered");
        verify(GroupScheduleLogic.scheduledAt(base, -1) == base, "negative index safe");
        verify(GroupScheduleLogic.scheduledAt(Long.MAX_VALUE - 1, 1) == Long.MAX_VALUE, "overflow safe");
        verify(GroupScheduleLogic.allTimesFuture(base, 5, base - 10_000), "all recipients in future");
        verify(!GroupScheduleLogic.allTimesFuture(base, 5, base + 240_000), "last recipient cannot be in past");
        verify(!GroupScheduleLogic.allTimesFuture(base, 5, base - 500), "first recipient also needs lead time");
        verify(GroupScheduleLogic.recipientPosition(2, 5).contains("2/5"), "batch position label");
        verify(GroupScheduleLogic.recipientPosition(99, 5).contains("5/5"), "index clamped");
        System.out.println(checks + " group schedule tests passed");
    }
}
