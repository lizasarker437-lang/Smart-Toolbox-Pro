package com.smarttoolbox.pro;

public final class SchedulerDisplayLogicTest {
    private static int checks;
    private static void verify(boolean pass, String message) {
        checks++;
        if (!pass) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        long now = 1_700_000_000_000L;
        verify(SchedulerDisplayLogic.tenSecondTrigger(now) - now == 10_000L,
                "Ten-second test must preserve seconds, not round to minutes");
        verify(SchedulerDisplayLogic.tenSecondTrigger(Long.MAX_VALUE - 5) == Long.MAX_VALUE,
                "Avoid time overflow");
        verify(SchedulerDisplayLogic.templateCount() >= 6, "Several quick templates");
        verify(SchedulerDisplayLogic.templateTitles().length == SchedulerDisplayLogic.templateCount(),
                "Template picker includes all shortcuts");
        verify(SchedulerDisplayLogic.templateTitle(0).length() > 0, "Template title");
        verify(SchedulerDisplayLogic.templateMessage(0).length() > 0, "Template message");
        verify(SchedulerDisplayLogic.templateMessage(-1).isEmpty(), "Negative template index safe");
        verify(SchedulerDisplayLogic.templateMessage(999).isEmpty(), "Out-of-range template index safe");
        verify(SchedulerDisplayLogic.remainingLabel(now + 10_000, now, "pending").contains("১০")
                        || SchedulerDisplayLogic.remainingLabel(now + 10_000, now, "pending").contains("10"),
                "Ten-second remaining label");
        verify(SchedulerDisplayLogic.remainingLabel(now + 61_000, now, "pending").contains("1 মিনিট"),
                "Minute and seconds label");
        verify(SchedulerDisplayLogic.remainingLabel(now + 3_600_000, now, "pending").contains("1 ঘণ্টা"),
                "Hour label");
        verify(SchedulerDisplayLogic.remainingLabel(now + 86_400_000, now, "pending").contains("1 দিন"),
                "Day label");
        verify(SchedulerDisplayLogic.remainingLabel(now + 1, now, "pending").contains("1 সেকেন্ড"),
                "Future millisecond must round up");
        verify(SchedulerDisplayLogic.remainingLabel(now - 1, now, "pending").contains("Alarm"),
                "Past-due pending message must not claim sent");
        verify(SchedulerDisplayLogic.remainingLabel(now, now, "paused").contains("বিরতিতে"),
                "Paused must not show sending countdown");
        verify(SchedulerDisplayLogic.remainingLabel(now, now, "due").contains("সময় হয়েছে"),
                "Due status shown");
        verify(SchedulerDisplayLogic.remainingLabel(now, now, "attempted").contains("ডেলিভারি নিশ্চিত নয়"),
                "Attempted must not claim delivered");
        verify(SchedulerDisplayLogic.remainingLabel(now, now, "done").contains("সম্পন্ন"),
                "Manually marked completion shown");
        System.out.println(checks + " scheduler timer & template tests passed");
    }
}
