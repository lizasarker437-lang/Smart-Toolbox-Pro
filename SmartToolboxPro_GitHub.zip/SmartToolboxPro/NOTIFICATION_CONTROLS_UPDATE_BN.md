# Smart Toolbox Pro — 1.2.9-alpha12 নতুন ফিচার

### Floating Panel
- ডান/বাম পাশের চিকন Tab-এ আঙুল রেখে ভিতরের দিকে Swipe করলে সরাসরি Quick Control Panel খোলে।
- Tab-এ Tap করলেও Quick Control Panel খোলে।
- ৩ সেকেন্ড ব্যবহার না করলে প্যানেল অটো বন্ধ হয়।
- ৩ সেকেন্ডের আগেই অন্য জায়গায় Tap করলে Android Outside Touch Event পেলে সঙ্গে সঙ্গে বন্ধ হয়। Android-এর Notifications Shade / System UI স্পর্শ নিজের অ্যাপ পর্যবেক্ষণ করতে পারে না।
- Auto-hide ON হলে আগের পাশে সাইড ট্যাব হয়ে যায়; Auto-hide OFF হলে Bubble খোলা থাকে।
- Floating Icon Settings-এর ১–৬০ সেকেন্ড Slider শুধু Icon Bubble-এর Idle Auto-hide সময় নির্ধারণ করে, Quick Panel-এর ৩ সেকেন্ড নয়।

### Notification Controls
- Main Activity-তে Notification Controls সেকশন।
- Android 13+ এ নোটিফিকেশন পারমিশন চাওয়া এবং Status দেখা যায়।
- App Notification Settings খুলতে পারে।
- Floating Sidebar, Night Screen, Temperature Monitor, Extra Volume & Equalizer—প্রতিটির আলাদা Notification Channel Android Settings-এ নিয়ন্ত্রণ করা যায়।
- Android 13+ এ সব অ্যাপের Notification Settings-এর তালিকায় যেতে পারে (অন্য অ্যাপের নোটিফিকেশন পড়া/মুছা হয় না)।
- Foreground Service চলতে থাকলে Android Task Manager-এ চলমান সার্ভিস দেখা যেতে পারে; নোটিফিকেশন চ্যানেল ব্লক করলেই সার্ভিস বন্ধ হয় না।

### অপরিবর্তিত ফিচার
Night Screen Extra Darkness, Master Boost & 5-band Equalizer, phone Media Volume +/- buttons, Thermal Status, Document Scanner, Floating Settings।

### পরীক্ষার সীমা
Java code structure, XML, Workflow, pure-Java Edge Swipe tests পরীক্ষা করা হয়েছে। সম্পূর্ণ Android SDK Build ও ফোনে Outside-touch আচরণ এখানে পরীক্ষা করা সম্ভব নয়।
