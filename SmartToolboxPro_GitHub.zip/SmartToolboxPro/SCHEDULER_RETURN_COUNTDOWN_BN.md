# SR Smart Toolbox Pro 1.5.3-alpha28 — Scheduler Return + 3→2→1 Countdown

## কী পরিবর্তন হয়েছে

### মেসেজ পাঠানোর পরে আগের জায়গায় ফিরে আসা
- ফোনে শিডিউল চলার আগে **Home Screen খোলা থাকলে**, মেসেজ পাঠানোর চেষ্টা শেষে Home Screen-এই ফিরে আসবে। আগের কোনো ব্যবহৃত অ্যাপ অকারণে খোলা হবে না।
- Chrome, Facebook, YouTube বা অন্য অ্যাপ সামনে খোলা থাকলে, WhatsApp থেকে Back করে ওই অ্যাপে ফিরতে চেষ্টা করবে। প্রথমে Android-এর Task Back Stack ব্যবহার করা হয়। সেটি কাজে না লাগলে আগের অ্যাপের Launcher Activity ফিরিয়ে আনার চেষ্টা করা হয়। Android সব ফোনে অ্যাপের আগের *নির্দিষ্ট পেজ* পুনরুদ্ধারের নিশ্চয়তা দেয় না।
- ফোন শিডিউলের শুরুতে লক থাকলে আগের Experimental Unlock / Home / Relock নিয়ম অপরিবর্তিত।
- Accessibility Service/Overlay Permission বন্ধ থাকলে Automation সীমিত হতে পারে। মেসেজ ডেলিভারি নিশ্চিত না হলে অ্যাপ **Attempted** দেখাবে, **Delivered** নয়।

### স্ক্রিন অন থাকলে 3 → 2 → 1
- স্ক্রিন অন এবং আনলক থাকলে নির্ধারিত সময়ের আগে **3 → 2 → 1**-এর একটি দৃশ্যমান Overlay Countdown চালু হবে; তার পর WhatsApp-এ পাঠানোর চেষ্টা শুরু হবে।
- পূর্বনির্ধারিত ৩-সেকেন্ডের Pre-Alert Alarm সময়মতো না এলে, Due Alarm-এ পূর্ণ **৩ সেকেন্ড দেখিয়ে** পাঠানোর চেষ্টা শুরু করবে। ফলে মেসেজ কয়েক সেকেন্ড দেরি হতে পারে।
- Countdown-এ **Cancel** চাপলে Auto-Send বন্ধ হয়। এর মধ্যে ফোন লক/স্ক্রিন অফ হলে স্বয়ংক্রিয় পাঠানো বন্ধ করে Manual Reminder-এর চেষ্টা হয়।
- Screen Overlay Permission ছাড়া দৃশ্যমান Countdown দেখানো সম্ভব না হলে **Manual Reminder** দেওয়া হবে; কাউন্টডাউন ছাড়া চুপিসারে Auto-Send নয়।
- Android AlarmManager ব্যাটারি সাশ্রয়/Permission সীমাবদ্ধতায় নির্ধারিত সময় কিছুটা পিছিয়ে দিতে পারে।

### প্রতিটি সেভ করা শিডিউলের বাকি সময়
- Scheduler Screen-এর প্রতিটি Pending Card-এ **📤 মেসেজটি পাঠানোর বাকি সময়** লেখা থাকবে।
- কত **দিন/ঘণ্টা/মিনিট/সেকেন্ড** বাকি আছে তা প্রতি সেকেন্ডে আপডেট হবে (স্ক্রিন খোলা থাকলে)।
- Due / Attempted / Paused / Done অবস্থায় ভুল Countdown না দেখিয়ে প্রকৃত Status দেখাবে।
- আগের সংরক্ষিত শিডিউলের Data Format অপরিবর্তিত।

## ফোনে অনুমতি
1. Android Settings → Accessibility → SR Smart Toolbox Pro Scheduler Service: ব্যবহারকারীকে নিজে চালু করতে হবে।
2. Android Settings → Display over other apps: 3→2→1 Overlay দেখাতে প্রয়োজন।
3. Notifications ও Alarms & Reminders অনুমতি নির্ধারিত সময় মনে করাতে প্রয়োজন হতে পারে।
4. Experimental Auto-Send নিজে থেকে ON হয় না; সেটিংস থেকে সম্মতি দিয়ে চালু করতে হবে।

## সীমাবদ্ধতা
এটি **Official WhatsApp UI Automation**, ফোনের SMS API নয়। WhatsApp/Android/OEM UI পরিবর্তন, Lock Screen এবং Battery Restriction-এর কারণে Auto-Send ও Back Navigation সব ডিভাইসে নিশ্চিত নয়। 

## Build পরীক্ষা
লোকাল Pure-Java ২৩টি Foreground/Countdown Test, আগের সব Source/Unit Verification, Java AST ও XML পরীক্ষা করা হয়েছে। Android SDK/Gradle অনুপস্থিত থাকায় পূর্ণ APK Build হয়নি। GitHub Actions-এ `:app:assembleDebug` চূড়ান্তভাবে চালাতে হবে।
