# SR Video Player — Version 1.4.0-alpha15

## What is included
1. Select one or multiple local videos through Android's document picker.
2. Queue / playlist with previous and next navigation.
3. Play secure HTTPS video links and RTSP streams.
4. Media3 adaptive stream modules for HLS (.m3u8), DASH (.mpd) and SmoothStreaming.
5. Native Media3 play/pause controls and seek bar.
6. Double-tap left/right side of the video to seek backward/forward 10 seconds.
7. Playback speed: 0.5x, 0.75x, 1x, 1.25x, 1.5x, 1.75x, 2x, 2.5x and 3x.
8. Repeat one / repeat playlist, shuffle, and queue selection.
9. Audio track and embedded subtitle track selection.
10. External SRT, VTT, ASS/SSA and TTML subtitle loading.
11. Fit, Fill and Zoom/Crop aspect ratio modes.
12. Player-window brightness and system media-volume sliders.
13. Full-screen landscape mode with immersive status/navigation bars and an exit button in the player controls; the screen stays awake during visible playback.
14. Picture-in-Picture on compatible devices.
15. Background audio playback via MediaSessionService with Android media notification controls and a wake lock; video stays visible in PiP while supported.
16. Screen-control lock, orientation toggle and service-managed sleep timer that continues after leaving the player screen while playback service remains alive.
17. Favorites, playback history and saved resume position.

## Compatibility and safety
- Android 8.0+ is required by the app overall (minSdk 26).
- No broad storage permission is requested; videos and subtitle files are selected with Android's Storage Access Framework.
- Secure HTTPS and RTSP are accepted for network playback. Plain HTTP is rejected by the URL validator. RTSP playback is limited to H.264, AAC and AC-3 sample formats.
- The service uses the `mediaPlayback` foreground-service type and Media3's MediaSession notification.
- Video decoding is hardware/platform-decoder-backed by default. Codec and profile support varies by device.
- Media3 extractors cover MP4, WebM, Matroska/MKV, AVI, MPEG-TS, MPEG-PS, FLV, Ogg, WAV, FLAC and several other containers. HLS/DASH/SmoothStreaming are enabled through their modules. The phone's hardware/software decoders must still support the codecs and profiles inside the container.
- No app can guarantee playback of every codec/container on every phone. Unsupported, damaged, DRM-protected or over-capability videos show a playback error instead of being advertised as universally playable.

## Dependency / build
- AndroidX Media3 1.11.1 stable.
- AGP 8.10.0, Gradle 8.11.1, compileSdk 36, JDK 17.
- `VideoPlaybackService` hosts ExoPlayer + MediaSession.
- `VideoPlayerActivity` uses MediaController and PlayerView.
