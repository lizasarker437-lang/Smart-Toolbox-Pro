# Smart Toolbox Pro — Feature Update

এই সংস্করণে যোগ/পরিবর্তন করা হয়েছে:

## 1) Floating ST Control
- Night Screen, Thermal Monitor, Extra Audio অথবা Document Scanner সক্রিয় থাকলে ছোট `ST` bubble দেখায়।
- Bubble স্ক্রিনের যেকোনো দিকে টেনে নেওয়া যায়।
- Bubble চাপলে quick panel খুলবে।
- Panel থেকে Night Screen এবং Thermal Monitor ON/OFF করা যায়।
- Extra Audio playback বন্ধ করা বা Audio Booster খুলে নতুন ফাইল চালানো যায়।
- Document Scanner খোলা যায়।
- `Hide floating icon` চাপলে bubble লুকানো হয়।
- Floating bubble-এর জন্য Android-এর `Display over other apps` permission দরকার।

## 2) Extra-dark Night Screen
- Dim slider এখন 0–95% black overlay।
- 90–95% এ extra-dark mode।
- আগের level ও warm-filter setting সংরক্ষণ করা হয়।
- Floating panel থেকে Night Screen চালু/বন্ধ করা যায়।

## 3) Extra Volume Booster (অ্যাপের ভেতরে)
- পুরোনো system volume sliders সরানো হয়েছে।
- Audio file picker দিয়ে একটি audio file নির্বাচন করা যায়।
- Android `LoudnessEnhancer` দিয়ে নির্বাচিত audio file-এর playback gain 0–10 dB পর্যন্ত বাড়ানো যায়।
- Android-এর system media-volume slider পরিবর্তন করা হয় না।
- এই boost কেবল Smart Toolbox Pro-তে চালানো নির্বাচিত audio file-এ প্রযোজ্য; YouTube, game, calls বা অন্য app-এর sound system-wide boost করে না।
- ফোনের master volume এবং speaker hardware শেষ সীমা হিসেবে কাজ করে। অতিরিক্ত gain distortion বা শ্রবণক্ষতি করতে পারে।

## 4) Thermal Monitor
- Thermal status ও battery temperature foreground service-এ পর্যবেক্ষণ করা যায়।
- Notification থেকে Stop করা যায়।
- Floating panel থেকে ON/OFF করা যায়।

## Build
GitHub Actions workflow `Build Smart Toolbox Pro APK` চালিয়ে `SmartToolboxPro-debug-apk` artifact থেকে APK নামাতে হবে।

## Permissions
- `SYSTEM_ALERT_WINDOW`: floating bubble ও screen dim overlay।
- `FOREGROUND_SERVICE_SPECIAL_USE`: ব্যবহারকারীর চালু করা floating control, screen dimming ও thermal monitor services।
- `FOREGROUND_SERVICE_MEDIA_PLAYBACK`: নির্বাচিত audio file-এর background playback।
- `POST_NOTIFICATIONS`: foreground service notification দেখানো (Android 13+ এ notification permission প্রয়োজন হতে পারে)।

## Verification notes
এই সোর্সে ZIP integrity, Java file structural checks, XML parsing, Manifest service/permission declarations, dependency alignment, এবং system-volume setter অনুপস্থিতি যাচাই করা হয়েছে। এই পরিবেশে Android SDK/Gradle নেই, তাই পূর্ণ Android APK build এখানে চালানো হয়নি। GitHub Actions build-ই প্রকৃত compile verification।
