# Smart Toolbox Pro — Feature Update 1.2.3-alpha6

## 1) Floating Sidebar
- Floating ST sidebar can be ON even if every toolbox feature is OFF.
- After 4 seconds without use, the full icon hides into a small screen-edge tab.
- Tapping the tab restores the icon and quick-control panel.
- Floating Icon Settings controls sidebar ON/OFF, auto-hide, size, opacity and saved position.

## 2) Night Screen
- 0–95% black overlay darkness.
- Warm filter and saved settings.
- Floating panel has Night Screen ON/OFF and darkness slider.

## 3) Extra Volume & Equalizer
- Existing Master Volume Control remains: 0 to +10 dB global output gain request.
- Five-band EQ: Bass, Low Mid, Mid, High Mid and Treble.
- Sound profiles: Balanced, Bass Boost, Vocal, Rock, Classical, Treble and Podcast.
- Separate Bass Boost and Virtualizer / Spatial Effect sliders.
- EQ controls can be changed inside the app and are applied live while audio processing is active.
- Values are saved and restored when the app is reopened.
- The audio service tries each global effect independently: Master `LoudnessEnhancer`, `Equalizer`, `BassBoost` and `Virtualizer`.
- Global audio effects use Android audio session 0 and may be blocked by Android or the phone manufacturer. The app reports unsupported effects rather than pretending they are active.
- This does not change Android's media-volume slider. It also cannot exceed the speaker/headphone hardware limit.

## 4) Thermal Monitor
- Battery temperature and Android thermal status where available.
- Foreground monitoring service and floating quick control.

## 5) Document Scanner
- Camera/gallery scan, PDF export and OCR.

## Build / verification
GitHub Actions workflow: `Build Smart Toolbox Pro APK`.
The source package has static checks for Java source structure, XML, manifest, workflow YAML and requested feature wiring. A complete Android Gradle build has not been run in this environment; GitHub Actions must complete `:app:assembleDebug` to verify the APK.
