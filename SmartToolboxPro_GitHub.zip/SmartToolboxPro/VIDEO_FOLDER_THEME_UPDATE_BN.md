# SR Smart Toolbox Pro — Folder Browser + Theme Settings

**Version 1.4.4-alpha19 (versionCode 19)**

## Video Folder Browser
- Video Player opens to a folder-first screen inspired by the supplied screenshot.
- Folder name and video count, including Camera, Download and WhatsApp folders when indexed by Android MediaStore.
- Folder detail screen: tap to play, long press for Continue or Start from beginning.
- Five relevant shortcuts: Folders, All Videos, Continue, Refresh and Open File.
- Folder list/grid toggle and search by folder or video title.
- Video sorting by Newest, Name A-Z or Longest.
- Previous per-video resume points remain stored separately.
- Uses MediaStore RELATIVE_PATH to group folders on Android 10+; never opens raw filesystem paths.
- Android 14+ partial media permission displays only user-selected videos. The system file picker remains available.

## Theme Settings
- Home-screen ⋮ menu includes Theme Settings.
- Five saved themes: Midnight Gold, Ocean Blue, Emerald Green, Royal Purple, Light Day.
- Main UI palette, cards, text and buttons update when theme is selected.
- Theme is saved in private SharedPreferences and restored when app starts again.
- Home screen recreates when returning from Theme Settings to apply the selected palette.
- Activity dialogs also receive the light/dark base Android theme.
- Cinema-mode Video Player deliberately stays black; system overlays with fixed colors may retain dark styling.

## Build limitations
Android SDK and Gradle are not installed in this workspace. Pure Java theme/folder logic tests, workflow source checks, XML and ZIP integrity can be run here, but actual Android APK build and phone testing require GitHub Actions + a device.
