package com.smarttoolbox.pro;

import java.util.Locale;

/** Pure Java presentation rules for the WhatsApp scheduler. */
final class SchedulerDisplayLogic {
    private SchedulerDisplayLogic() {}

    static final long TEN_SECOND_TEST_DELAY_MS = 10_000L;
    private static final String[] TITLES = {
            "শুভ সকাল", "শুভ রাত", "ধন্যবাদ", "জন্মদিন",
            "মিটিং", "পরে কথা", "খোঁজখবর", "দ্রুত জানাবেন"
    };
    private static final String[] MESSAGES = {
            "আসসালামু আলাইকুম। শুভ সকাল! আশা করি আপনার দিনটি সুন্দর কাটবে।",
            "শুভ রাত। ভালো থাকবেন, সুস্থ থাকবেন।",
            "অনেক ধন্যবাদ। আপনার সহযোগিতার জন্য কৃতজ্ঞ।",
            "শুভ জন্মদিন! আপনার সুস্থতা, সুখ ও সফলতা কামনা করছি।",
            "স্মরণ করিয়ে দিচ্ছি, আমাদের নির্ধারিত মিটিংয়ের সময় হয়েছে। অনুগ্রহ করে নিশ্চিত করবেন।",
            "এখন একটু ব্যস্ত আছি। কিছুক্ষণ পরে আপনার সঙ্গে কথা বলব।",
            "আসসালামু আলাইকুম। কেমন আছেন? সময় হলে জানাবেন।",
            "সময় হলে দয়া করে আমাকে একটি উত্তর জানাবেন। ধন্যবাদ।"
    };

    static int templateCount() { return TITLES.length; }
    static String[] templateTitles() { return TITLES.clone(); }
    static String templateTitle(int index) {
        return index < 0 || index >= TITLES.length ? "" : TITLES[index];
    }
    static String templateMessage(int index) {
        return index < 0 || index >= MESSAGES.length ? "" : MESSAGES[index];
    }

    static long tenSecondTrigger(long nowMillis) {
        return nowMillis > Long.MAX_VALUE - TEN_SECOND_TEST_DELAY_MS
                ? Long.MAX_VALUE : nowMillis + TEN_SECOND_TEST_DELAY_MS;
    }

    static String remainingLabel(long dueMillis, long nowMillis, String status) {
        if ("paused".equals(status)) return "Ⅱ শিডিউল বিরতিতে আছে";
        if ("due".equals(status)) return "● সময় হয়েছে · WhatsApp-এ মেসেজ যাচাই করুন";
        if ("attempted".equals(status)) return "➤ Send চেষ্টা হয়েছে · ডেলিভারি নিশ্চিত নয়";
        if ("done".equals(status)) return "✓ সম্পন্ন হিসেবে চিহ্নিত";
        if (!"pending".equals(status)) return "অবস্থা: " + (status == null ? "unknown" : status);
        if (dueMillis <= nowMillis) return "⏳ সময় হয়েছে · Android Alarm অপেক্ষায়";

        // Round up to a second: never display zero while a future event is pending.
        long delta = dueMillis - nowMillis;
        long seconds = delta / 1000L + (delta % 1000L == 0 ? 0 : 1);
        long days = seconds / 86400L;
        long hours = (seconds % 86400L) / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long sec = seconds % 60L;
        if (days > 0) return String.format(Locale.ROOT,
                "⏳ আর %d দিন %d ঘণ্টা %d মিনিট বাকি", days, hours, minutes);
        if (hours > 0) return String.format(Locale.ROOT,
                "⏳ আর %d ঘণ্টা %d মিনিট %d সেকেন্ড বাকি", hours, minutes, sec);
        if (minutes > 0) return String.format(Locale.ROOT,
                "⏳ আর %d মিনিট %d সেকেন্ড বাকি", minutes, sec);
        return String.format(Locale.ROOT, "⏳ আর %d সেকেন্ড বাকি", sec);
    }
}
