package com.smarttoolbox.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Rational;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import androidx.media3.common.util.RepeatModeUtil;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

@UnstableApi
public class VideoPlayerActivity extends Activity {
    private static final int REQUEST_OPEN_VIDEOS = 4101;
    private static final int REQUEST_OPEN_SUBTITLE = 4102;
    private static final String PREFS = "sr_video_player";
    private static final long POSITION_SAVE_INTERVAL_MS = 1500L;

    private LinearLayout rootPage;
    private LinearLayout body;
    private LinearLayout videoCard;
    private android.graphics.drawable.Drawable originalVideoCardBackground;
    private PlayerView playerView;
    private LinearLayout playerTools;
    private TextView statusText;
    private TextView nowPlayingText;
    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private List<MediaItem> pendingItems;
    private CountDownTimer sleepTimer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean screenLocked;
    private boolean inPictureInPicture;
    private boolean wasFullScreenBeforePip;
    private boolean activityStarted;
    private boolean landscape;
    private boolean fullScreen;
    private boolean playbackEnded;
    private int originalSystemUiVisibility;
    private int resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
    private GestureDetector gestureDetector;

    private final Runnable savePositionRunnable = new Runnable() {
        @Override public void run() {
            saveResumePoint();
            updateNowPlaying();
            handler.postDelayed(this, POSITION_SAVE_INTERVAL_MS);
        }
    };

    private final Player.Listener playerListener = new Player.Listener() {
        @Override public void onMediaItemTransition(MediaItem mediaItem, int reason) {
            playbackEnded = false;
            updateNowPlaying();
            saveResumePoint();
            rememberHistory(mediaItem);
        }

        @Override public void onPlaybackStateChanged(int playbackState) {
            playbackEnded = playbackState == Player.STATE_ENDED;
            updateNowPlaying();
            if (playbackEnded) {
                saveResumePoint();
            }
        }

        @Override public void onIsPlayingChanged(boolean isPlaying) {
            if (playerView != null) playerView.setKeepScreenOn(isPlaying);
            updateNowPlaying();
        }

        @Override public void onPlayerError(PlaybackException error) {
            String message = "এই ভিডিওটি চালানো যায়নি। ফাইলটি নষ্ট, অসমর্থিত Codec অথবা নেটওয়ার্ক সমস্যা হতে পারে।";
            if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
                    || error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
                    || error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED) {
                message = "এই ফোনে ভিডিওটির Codec / Resolution সমর্থিত নয়। অন্য ফরম্যাট বা কম Resolution-এর ভিডিও চেষ্টা করুন।";
            } else if (error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
                    || error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
                    || error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
                    || error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED) {
                message = "ভিডিওর Container / Stream format অসমর্থিত অথবা ফাইলটি নষ্ট। অন্য ভিডিও চেষ্টা করুন।";
            } else if (error.errorCode == PlaybackException.ERROR_CODE_IO_NO_PERMISSION
                    || error.errorCode == PlaybackException.ERROR_CODE_PERMISSION_DENIED) {
                message = "ভিডিও ফাইলটি পড়ার অনুমতি নেই। ফাইলটি আবার নির্বাচন করুন।";
            } else if (error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                    || error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) {
                message = "নেটওয়ার্ক সংযোগ পাওয়া যায়নি। ইন্টারনেট ও ভিডিও লিংক পরীক্ষা করুন।";
            }
            statusText.setText(message);
            Toast.makeText(VideoPlayerActivity.this, message, Toast.LENGTH_LONG).show();
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        buildInterface();
        setupGestures();
    }

    private void buildInterface() {
        rootPage = Ui.page(this, "SR Video Player");
        body = Ui.content(rootPage);

        Ui.addText(this, body,
                "Premium video playback • Created by Shahriar Rahman",
                13, Ui.MUTED, false, 2);

        LinearLayout openCard = Ui.card(this);
        Ui.addText(this, openCard, "Open videos", 18, Ui.TEXT, true, 0);
        Ui.addText(this, openCard,
                "Choose one or multiple videos from your phone. Files are opened through Android's document picker; no broad storage permission is required.",
                13, Ui.MUTED, false, 6);
        addButton(openCard, "＋  Select videos / playlist", this::openVideos);
        addButton(openCard, "↗  Play HTTPS video URL", this::openNetworkUrl);
        addButton(openCard, "▶  Continue last video", this::resumeLastVideo);
        addButton(openCard, "★  My favorites", this::showFavorites);
        addButton(openCard, "◷  Playback history", this::showHistory);
        Ui.addCard(this, body, openCard, 12);

        videoCard = Ui.card(this);
        originalVideoCardBackground = videoCard.getBackground();
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        playerView.setControllerHideOnTouch(true);
        playerView.setControllerShowTimeoutMs(3000);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setShowRewindButton(true);
        playerView.setShowFastForwardButton(true);
        playerView.setTimeBarScrubbingEnabled(true);
        playerView.setKeepContentOnPlayerReset(true);
        playerView.setResizeMode(resizeMode);
        playerView.setShutterBackgroundColor(Color.BLACK);
        playerView.setRepeatToggleModes(RepeatModeUtil.REPEAT_TOGGLE_MODE_ONE
                | RepeatModeUtil.REPEAT_TOGGLE_MODE_ALL);
        playerView.setShowShuffleButton(true);
        playerView.setShowNextButton(true);
        playerView.setShowPreviousButton(true);
        playerView.setShowSubtitleButton(true);
        playerView.setFullscreenButtonClickListener(this::setFullScreen);
        playerView.setFullscreenButtonState(false);
        originalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
        LinearLayout.LayoutParams videoParams =
                new LinearLayout.LayoutParams(-1, Ui.dp(this, 232));
        videoCard.addView(playerView, videoParams);
        Ui.addCard(this, body, videoCard, 14);

        nowPlayingText = Ui.addText(this, body, "No video selected", 14, Ui.TEXT, true, 10);
        statusText = Ui.addText(this, body,
                "Player ready. Select a video or open a network URL.",
                12, Ui.MUTED, false, 4);

        playerTools = new LinearLayout(this);
        playerTools.setOrientation(LinearLayout.VERTICAL);
        LinearLayout playbackCard = Ui.card(this);
        Ui.addText(this, playbackCard, "Playback controls", 17, Ui.TEXT, true, 0);
        addButton(playbackCard, "⏮  Previous video", this::previousVideo);
        addButton(playbackCard, "⏭  Next video", this::nextVideo);
        addButton(playbackCard, "⤨  Shuffle on / off", this::toggleShuffle);
        addButton(playbackCard, "↻  Repeat mode", this::chooseRepeatMode);
        addButton(playbackCard, "⏩  Playback speed", this::chooseSpeed);
        addButton(playbackCard, "▣  Aspect ratio / Zoom", this::chooseAspectRatio);
        addButton(playbackCard, "↻  Rotate screen", this::toggleOrientation);
        addButton(playbackCard, "⛶  Picture in Picture", this::enterPictureInPicture);
        addButton(playbackCard, "🔒  Lock / Unlock video controls", this::toggleScreenLock);
        Ui.addCard(this, playerTools, playbackCard, 12);

        LinearLayout tracksCard = Ui.card(this);
        Ui.addText(this, tracksCard, "Audio & subtitles", 17, Ui.TEXT, true, 0);
        addButton(tracksCard, "🎧  Select audio track", () -> chooseTrack(C.TRACK_TYPE_AUDIO));
        addButton(tracksCard, "CC  Select subtitle track", () -> chooseTrack(C.TRACK_TYPE_TEXT));
        addButton(tracksCard, "＋  Load external subtitle (SRT / VTT / ASS / TTML)", this::openSubtitle);
        Ui.addCard(this, playerTools, tracksCard, 12);

        LinearLayout toolsCard = Ui.card(this);
        Ui.addText(this, toolsCard, "Smart tools", 17, Ui.TEXT, true, 0);
        addButton(toolsCard, "★  Add / remove current video from favorites", this::toggleFavorite);
        addButton(toolsCard, "☷  Current playlist / queue", this::showQueue);
        addButton(toolsCard, "◷  Sleep timer", this::chooseSleepTimer);
        addButton(toolsCard, "Stop playback", this::stopPlayback);
        Ui.addCard(this, playerTools, toolsCard, 12);

        LinearLayout displayCard = Ui.card(this);
        Ui.addText(this, displayCard, "Player brightness & volume", 17, Ui.TEXT, true, 0);
        Ui.addText(this, displayCard, "Brightness (player window only)", 13, Ui.MUTED, false, 8);
        SeekBar brightness = new SeekBar(this);
        brightness.setMax(100);
        float currentBrightness = getWindow().getAttributes().screenBrightness;
        brightness.setProgress(currentBrightness < 0 ? 55 : Math.max(1, (int) (currentBrightness * 100)));
        brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {
                if (!fromUser) return;
                WindowManager.LayoutParams params = getWindow().getAttributes();
                params.screenBrightness = Math.max(0.02f, value / 100f);
                getWindow().setAttributes(params);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        displayCard.addView(brightness, new LinearLayout.LayoutParams(-1, -2));

        Ui.addText(this, displayCard, "Media volume", 13, Ui.MUTED, false, 8);
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        SeekBar volume = new SeekBar(this);
        int maxVolume = audioManager == null ? 15 : audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int currentVolume = audioManager == null ? 0 : audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        volume.setMax(Math.max(1, maxVolume));
        volume.setProgress(currentVolume);
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {
                if (fromUser && audioManager != null) {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        displayCard.addView(volume, new LinearLayout.LayoutParams(-1, -2));
        Ui.addCard(this, playerTools, displayCard, 12);

        Ui.addText(this, body,
                "Format note: MP4, MKV/Matroska, WebM, AVI, MPEG-TS, MPEG-PS, FLV and supported HLS/DASH/SmoothStreaming streams are handled when their contained codecs are supported by Android or Media3. Unusual codecs or high-resolution profiles are not guaranteed on every phone.",
                12, Ui.MUTED, false, 14);
        body.addView(playerTools);
        setContentView(rootPage);
    }

    private void addButton(LinearLayout card, String label, Runnable action) {
        android.widget.Button button = Ui.button(this, label, action);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = Ui.dp(this, 8);
        card.addView(button, params);
    }

    private void setupGestures() {
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent event) { return true; }

            @Override public boolean onDoubleTap(MotionEvent event) {
                if (screenLocked) return true;
                if (controller == null || controller.getMediaItemCount() == 0) return false;
                long delta = event.getX() < playerView.getWidth() / 2f ? -10_000L : 10_000L;
                long target = Math.max(0L, controller.getCurrentPosition() + delta);
                long duration = controller.getDuration();
                if (duration > 0) target = Math.min(duration, target);
                controller.seekTo(target);
                String label = delta < 0 ? "10 seconds back" : "10 seconds forward";
                statusText.setText(label);
                return true;
            }
        });
        playerView.setOnTouchListener((view, event) -> {
            gestureDetector.onTouchEvent(event);
            return false; // Keep Media3's own playback controls responsive.
        });
    }

    @Override protected void onStart() {
        super.onStart();
        activityStarted = true;
        handler.removeCallbacks(savePositionRunnable);
        handler.post(savePositionRunnable);
        connectController();
    }

    private void connectController() {
        if (controllerFuture != null) return;
        SessionToken token = new SessionToken(this,
                new ComponentName(this, VideoPlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        final ListenableFuture<MediaController> requestedFuture = controllerFuture;
        requestedFuture.addListener(() -> {
            if (!activityStarted || requestedFuture != controllerFuture) {
                // onStop already releases any future that is no longer current.
                return;
            }
            try {
                controller = requestedFuture.get();
                playerView.setPlayer(controller);
                playerView.setKeepScreenOn(controller.isPlaying());
                controller.addListener(playerListener);
                statusText.setText("Connected. Choose a video to start playback.");
                if (pendingItems != null && !pendingItems.isEmpty()) {
                    List<MediaItem> items = pendingItems;
                    pendingItems = null;
                    if (pendingResumePosition != C.TIME_UNSET && items.size() == 1) {
                        controller.setMediaItem(items.get(0), pendingResumePosition);
                        pendingResumePosition = C.TIME_UNSET;
                        controller.prepare();
                        controller.play();
                    } else {
                        playItems(items);
                    }
                }
                updateNowPlaying();
            } catch (ExecutionException | InterruptedException error) {
                if (error instanceof InterruptedException) Thread.currentThread().interrupt();
                statusText.setText("Video service could not start. Please close and reopen the player.");
                Toast.makeText(this, "Could not connect to video playback service.", Toast.LENGTH_LONG).show();
                controllerFuture = null;
            } catch (RuntimeException error) {
                statusText.setText("Video service connection failed. Please retry.");
                Toast.makeText(this, "Could not connect to video playback service.", Toast.LENGTH_LONG).show();
                controllerFuture = null;
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void openVideos() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Some providers label MKV/Matroska and less common containers as application/*.
        // Use the SAF picker broadly rather than hiding valid files behind video/* only.
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "video/*", "application/x-matroska", "video/x-matroska",
                "video/x-msvideo", "application/x-troff-msvideo",
                "application/vnd.apple.mpegurl", "application/x-mpegURL",
                "application/dash+xml", "application/vnd.ms-sstr+xml",
                "application/octet-stream"
        });
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_OPEN_VIDEOS);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "No file picker is available on this phone.", Toast.LENGTH_LONG).show();
        }
    }

    private void openSubtitle() {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            toast("আগে একটি ভিডিও চালু করুন।");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_OPEN_SUBTITLE);
        } catch (ActivityNotFoundException error) {
            toast("Subtitle picker পাওয়া যায়নি।");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_OPEN_VIDEOS) {
            List<Uri> uris = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    uris.add(data.getClipData().getItemAt(i).getUri());
                }
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            List<MediaItem> items = new ArrayList<>();
            for (Uri uri : uris) {
                takePersistableReadPermission(uri, data.getFlags());
                String title = getDisplayName(uri);
                items.add(createMediaItem(uri, title));
            }
            if (!items.isEmpty()) playItems(items);
        } else if (requestCode == REQUEST_OPEN_SUBTITLE && data.getData() != null) {
            Uri subtitleUri = data.getData();
            takePersistableReadPermission(subtitleUri, data.getFlags());
            attachSubtitle(subtitleUri);
        }
    }

    private void takePersistableReadPermission(Uri uri, int resultFlags) {
        try {
            int readFlag = resultFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            int persistableFlag = resultFlags & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION;
            if (readFlag != 0 && persistableFlag != 0) {
                getContentResolver().takePersistableUriPermission(uri, readFlag);
            }
        } catch (SecurityException | IllegalArgumentException ignored) {
            // Some document providers issue temporary grants only. Playback still works for this session.
        }
    }

    private void playItems(List<MediaItem> items) {
        if (controller == null) {
            pendingResumePosition = C.TIME_UNSET;
            pendingItems = new ArrayList<>(items);
            statusText.setText("Connecting to video service…");
            connectController();
            return;
        }
        try {
            controller.setMediaItems(items, 0, C.TIME_UNSET);
            controller.prepare();
            controller.play();
            statusText.setText(items.size() == 1 ? "Video loaded." : items.size() + " videos added to playlist.");
            updateNowPlaying();
        } catch (RuntimeException error) {
            statusText.setText("ভিডিওটি খোলা যায়নি। অন্য ফাইল নির্বাচন করুন।");
        }
    }

    private void openNetworkUrl() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://example.com/video.m3u8  or  rtsp://camera/stream");
        new AlertDialog.Builder(this)
                .setTitle("Play network video")
                .setMessage("Secure HTTPS / RTSP video URL, HLS (.m3u8) or DASH (.mpd)")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Play", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (!VideoPlayerLogic.isNetworkUrl(value)) {
                        toast("সঠিক HTTPS অথবা RTSP ভিডিও লিংক দিন।");
                        return;
                    }
                    Uri uri = Uri.parse(value);
                    MediaItem item = createMediaItem(uri, VideoPlayerLogic.titleFromUrl(value));
                    playItems(Collections.singletonList(item));
                }).show();
    }

    private void resumeLastVideo() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String savedUri = prefs.getString("last_uri", null);
        if (savedUri == null || savedUri.trim().isEmpty()) {
            toast("এখনো কোনো ভিডিওর Resume তথ্য নেই।");
            return;
        }
        try {
            Uri uri = Uri.parse(savedUri);
            long position = Math.max(0L, prefs.getLong("last_position", 0L));
            MediaItem item = createMediaItem(uri, prefs.getString("last_title", getDisplayName(uri)));
            if (controller == null) {
                pendingItems = Collections.singletonList(item);
                pendingResumePosition = position;
                connectController();
                return;
            }
            controller.setMediaItem(item, position);
            controller.prepare();
            controller.play();
        } catch (SecurityException error) {
            toast("ফাইলের অনুমতি আর পাওয়া যাচ্ছে না। ভিডিওটি আবার নির্বাচন করুন।");
        } catch (RuntimeException error) {
            toast("শেষ ভিডিওটি পুনরায় খোলা যায়নি।");
        }
    }

    private long pendingResumePosition = C.TIME_UNSET;

    private void updateNowPlaying() {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            nowPlayingText.setText("No video selected");
            return;
        }
        MediaItem item = controller.getCurrentMediaItem();
        String title = item.mediaMetadata.title == null
                ? getTitleFromItem(item) : item.mediaMetadata.title.toString();
        nowPlayingText.setText("▶  " + title + "  ·  " +
                (controller.getCurrentMediaItemIndex() + 1) + "/" + controller.getMediaItemCount());
        long duration = controller.getDuration();
        statusText.setText(controller.isPlaying()
                ? "Playing  •  " + formatTime(controller.getCurrentPosition()) + " / " + formatTime(duration)
                : "Ready  •  " + formatTime(controller.getCurrentPosition()) + " / " + formatTime(duration));
    }

    private String getTitleFromItem(MediaItem item) {
        try {
            Uri uri = getUriFromItem(item);
            if (uri != null) return getDisplayName(uri);
        } catch (Exception ignored) {}
        return "Video";
    }

    private MediaItem createMediaItem(Uri uri, String title) {
        MediaMetadata metadata = new MediaMetadata.Builder()
                .setTitle(title == null || title.trim().isEmpty() ? "Video" : title)
                .build();
        MediaItem.Builder builder = new MediaItem.Builder()
                .setUri(uri)
                // Keep the URI in mediaId as a fallback because session IPC may omit localConfiguration.
                .setMediaId(uri.toString())
                .setMediaMetadata(metadata);
        String mimeType = getContentResolver().getType(uri);
        if (mimeType != null) builder.setMimeType(mimeType);
        return builder.build();
    }

    private Uri getUriFromItem(MediaItem item) {
        if (item == null) return null;
        if (item.localConfiguration != null && item.localConfiguration.uri != null) {
            return item.localConfiguration.uri;
        }
        String mediaId = item.mediaId;
        if (mediaId != null && !mediaId.trim().isEmpty()) {
            Uri parsed = Uri.parse(mediaId);
            String scheme = parsed.getScheme();
            if ("content".equalsIgnoreCase(scheme) || "file".equalsIgnoreCase(scheme)
                    || "https".equalsIgnoreCase(scheme) || "rtsp".equalsIgnoreCase(scheme)) {
                return parsed;
            }
        }
        return null;
    }

    private String getDisplayName(Uri uri) {
        String result = uri.getLastPathSegment();
        try (android.database.Cursor cursor = getContentResolver().query(
                uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (column >= 0) result = cursor.getString(column);
            }
        } catch (Exception ignored) {}
        if (result == null || result.trim().isEmpty()) result = "Video";
        return result;
    }

    private void saveResumePoint() {
        if (controller == null || controller.getCurrentMediaItem() == null) return;
        MediaItem item = controller.getCurrentMediaItem();
        Uri uri = getUriFromItem(item);
        if (uri == null) return;
        long position = playbackEnded ? 0L : Math.max(0L, controller.getCurrentPosition());
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("last_uri", uri.toString())
                .putString("last_title", getTitleFromItem(item))
                .putLong("last_position", position)
                .apply();
    }

    private void rememberHistory(MediaItem item) {
        Uri itemUri = getUriFromItem(item);
        if (itemUri == null) return;
        String uri = itemUri.toString();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> history = new HashSet<>(prefs.getStringSet("history", Collections.emptySet()));
        history.remove(uri);
        history.add(uri);
        if (history.size() > 30) {
            // Keep the newest set bounded. The set is only a convenience list; URI order is not promised.
            history.clear();
            history.add(uri);
        }
        prefs.edit().putStringSet("history", history).apply();
    }

    private void toggleFavorite() {
        MediaItem item = controller == null ? null : controller.getCurrentMediaItem();
        Uri itemUri = getUriFromItem(item);
        if (itemUri == null) {
            toast("আগে একটি ভিডিও চালু করুন।");
            return;
        }
        String uri = itemUri.toString();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> favorites = new HashSet<>(prefs.getStringSet("favorites", Collections.emptySet()));
        boolean removed = favorites.remove(uri);
        if (!removed) favorites.add(uri);
        prefs.edit().putStringSet("favorites", favorites).apply();
        toast(removed ? "Favorites থেকে সরানো হয়েছে।" : "Favorites-এ যোগ করা হয়েছে।");
    }

    private void showFavorites() {
        Set<String> favorites = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getStringSet("favorites", Collections.emptySet());
        if (favorites.isEmpty()) {
            toast("এখনো কোনো Favorite ভিডিও নেই।");
            return;
        }
        List<String> uris = new ArrayList<>(favorites);
        String[] labels = new String[uris.size()];
        for (int i = 0; i < uris.size(); i++) labels[i] = getDisplayName(Uri.parse(uris.get(i)));
        new AlertDialog.Builder(this).setTitle("Favorite videos")
                .setItems(labels, (dialog, which) -> {
                    Uri uri = Uri.parse(uris.get(which));
                    playItems(Collections.singletonList(createMediaItem(uri, labels[which])));
                })
                .setNegativeButton("Close", null).show();
    }

    private void showHistory() {
        Set<String> history = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getStringSet("history", Collections.emptySet());
        if (history.isEmpty()) {
            toast("এখনো কোনো Playback History নেই।");
            return;
        }
        List<String> uris = new ArrayList<>(history);
        String[] labels = new String[uris.size()];
        for (int i = 0; i < uris.size(); i++) labels[i] = getDisplayName(Uri.parse(uris.get(i)));
        new AlertDialog.Builder(this).setTitle("Playback history")
                .setItems(labels, (dialog, which) -> {
                    Uri uri = Uri.parse(uris.get(which));
                    playItems(Collections.singletonList(createMediaItem(uri, labels[which])));
                })
                .setNegativeButton("Close", null).show();
    }

    private void showQueue() {
        if (controller == null || controller.getMediaItemCount() == 0) {
            toast("Playlist খালি।");
            return;
        }
        int count = controller.getMediaItemCount();
        String[] labels = new String[count];
        for (int i = 0; i < count; i++) labels[i] = (i + 1) + ". " + getTitleFromItem(controller.getMediaItemAt(i));
        new AlertDialog.Builder(this).setTitle("Current playlist")
                .setSingleChoiceItems(labels, controller.getCurrentMediaItemIndex(), (dialog, which) -> {
                    controller.seekTo(which, 0L);
                    controller.play();
                    dialog.dismiss();
                }).setNegativeButton("Close", null).show();
    }

    private void previousVideo() {
        if (controller == null || controller.getMediaItemCount() == 0) return;
        if (controller.hasPreviousMediaItem()) controller.seekToPreviousMediaItem();
        else controller.seekTo(0L);
    }

    private void nextVideo() {
        if (controller != null && controller.hasNextMediaItem()) controller.seekToNextMediaItem();
    }

    private void toggleShuffle() {
        if (controller == null) return;
        boolean enabled = !controller.getShuffleModeEnabled();
        controller.setShuffleModeEnabled(enabled);
        toast(enabled ? "Shuffle enabled" : "Shuffle disabled");
    }

    private void chooseRepeatMode() {
        if (controller == null) return;
        String[] modes = {"Off", "Repeat current video", "Repeat playlist"};
        new AlertDialog.Builder(this).setTitle("Repeat mode")
                .setSingleChoiceItems(modes, controller.getRepeatMode(), (dialog, which) -> {
                    int mode = which == 1 ? Player.REPEAT_MODE_ONE
                            : which == 2 ? Player.REPEAT_MODE_ALL : Player.REPEAT_MODE_OFF;
                    controller.setRepeatMode(mode);
                    dialog.dismiss();
                }).setNegativeButton("Cancel", null).show();
    }

    private void chooseSpeed() {
        if (controller == null) return;
        float[] speeds = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f};
        String[] labels = {"0.5×", "0.75×", "1.0×", "1.25×", "1.5×", "1.75×", "2.0×", "2.5×", "3.0×"};
        new AlertDialog.Builder(this).setTitle("Playback speed")
                .setSingleChoiceItems(labels, -1, (dialog, which) -> {
                    controller.setPlaybackParameters(new PlaybackParameters(speeds[which]));
                    statusText.setText("Playback speed: " + labels[which]);
                    dialog.dismiss();
                }).setNegativeButton("Cancel", null).show();
    }

    private void chooseAspectRatio() {
        String[] labels = {"Fit", "Fill", "Zoom / Crop"};
        int[] modes = {AspectRatioFrameLayout.RESIZE_MODE_FIT,
                AspectRatioFrameLayout.RESIZE_MODE_FILL,
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM};
        new AlertDialog.Builder(this).setTitle("Video aspect ratio")
                .setSingleChoiceItems(labels, resizeMode == modes[0] ? 0 : resizeMode == modes[1] ? 1 : 2,
                        (dialog, which) -> {
                            resizeMode = modes[which];
                            playerView.setResizeMode(resizeMode);
                            dialog.dismiss();
                        }).setNegativeButton("Cancel", null).show();
    }

    private void chooseTrack(int trackType) {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            toast("আগে একটি ভিডিও চালু করুন।");
            return;
        }
        List<TrackChoice> choices = new ArrayList<>();
        if (trackType == C.TRACK_TYPE_TEXT) choices.add(TrackChoice.off());
        Tracks tracks = controller.getCurrentTracks();
        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() != trackType) continue;
            for (int i = 0; i < group.length; i++) {
                if (!group.isTrackSupported(i)) continue;
                Format format = group.getTrackFormat(i);
                String label = format.label;
                if (label == null || label.trim().isEmpty()) label = format.language;
                if (label == null || label.trim().isEmpty()) label = "Track " + (i + 1);
                if (format.sampleMimeType != null) label += "  ·  " + format.sampleMimeType;
                choices.add(new TrackChoice(group, i, label, false));
            }
        }
        if (choices.size() <= (trackType == C.TRACK_TYPE_TEXT ? 1 : 0)) {
            toast(trackType == C.TRACK_TYPE_AUDIO
                    ? "এই ভিডিওতে আলাদা Audio Track পাওয়া যায়নি।"
                    : "Subtitle Track পাওয়া যায়নি। External Subtitle যোগ করতে পারেন।");
            return;
        }
        String[] labels = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) labels[i] = choices.get(i).label;
        new AlertDialog.Builder(this)
                .setTitle(trackType == C.TRACK_TYPE_AUDIO ? "Select audio track" : "Select subtitle track")
                .setItems(labels, (dialog, which) -> applyTrackChoice(trackType, choices.get(which)))
                .setNegativeButton("Cancel", null).show();
    }

    private void applyTrackChoice(int trackType, TrackChoice choice) {
        TrackSelectionParameters.Builder builder =
                controller.getTrackSelectionParameters().buildUpon()
                        .clearOverridesOfType(trackType);
        if (choice.off) {
            builder.setTrackTypeDisabled(trackType, true);
        } else {
            builder.setTrackTypeDisabled(trackType, false);
            builder.addOverride(new TrackSelectionOverride(choice.group.getMediaTrackGroup(), choice.trackIndex));
        }
        controller.setTrackSelectionParameters(builder.build());
        toast(choice.off ? "Subtitles off" : "Track selected");
    }

    private void attachSubtitle(Uri subtitleUri) {
        MediaItem current = controller == null ? null : controller.getCurrentMediaItem();
        Uri currentUri = getUriFromItem(current);
        if (current == null || currentUri == null) {
            toast("বর্তমান ভিডিওর URI পাওয়া যায়নি।");
            return;
        }
        String name = getDisplayName(subtitleUri);
        String mime = VideoPlayerLogic.subtitleMimeType(name);
        if (mime == null) {
            toast("এই Subtitle ফরম্যাট সমর্থিত নয়। SRT, VTT, ASS বা TTML ব্যবহার করুন।");
            return;
        }
        try {
            MediaItem.SubtitleConfiguration subtitle =
                    new MediaItem.SubtitleConfiguration.Builder(subtitleUri)
                            .setMimeType(mime)
                            .setLanguage("und")
                            .setLabel(name)
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                            .build();
            long position = controller.getCurrentPosition();
            boolean wasPlaying = controller.getPlayWhenReady();
            MediaItem.Builder updatedBuilder = new MediaItem.Builder()
                    .setUri(currentUri)
                    .setMediaId(currentUri.toString())
                    .setMediaMetadata(current.mediaMetadata)
                    .setSubtitleConfigurations(Collections.singletonList(subtitle));
            String originalMimeType = getContentResolver().getType(currentUri);
            if (originalMimeType != null) updatedBuilder.setMimeType(originalMimeType);
            MediaItem updated = updatedBuilder.build();
            controller.setMediaItem(updated, position);
            controller.setTrackSelectionParameters(controller.getTrackSelectionParameters()
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .build());
            controller.prepare();
            controller.setPlayWhenReady(wasPlaying);
            toast("External subtitle যুক্ত হয়েছে।");
        } catch (RuntimeException error) {
            toast("Subtitle যুক্ত করা যায়নি। ফাইলটি পরীক্ষা করুন।");
        }
    }

    private void chooseSleepTimer() {
        String[] options = {"10 minutes", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "Cancel timer"};
        long[] durations = {10, 15, 30, 45, 60};
        new AlertDialog.Builder(this).setTitle("Sleep timer")
                .setItems(options, (dialog, which) -> {
                    if (sleepTimer != null) {
                        sleepTimer.cancel();
                        sleepTimer = null;
                    }
                    if (which == 5) {
                        VideoPlaybackService.cancelSleepTimer();
                        toast("Sleep timer cancelled.");
                        return;
                    }
                    long millis = durations[which] * 60_000L;
                    if (controller == null || !controller.isPlaying()) {
                        toast("Sleep timer চালু করতে আগে ভিডিও Play করুন।");
                        return;
                    }
                    if (!VideoPlaybackService.scheduleSleepTimer(millis)) {
                        toast("Video playback service is not ready. Start a video first.");
                        return;
                    }
                    sleepTimer = new CountDownTimer(millis, 1000L) {
                        @Override public void onTick(long remaining) {
                            statusText.setText("Sleep timer: " + (remaining / 60_000L) + "m " +
                                    ((remaining / 1000L) % 60L) + "s");
                        }
                        @Override public void onFinish() {
                            statusText.setText("Sleep timer finished. Background playback stopped.");
                            sleepTimer = null;
                        }
                    }.start();
                }).show();
    }

    private void toggleScreenLock() {
        screenLocked = !screenLocked;
        playerView.setUseController(!screenLocked);
        toast(screenLocked ? "Player controls locked. Use the button below to unlock." : "Player controls unlocked.");
    }

    private void setFullScreen(boolean enabled) {
        if (rootPage == null || body == null || videoCard == null || playerView == null
                || fullScreen == enabled) return;
        fullScreen = enabled;
        if (enabled && screenLocked) {
            screenLocked = false;
            playerView.setUseController(true);
        }
        View header = rootPage.getChildAt(0);
        if (enabled) {
            if (header != null) header.setVisibility(View.GONE);
            for (int i = 0; i < body.getChildCount(); i++) {
                View child = body.getChildAt(i);
                if (child != videoCard) child.setVisibility(View.GONE);
            }
            rootPage.setPadding(0, 0, 0, 0);
            body.setPadding(0, 0, 0, 0);
            videoCard.setPadding(0, 0, 0, 0);
            videoCard.setBackgroundColor(Color.BLACK);
            LinearLayout.LayoutParams cardParams =
                    (LinearLayout.LayoutParams) videoCard.getLayoutParams();
            cardParams.height = -1;
            cardParams.topMargin = 0;
            videoCard.setLayoutParams(cardParams);
            LinearLayout.LayoutParams playerParams =
                    (LinearLayout.LayoutParams) playerView.getLayoutParams();
            playerParams.height = -1;
            playerView.setLayoutParams(playerParams);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else {
            if (header != null) header.setVisibility(View.VISIBLE);
            for (int i = 0; i < body.getChildCount(); i++) {
                View child = body.getChildAt(i);
                child.setVisibility(child == playerTools && inPictureInPicture
                        ? View.GONE : View.VISIBLE);
            }
            rootPage.setPadding(Ui.dp(this, 18), Ui.dp(this, 14),
                    Ui.dp(this, 18), Ui.dp(this, 22));
            body.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
            videoCard.setPadding(Ui.dp(this, 16), Ui.dp(this, 16),
                    Ui.dp(this, 16), Ui.dp(this, 16));
            if (originalVideoCardBackground != null) videoCard.setBackground(originalVideoCardBackground);
            LinearLayout.LayoutParams cardParams =
                    (LinearLayout.LayoutParams) videoCard.getLayoutParams();
            cardParams.height = -2;
            cardParams.topMargin = Ui.dp(this, 14);
            videoCard.setLayoutParams(cardParams);
            LinearLayout.LayoutParams playerParams =
                    (LinearLayout.LayoutParams) playerView.getLayoutParams();
            playerParams.height = Ui.dp(this, 232);
            playerView.setLayoutParams(playerParams);
            getWindow().getDecorView().setSystemUiVisibility(originalSystemUiVisibility);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
        playerView.setFullscreenButtonState(enabled);
    }

    private void toggleOrientation() {
        landscape = !landscape;
        setRequestedOrientation(landscape
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void enterPictureInPicture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            toast("Picture-in-Picture requires Android 8.0 or later.");
            return;
        }
        if (controller == null || !controller.isPlaying()) {
            toast("আগে ভিডিও চালু করুন।");
            return;
        }
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            toast("এই ডিভাইসে Picture-in-Picture সমর্থিত নয়।");
            return;
        }
        try {
            wasFullScreenBeforePip = fullScreen;
            if (!fullScreen) setFullScreen(true);
            PictureInPictureParams.Builder builder =
                    new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) builder.setAutoEnterEnabled(true);
            boolean entered = enterPictureInPictureMode(builder.build());
            if (!entered && !wasFullScreenBeforePip) setFullScreen(false);
        } catch (IllegalStateException | IllegalArgumentException error) {
            if (!wasFullScreenBeforePip) setFullScreen(false);
            toast("Picture-in-Picture চালু করা যায়নি।");
        }
    }

    @Override public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                && controller != null && controller.isPlaying()
                && getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            try {
                wasFullScreenBeforePip = fullScreen;
                if (!fullScreen) setFullScreen(true);
                boolean entered = enterPictureInPictureMode(new PictureInPictureParams.Builder()
                        .setAspectRatio(new Rational(16, 9)).build());
                if (!entered && !wasFullScreenBeforePip) setFullScreen(false);
            } catch (RuntimeException ignored) {
                if (!wasFullScreenBeforePip) setFullScreen(false);
            }
        }
    }

    @Override public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        inPictureInPicture = isInPictureInPictureMode;
        if (inPictureInPicture) {
            if (playerTools != null) playerTools.setVisibility(View.GONE);
        } else {
            if (!wasFullScreenBeforePip && fullScreen) {
                setFullScreen(false);
            } else if (playerTools != null) {
                playerTools.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
            }
            wasFullScreenBeforePip = false;
        }
    }

    private void stopPlayback() {
        VideoPlaybackService.cancelSleepTimer();
        if (sleepTimer != null) {
            sleepTimer.cancel();
            sleepTimer = null;
        }
        if (controller != null) {
            saveResumePoint();
            controller.stop();
            controller.clearMediaItems();
            statusText.setText("Playback stopped.");
            nowPlayingText.setText("No video selected");
        }
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    private String formatTime(long millis) {
        if (millis < 0 || millis == C.TIME_UNSET) return "--:--";
        long totalSeconds = millis / 1000L;
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        return hours > 0
                ? String.format(java.util.Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
                : String.format(java.util.Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    @Override protected void onPause() {
        saveResumePoint();
        super.onPause();
    }

    @Override protected void onStop() {
        activityStarted = false;
        handler.removeCallbacks(savePositionRunnable);
        saveResumePoint();
        if (controller != null) {
            controller.removeListener(playerListener);
            playerView.setKeepScreenOn(false);
            playerView.setPlayer(null);
            controller = null;
        }
        if (controllerFuture != null) {
            MediaController.releaseFuture(controllerFuture);
            controllerFuture = null;
        }
        super.onStop();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(savePositionRunnable);
        if (sleepTimer != null) sleepTimer.cancel();
        super.onDestroy();
    }

    private static final class TrackChoice {
        final Tracks.Group group;
        final int trackIndex;
        final String label;
        final boolean off;

        TrackChoice(Tracks.Group group, int trackIndex, String label, boolean off) {
            this.group = group;
            this.trackIndex = trackIndex;
            this.label = label;
            this.off = off;
        }

        static TrackChoice off() {
            return new TrackChoice(null, -1, "Off", true);
        }
    }
}
