package com.smarttoolbox.pro;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;

public final class MessageScheduleReceiver extends BroadcastReceiver {
    static final String EXTRA_SCHEDULE_ID = "sr_schedule_id";
    static final String EXTRA_PRE_ALERT = "sr_pre_send_notice";
    static final String EXTRA_EXPECTED_DUE = "sr_expected_due";
    private static final String CHANNEL_ID = "sr_whatsapp_schedule";

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra(EXTRA_SCHEDULE_ID);
        if (id == null || id.isEmpty()) return;
        if (intent.getBooleanExtra(EXTRA_PRE_ALERT, false)) {
            MessageScheduleStore.Item pending = MessageScheduleStore.get(context, id);
            if (pending != null && MessageScheduleStore.STATUS_PENDING.equals(pending.status)
                    && pending.scheduledAtMillis == intent.getLongExtra(EXTRA_EXPECTED_DUE, -1L)) {
                ScheduledWhatsAppAccessibilityService.preview(context, pending);
            }
            return;
        }
        MessageScheduleStore.Item item = MessageScheduleStore.onAlarmTriggered(context, id);
        if (item != null && !ScheduledWhatsAppAccessibilityService.sendWhenDue(context, item)) {
            showReminder(context, item);
        }
    }

    static void showReminder(Context context, MessageScheduleStore.Item item) {
        try {
            NotificationManager manager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    && manager.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "WhatsApp scheduled messages",
                        NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("Reminders for messages scheduled from SR Smart Toolbox Pro.");
                manager.createNotificationChannel(channel);
            }

            String url = MessageScheduleLogic.buildWhatsAppUrl(item.phone, item.message);
            Intent openWhatsApp = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            openWhatsApp.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent openPending = PendingIntent.getActivity(
                    context, item.alarmId + 1, openWhatsApp,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Intent viewSchedule = new Intent(context, MessageSchedulerActivity.class);
            viewSchedule.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent viewPending = PendingIntent.getActivity(
                    context, item.alarmId + 2, viewSchedule,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            String title = "WhatsApp message is due";
            String recipient = item.contactName.isEmpty() ? item.phone : item.contactName;
            String text = "সময় হয়েছে: " + recipient + " · WhatsApp খুলে Send চাপুন।";

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new NotificationCompat.BigTextStyle()
                            .bigText(text + "\n\n" + MessageScheduleLogic.messagePreview(item.message, 180)))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .setContentIntent(openPending)
                    .addAction(android.R.drawable.ic_menu_send, "Open WhatsApp", openPending)
                    .addAction(android.R.drawable.ic_menu_agenda, "View schedule", viewPending);

            manager.notify(item.alarmId, builder.build());
        } catch (Exception ignored) {
            // The schedule remains saved; the user can still open it from the Scheduler screen.
        }
    }
}
