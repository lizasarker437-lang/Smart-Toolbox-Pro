package com.smarttoolbox.pro;

/** Pure-Java gesture decisions shared by Home, other apps and in-app overlay UI. */
final class FloatingBarGestureLogic {
    /** A quick slide opens controls; a long hold deliberately drags the round bubble. */
    static final long HOLD_TO_DRAG_MS = 450L;
    static final long SWIPE_MAX_MS = 700L;

    private FloatingBarGestureLogic() { }

    static boolean qualifiesAsSlide(float dx, float dy, int thresholdPx) {
        float threshold = Math.max(1, thresholdPx);
        return Math.max(Math.abs(dx), Math.abs(dy)) >= threshold;
    }

    /** The edge tab is not draggable: any swipe over its touch target is a menu gesture. */
    static boolean edgeSwipe(float dx, float dy, int thresholdPx) {
        return qualifiesAsSlide(dx, dy, thresholdPx);
    }

    /** Quick inward or vertical slide on the full bubble opens controls, not a drag. */
    static boolean bubbleSwipe(boolean onLeftHalf, float dx, float dy,
                               long durationMs, int thresholdPx) {
        if (durationMs < 0L || durationMs > SWIPE_MAX_MS
                || !qualifiesAsSlide(dx, dy, thresholdPx)) return false;
        boolean inward = onLeftHalf ? dx > 0f : dx < 0f;
        return inward && Math.abs(dx) >= Math.abs(dy) * .7f
                || Math.abs(dy) > Math.abs(dx) * 1.15f;
    }

    /** An intentional long press then move keeps the movable icon feature. */
    static boolean canDrag(long elapsedMs) { return elapsedMs >= HOLD_TO_DRAG_MS; }

    /** Edge tap or finished slide reliably opens; never require a strict direction. */
    static boolean shouldOpenEdgeOnRelease(boolean touched, boolean panelEnabled) {
        return touched && panelEnabled;
    }
}
