package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.audiofx.LoudnessEnhancer;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;

public class SystemAudioBoostService extends Service {
    public static final String ACTION_START = "com.smarttoolbox.pro.SYSTEM_AUDIO_START";
    public static final String ACTION_UPDATE = "com.smarttoolbox.pro.SYSTEM_AUDIO_UPDATE";
    public static final String ACTION_STOP = "com.smarttoolbox.pro.SYSTEM_AUDIO_STOP";
    public static final String EXTRA_GAIN_MB = "system_gain_millibels";

    private static final String CHANNEL_ID = "system_audio_boost";
    private static final int NOTIFICATION_ID = 2404;
    private static final int MAX_GAIN_MB = 1000;

    private LoudnessEnhancer enhancer;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopBoost(startId);
            return START_NOT_STICKY;
        }

        int gainMb = intent == null ? 0
                : Math.max(0, Math.min(MAX_GAIN_MB, intent.getIntExtra(EXTRA_GAIN_MB, 0)));
        startAsForeground("Applying global audio processing…");

        try {
            if (enhancer == null) {
                // Session 0 asks Android's audio framework for the global output mix.
                // This is deprecated / blocked on some devices, so every failure is handled.
                enhancer = new LoudnessEnhancer(0);
            }
            if (!enhancer.hasControl()) {
                throw new IllegalStateException("The device did not grant control of the global audio effect.");
            }
            enhancer.setTargetGain(gainMb);
            enhancer.setEnabled(true);

            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("audio.active", true)
                    .putInt("audio.gain", gainMb)
                    .putBoolean("audio.unsupported", false)
                    .putString("audio.status", "Global audio boost is active on this device.")
                    .apply();

            String level = String.format(java.util.Locale.getDefault(), "+%.1f dB", gainMb / 100f);
            updateNotification("Global audio boost active · " + level);
            if (FloatingControlService.hasOverlayPermission(this)) {
                FloatingControlService.start(this);
            }
            return START_STICKY;
        } catch (Exception error) {
            releaseEnhancer();
            String message = error.getMessage();
            if (message == null || message.trim().isEmpty()) {
                message = "This phone does not allow a global audio effect.";
            }
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("audio.active", false)
                    .putBoolean("audio.unsupported", true)
                    .putString("audio.status", "Global audio boost is not supported: " + message)
                    .apply();
            Toast.makeText(this,
                    "Global audio boost is not supported on this device.",
                    Toast.LENGTH_LONG).show();
            stopForeground(true);
            stopSelf(startId);
            FloatingControlService.refresh(this);
            return START_NOT_STICKY;
        }
    }

    private void stopBoost(int startId) {
        releaseEnhancer();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("audio.active", false)
                .putString("audio.status", "Global audio boost is off.")
                .apply();
        stopForeground(true);
        stopSelf(startId);
        FloatingControlService.refresh(this);
    }

    private void releaseEnhancer() {
        if (enhancer != null) {
            try { enhancer.setEnabled(false); } catch (Exception ignored) {}
            try { enhancer.release(); } catch (Exception ignored) {}
            enhancer = null;
        }
    }

    private void startAsForeground(String message) {
        Notification notification = buildNotification(message);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "System-wide audio boost", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows while global audio processing is enabled.");
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String message) {
        Intent stopIntent = new Intent(this, SystemAudioBoostService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 2404, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("System-wide Extra Volume")
                .setContentText(message)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Turn off", stopPending)
                .build();
    }

    private void updateNotification(String message) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(message));
    }

    @Override public void onDestroy() {
        releaseEnhancer();
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        if (prefs.getBoolean("audio.active", false)) {
            prefs.edit().putBoolean("audio.active", false)
                    .putString("audio.status", "Global audio processing stopped by Android or the system.")
                    .apply();
        }
        super.onDestroy();
        FloatingControlService.refresh(this);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
