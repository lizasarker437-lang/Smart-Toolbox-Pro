package com.smarttoolbox.pro;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Opens Android's real notification controls for the SR Smart Toolbox app/channels.
 * Notification importance belongs to the USER on Android 8+; changing a channel
 * in-app after it is created does not override the user's notification settings.
 */
public class NotificationControlsActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1209;
    private static final String[] CHANNEL_IDS = {
            "floating_controls", "night_overlay", "thermal_monitor", "system_audio_boost"
    };
    private static final String[] CHANNEL_NAMES = {
            "Floating Icon / Sidebar", "Night Screen", "Temperature Monitor", "Extra Volume & Equalizer"
    };
    private TextView statusLabel;
    private final TextView[] channelStatus = new TextView[CHANNEL_IDS.length];

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = Ui.page(this, "Notification Controls");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body,
                "Control SR Smart Toolbox's notifications in your phone's notification bar. "
                        + "Notification permissions and channel alerts are managed by Android.",
                14, Ui.MUTED, false, 2);

        LinearLayout appCard = Ui.card(this);
        Ui.addText(this, appCard, "App notifications", 18, Ui.TEXT, true, 0);
        statusLabel = Ui.addText(this, appCard, "Checking notification permission…",
                13, Ui.MUTED, false, 8);
        addButton(appCard, "Allow notifications (Android 13+)", this::requestNotificationPermission);
        addButton(appCard, "Open app notification settings", this::openAppNotificationSettings);
        addButton(appCard, "Manage notifications from other apps (Android Settings)",
                this::openAllAppNotificationSettings);
        Ui.addCard(this, body, appCard, 14);

        Ui.addText(this, body, "Notification types", 18, Ui.TEXT, true, 20);
        for (int i = 0; i < CHANNEL_IDS.length; i++) {
            final int channelIndex = i;
            LinearLayout card = Ui.card(this);
            Ui.addText(this, card, CHANNEL_NAMES[i], 16, Ui.TEXT, true, 0);
            channelStatus[i] = Ui.addText(this, card, "Checking this notification type…",
                    12, Ui.MUTED, false, 5);
            addButton(card, "Manage " + CHANNEL_NAMES[i],
                    () -> openChannelSettings(CHANNEL_IDS[channelIndex]));
            Ui.addCard(this, body, card, 10);
        }

        LinearLayout note = Ui.card(this);
        Ui.addText(this, note, "Important", 16, Ui.ACCENT, true, 0);
        Ui.addText(this, note,
                "Background features need ongoing foreground-service notifications. "
                        + "Android may still show active services in its task manager even if you "
                        + "silence or hide their notification channel. Turning off a notification "
                        + "does not stop the feature. This page does not read or manage "
                        + "notifications belonging to other apps.",
                13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, note, 16);

        setContentView(page);
    }

    private void addButton(LinearLayout target, String label, Runnable action) {
        Button button = Ui.button(this, label, action);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = Ui.dp(this, 10);
        target.addView(button, params);
    }

    private NotificationManager getManager() {
        return (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    private void updateStatuses() {
        NotificationManager manager = getManager();
        // Make the four channels available for user control before a feature is started.
        // On Android, re-creating a channel does not override user-selected importance.
        if (manager != null) {
            for (int i = 0; i < CHANNEL_IDS.length; i++) {
                if (manager.getNotificationChannel(CHANNEL_IDS[i]) == null) {
                    NotificationChannel channel = new NotificationChannel(
                            CHANNEL_IDS[i], CHANNEL_NAMES[i], NotificationManager.IMPORTANCE_LOW);
                    channel.setDescription("SR Smart Toolbox foreground-service status: " + CHANNEL_NAMES[i]);
                    manager.createNotificationChannel(channel);
                }
            }
        }
        boolean allowed = manager != null && manager.areNotificationsEnabled();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            allowed = false;
        }
        statusLabel.setText(allowed
                ? "Enabled · SR Smart Toolbox may display its notification types below."
                : "Notifications are not fully enabled. Use Allow or open Android notification settings.");

        for (int i = 0; i < CHANNEL_IDS.length; i++) {
            String message;
            if (manager == null) {
                message = "Notification service unavailable on this phone.";
            } else {
                NotificationChannel channel = manager.getNotificationChannel(CHANNEL_IDS[i]);
                if (channel == null) {
                    message = "Not created yet · Start the feature once to activate this channel.";
                } else if (channel.getImportance() == NotificationManager.IMPORTANCE_NONE) {
                    message = "Blocked in Android settings";
                } else {
                    int importance = channel.getImportance();
                    message = !allowed ? "App notifications blocked" :
                            (importance <= NotificationManager.IMPORTANCE_LOW
                                ? "Enabled · Silent / low priority" : "Enabled · Alerts allowed");
                }
            }
            channelStatus[i].setText(message);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS },
                    NOTIFICATION_PERMISSION_REQUEST);
        } else {
            Toast.makeText(this, "Use Android settings to manage notification alerts.",
                    Toast.LENGTH_SHORT).show();
            openAppNotificationSettings();
        }
    }

    private void openAppNotificationSettings() {
        try {
            Intent settings = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            settings.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(settings);
        } catch (Exception error) {
            openAppDetails();
        }
    }

    private void openAllAppNotificationSettings() {
        try {
            // Android 13+ supports a notification-filtered list of all installed apps.
            // This does not give SR Smart Toolbox access to read anybody's notifications.
            Intent settings = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    ? new Intent(Settings.ACTION_ALL_APPS_NOTIFICATION_SETTINGS)
                    : new Intent(Settings.ACTION_SETTINGS);
            startActivity(settings);
        } catch (Exception error) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                Toast.makeText(this, "Notification settings are unavailable.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openChannelSettings(String channelId) {
        try {
            NotificationManager manager = getManager();
            if (manager == null || manager.getNotificationChannel(channelId) == null) {
                Toast.makeText(this,
                        "Start this feature once to create the notification channel.",
                        Toast.LENGTH_LONG).show();
                openAppNotificationSettings();
                return;
            }
            Intent settings = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
            settings.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            settings.putExtra(Settings.EXTRA_CHANNEL_ID, channelId);
            startActivity(settings);
        } catch (Exception error) {
            openAppNotificationSettings();
        }
    }

    private void openAppDetails() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            Toast.makeText(this, "Notification settings are unavailable.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (statusLabel != null) updateStatuses();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                                      int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST) updateStatuses();
    }
}
