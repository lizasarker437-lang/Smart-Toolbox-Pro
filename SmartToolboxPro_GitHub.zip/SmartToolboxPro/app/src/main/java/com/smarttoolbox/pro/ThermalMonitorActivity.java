package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ThermalMonitorActivity extends Activity {
    private TextView batteryTemp;
    private TextView thermalStatus;
    private TextView note;
    private PowerManager power;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { updateBattery(intent); }
    };

    private final PowerManager.OnThermalStatusChangedListener thermalListener =
            status -> runOnUiThread(() -> updateThermalStatus(status));

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        power = (PowerManager) getSystemService(POWER_SERVICE);
        LinearLayout page = Ui.page(this, "Thermal Monitor");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body, "Monitor the temperature information Android makes available.", 14, Ui.MUTED, false, 2);

        LinearLayout tempCard = Ui.card(this);
        Ui.addText(this, tempCard, "Battery temperature", 17, Ui.TEXT, true, 0);
        batteryTemp = Ui.addText(this, tempCard, "Reading…", 34, Ui.GREEN, true, 12);
        Ui.addText(this, tempCard, "Reported by the phone's battery service.", 12, Ui.MUTED, false, 4);
        Ui.addCard(this, body, tempCard, 18);

        LinearLayout statusCard = Ui.card(this);
        Ui.addText(this, statusCard, "Android thermal status", 17, Ui.TEXT, true, 0);
        thermalStatus = Ui.addText(this, statusCard, "Checking…", 24, Ui.GREEN, true, 12);
        note = Ui.addText(this, statusCard, "", 13, Ui.MUTED, false, 6);
        Ui.addCard(this, body, statusCard, 12);

        LinearLayout actions = Ui.card(this);
        android.widget.Button start = Ui.button(this, "Start background monitoring", this::startMonitoring);
        actions.addView(start, new LinearLayout.LayoutParams(-1, -2));
        android.widget.Button stop = Ui.button(this, "Stop monitoring", this::stopMonitoring);
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, -2);
        stopParams.topMargin = Ui.dp(this, 8);
        actions.addView(stop, stopParams);
        Ui.addCard(this, body, actions, 16);

        LinearLayout explain = Ui.card(this);
        Ui.addText(this, explain, "What this monitor can read", 16, Ui.ACCENT, true, 0);
        Ui.addText(this, explain,
                "Android exposes battery temperature and a device-wide thermal state on supported phones. Direct CPU/GPU temperature sensors are restricted on many devices, so this app does not invent those readings. The floating ST icon lets you turn monitoring on or off from other apps.",
                13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, explain, 18);

        android.widget.Button permission = Ui.button(this, "Enable floating control permission", this::requestOverlayPermission);
        Ui.addCard(this, body, permission, 10);
        setContentView(page);
    }

    @Override protected void onResume() {
        super.onResume();
        if (getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("thermal.active", false)
                && FloatingControlService.hasOverlayPermission(this)) {
            FloatingControlService.refresh(this);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        Intent sticky = registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        receiverRegistered = true;
        if (sticky != null) updateBattery(sticky);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            power.addThermalStatusListener(thermalListener);
            updateThermalStatus(power.getCurrentThermalStatus());
        } else {
            thermalStatus.setText("Not supported on this Android version");
            note.setText("Thermal status API requires Android 10 or later.");
        }
    }

    @Override protected void onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(batteryReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && power != null) {
            try { power.removeThermalStatusListener(thermalListener); } catch (Exception ignored) {}
        }
        super.onStop();
    }

    private void requestOverlayPermission() {
        if (FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this, "Floating control permission is already enabled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void startMonitoring() {
        if (!FloatingControlService.hasOverlayPermission(this)) {
            requestOverlayPermission();
            Toast.makeText(this, "Allow Display over other apps, then tap Start monitoring again.", Toast.LENGTH_LONG).show();
            return;
        }
        android.content.Intent service = new Intent(this, ThermalMonitorService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putBoolean("thermal.active", true).apply();
        FloatingControlService.start(this);
        Toast.makeText(this, "Background thermal monitoring started.", Toast.LENGTH_SHORT).show();
    }

    private void stopMonitoring() {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putBoolean("thermal.active", false).apply();
        Intent service = new Intent(this, ThermalMonitorService.class);
        service.setAction(ThermalMonitorService.ACTION_STOP);
        startService(service);
        FloatingControlService.refresh(this);
        Toast.makeText(this, "Thermal monitoring stopped.", Toast.LENGTH_SHORT).show();
    }

    private void updateBattery(Intent intent) {
        int raw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        if (raw >= 0) {
            float c = raw / 10f;
            batteryTemp.setText(String.format(java.util.Locale.getDefault(), "%.1f °C", c));
            batteryTemp.setTextColor(c >= 45 ? 0xFFFF8A65 : (c >= 40 ? Ui.ACCENT : Ui.GREEN));
        } else batteryTemp.setText("Unavailable");
    }

    private void updateThermalStatus(int status) {
        String label;
        String description;
        int color = Ui.GREEN;
        if (status == PowerManager.THERMAL_STATUS_NONE) {
            label = "Normal · No throttling reported"; description = "Device is operating within its normal thermal range.";
        } else if (status == PowerManager.THERMAL_STATUS_LIGHT) {
            label = "Light"; description = "A small amount of thermal management may be active.";
        } else if (status == PowerManager.THERMAL_STATUS_MODERATE) {
            label = "Moderate"; description = "The device may reduce performance to manage heat."; color = Ui.ACCENT;
        } else if (status == PowerManager.THERMAL_STATUS_SEVERE) {
            label = "Severe"; description = "Reduce heavy usage and let the device cool down."; color = 0xFFFF8A65;
        } else if (status == PowerManager.THERMAL_STATUS_CRITICAL) {
            label = "Critical"; description = "Stop demanding tasks and cool the device immediately."; color = 0xFFFF5252;
        } else if (status == PowerManager.THERMAL_STATUS_EMERGENCY) {
            label = "Emergency"; description = "The device is in an emergency thermal state."; color = 0xFFFF5252;
        } else {
            label = "Shutdown threshold"; description = "The device reports an extreme thermal state."; color = 0xFFFF5252;
        }
        thermalStatus.setText(label);
        thermalStatus.setTextColor(color);
        note.setText(description);
    }
}
