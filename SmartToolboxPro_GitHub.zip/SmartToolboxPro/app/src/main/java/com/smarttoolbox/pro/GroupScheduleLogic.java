package com.smarttoolbox.pro;

/** A broadcast-style batch sends one-to-one WhatsApp messages sequentially, not a group chat. */
final class GroupScheduleLogic {
    static final int MIN_RECIPIENTS = 2;
    static final int MAX_RECIPIENTS = 20;
    static final long RECIPIENT_INTERVAL_MS = 60_000L;
    private GroupScheduleLogic() {}
    static boolean validCount(int count) { return count >= MIN_RECIPIENTS && count <= MAX_RECIPIENTS; }
    static long scheduledAt(long baseMillis, int zeroBasedIndex) {
        if (zeroBasedIndex < 0) return baseMillis;
        long offset = zeroBasedIndex > Long.MAX_VALUE / RECIPIENT_INTERVAL_MS
                ? Long.MAX_VALUE : zeroBasedIndex * RECIPIENT_INTERVAL_MS;
        return baseMillis > Long.MAX_VALUE - offset ? Long.MAX_VALUE : baseMillis + offset;
    }
    static boolean allTimesFuture(long baseMillis, int count, long nowMillis) {
        if (!validCount(count)) return false;
        long last = scheduledAt(baseMillis, count - 1);
        return baseMillis > nowMillis && baseMillis - nowMillis > 1000L
                && last > nowMillis && last - nowMillis > 1000L;
    }
    static String recipientPosition(int oneBasedIndex, int total) {
        int safeTotal = Math.max(1, total);
        int safeIndex = Math.max(1, Math.min(oneBasedIndex, safeTotal));
        return "👥 Group message · " + safeIndex + "/" + safeTotal;
    }
}
