package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.view.View;

/** Application-wide palette plus independent System/Light/Dark appearance mode. */
final class ThemeManager {
    static final int MODE_SYSTEM = 0;
    static final int MODE_LIGHT = 1;
    static final int MODE_DARK = 2;
    private static final String PREFS = "sr_theme_preferences";
    private static final String KEY = "chosen_theme";
    private static final String KEY_APPEARANCE = "appearance_mode";
    private ThemeManager() {}

    static int current(Context context) {
        return ThemePalette.safeIndex(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, 0));
    }
    static int appearanceMode(Context context) {
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        // Migration: the previous fifth preset was always light; preserve that choice
        // until the user explicitly selects System / Light / Dark in the new studio.
        if (!prefs.contains(KEY_APPEARANCE) && current(context) == 4) return MODE_LIGHT;
        int mode = prefs.getInt(KEY_APPEARANCE, MODE_SYSTEM);
        return mode < MODE_SYSTEM || mode > MODE_DARK ? MODE_SYSTEM : mode;
    }
    static boolean isLight(Context context) {
        int mode = appearanceMode(context);
        if (mode == MODE_LIGHT) return true;
        if (mode == MODE_DARK) return false;
        int night = context.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return night != Configuration.UI_MODE_NIGHT_YES;
    }
    static int styleKey(Context context) {
        return current(context) * 100 + appearanceMode(context) * 2 + (isLight(context) ? 1 : 0);
    }
    static int[] colors(Context context) { return ThemePalette.colors(current(context), isLight(context)); }
    static void initialize(Context context) { Ui.applyColors(colors(context)); }
    static void save(Context context, int index) {
        int valid = ThemePalette.safeIndex(index);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY, valid).apply();
        initialize(context);
        FloatingControlService.refresh(context);
    }
    static void saveAppearance(Context context, int mode) {
        int valid = mode < MODE_SYSTEM || mode > MODE_DARK ? MODE_SYSTEM : mode;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_APPEARANCE, valid).apply();
        initialize(context);
        FloatingControlService.refresh(context);
    }
    static void applyToActivity(Activity activity) {
        initialize(activity);
        activity.setTheme(isLight(activity) ? R.style.AppThemeLight : R.style.AppTheme);
        int flags = activity.getWindow().getDecorView().getSystemUiVisibility();
        flags = isLight(activity) ? flags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                : flags & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        activity.getWindow().getDecorView().setSystemUiVisibility(flags);
    }
}
