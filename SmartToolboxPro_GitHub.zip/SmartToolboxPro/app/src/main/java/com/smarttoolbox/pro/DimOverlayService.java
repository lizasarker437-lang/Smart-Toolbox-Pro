package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

public class DimOverlayService extends Service {
    public static final String ACTION_STOP = "com.smarttoolbox.pro.STOP_DIM";
    private static final String CHANNEL = "night_overlay";
    private static final int NOTIFICATION_ID = 2101;
    private WindowManager windowManager;
    private FrameLayout overlay;
    private View dimView;
    private View warmView;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            removeOverlay();
            getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", false).apply();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        int level = intent == null ? 35 : intent.getIntExtra("level", 35);
        boolean warm = intent != null && intent.getBooleanExtra("warm", false);
        showOverlay(level, warm);
        getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", true).apply();
        return START_STICKY;
    }

    private void showOverlay(int level, boolean warm) {
        if (overlay == null) {
            overlay = new FrameLayout(this);
            dimView = new View(this);
            warmView = new View(this);
            overlay.addView(dimView, new FrameLayout.LayoutParams(-1, -1));
            overlay.addView(warmView, new FrameLayout.LayoutParams(-1, -1));
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            try { windowManager.addView(overlay, params); }
            catch (Exception e) { overlay = null; return; }
        }
        dimView.setBackgroundColor(Color.BLACK);
        dimView.setAlpha(Math.max(0, Math.min(80, level)) / 100f);
        warmView.setBackgroundColor(Color.rgb(255, 164, 70));
        warmView.setAlpha(warm ? 0.10f : 0f);
    }

    private void removeOverlay() {
        if (overlay != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) {}
            overlay = null;
            dimView = null;
            warmView = null;
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Night Screen", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the screen dimming overlay active while you use other apps.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Night Screen is active")
                .setContentText("Tap Stop in Smart Toolbox Pro to remove the dimming overlay.")
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        removeOverlay();
        getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", false).apply();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
