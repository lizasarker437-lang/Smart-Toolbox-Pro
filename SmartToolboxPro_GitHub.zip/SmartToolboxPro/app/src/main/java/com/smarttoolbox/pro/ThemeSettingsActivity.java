package com.smarttoolbox.pro;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Smart global theme studio: independent appearance mode and palette selection. */
public final class ThemeSettingsActivity extends Activity {
    private static final String[] DESCRIPTIONS = {
            "SR signature · black and gold", "Navy surfaces · sky-blue accent",
            "Forest surfaces · mint accent", "Violet surfaces · lavender accent",
            "Clean neutral surfaces · blue accent", "Warm sunset · coral accent",
            "Modern graphite · cyan accent", "Soft rose · pink accent", "Arctic teal · mint accent"
    };
    private LinearLayout body;

    @Override public void onCreate(Bundle state) {
        ThemeManager.applyToActivity(this);
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        LinearLayout page = Ui.page(this, "🎨 Smart Theme Studio");
        body = Ui.content(page);
        buildContent();
        setContentView(page);
    }

    private void buildContent() {
        body.removeAllViews();
        Ui.addText(this, body, "Your app, your style", 23, Ui.TEXT, true, 4);
        Ui.addText(this, body,
                "এক জায়গা থেকে পুরো SR Smart Toolbox-এর রং এবং Light/Dark আচরণ নিয়ন্ত্রণ করুন। "
                        + "পরিবর্তন সংরক্ষিত হবে এবং অন্য স্ক্রিনে ফিরে গেলে প্রয়োগ হবে।",
                13, Ui.MUTED, false, 7);

        Ui.addText(this, body, "APPEARANCE MODE", 12, Ui.ACCENT, true, 20);
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        addModeButton(modes, "◐ System", ThemeManager.MODE_SYSTEM);
        addModeButton(modes, "☀ Light", ThemeManager.MODE_LIGHT);
        addModeButton(modes, "☾ Dark", ThemeManager.MODE_DARK);
        Ui.addCard(this, body, modes, 7);

        Ui.addText(this, body, "COLOR COLLECTION", 12, Ui.ACCENT, true, 20);
        Ui.addText(this, body, "একটি রঙের প্যালেট বেছে নিন। Appearance Mode আলাদাভাবে বদলানো যাবে।",
                12, Ui.MUTED, false, 4);
        int current = ThemeManager.current(this);
        for (int i = 0; i < ThemePalette.count(); i++) {
            final int selection = i;
            int[] colors = ThemePalette.colors(i, ThemeManager.isLight(this));
            LinearLayout card = Ui.card(this);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView sample = Ui.text(this, "SR", 17, colors[3], true);
            sample.setGravity(Gravity.CENTER);
            GradientDrawable sampleBg = new GradientDrawable();
            sampleBg.setColor(colors[0]);
            sampleBg.setCornerRadius(Ui.dp(this, 14));
            sampleBg.setStroke(Ui.dp(this, 2), colors[5]);
            sample.setBackground(sampleBg);
            row.addView(sample, new LinearLayout.LayoutParams(Ui.dp(this, 58), Ui.dp(this, 58)));

            LinearLayout labels = new LinearLayout(this);
            labels.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.leftMargin = Ui.dp(this, 12);
            row.addView(labels, lp);
            labels.addView(Ui.text(this, ThemePalette.name(i), 16, Ui.TEXT, true));
            labels.addView(Ui.text(this, DESCRIPTIONS[i], 12, Ui.MUTED, false));
            TextView selected = Ui.text(this, i == current ? "✓ Active" : "Preview", 12,
                    i == current ? Ui.GREEN : Ui.ACCENT, true);
            selected.setGravity(Gravity.CENTER);
            row.addView(selected);
            card.addView(row);

            LinearLayout swatches = new LinearLayout(this);
            swatches.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams swatchParams = new LinearLayout.LayoutParams(-1, Ui.dp(this, 12));
            swatchParams.topMargin = Ui.dp(this, 10);
            card.addView(swatches, swatchParams);
            for (int color : new int[]{colors[0], colors[1], colors[3], colors[5], colors[6]}) {
                View chip = new View(this);
                chip.setBackgroundColor(color);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, Ui.dp(this, 12), 1f);
                cp.rightMargin = Ui.dp(this, 4);
                swatches.addView(chip, cp);
            }
            card.setOnClickListener(v -> {
                ThemeManager.save(this, selection);
                recreate();
            });
            Ui.addCard(this, body, card, 10);
        }
        Button reset = Ui.button(this, "↺ Reset SR default theme", () -> {
            ThemeManager.save(this, 0);
            ThemeManager.saveAppearance(this, ThemeManager.MODE_SYSTEM);
            recreate();
        });
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = Ui.dp(this, 16);
        body.addView(reset, rp);
        Ui.addText(this, body,
                "Theme applies across the app when each screen is opened again. The video cinema player keeps its black playback canvas.",
                12, Ui.MUTED, false, 14);
    }

    private void addModeButton(LinearLayout row, String title, int mode) {
        boolean selected = ThemeManager.appearanceMode(this) == mode;
        Button button = Ui.button(this, (selected ? "✓ " : "") + title, () -> {
            ThemeManager.saveAppearance(this, mode);
            recreate();
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = Ui.dp(this, 3);
        p.rightMargin = Ui.dp(this, 3);
        row.addView(button, p);
    }
}
