package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        FloatingControlService.refresh(this);
        LinearLayout page = Ui.page(this, "Smart Toolbox Pro");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body, "One app. Four useful tools.", 15, Ui.MUTED, false, 2);

        LinearLayout hero = Ui.card(this);
        TextView badge = Ui.text(this, "SMART TOOLBOX  •  VERSION 1.2.4 ALPHA", 11, Ui.ACCENT, true);
        hero.addView(badge);
        TextView title = Ui.text(this, "Your everyday phone toolkit", 25, Ui.TEXT, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = Ui.dp(this, 12);
        hero.addView(title, tp);
        TextView sub = Ui.text(this, "Extra-dark screen dimming, master audio gain with equalizer and bass controls where supported, temperature monitoring and document scanning in one place.", 14, Ui.MUTED, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = Ui.dp(this, 8);
        hero.addView(sub, sp);
        Ui.addCard(this, body, hero, 18);

        addTool(body, "🌙", "Night Screen", "Dim the display and enable a warm screen filter.", NightScreenActivity.class);
        addTool(body, "🔊", "System-Wide Extra Volume", "Control master output gain, five-band equalizer, Bass Boost and spatial sound where the phone supports global effects.", VolumeBoosterActivity.class);
        addTool(body, "🌡️", "Thermal Monitor", "Check battery temperature and Android thermal status.", ThermalMonitorActivity.class);
        addTool(body, "📷", "Document Scanner", "Capture or import pages, export PDF and extract text.", DocumentScannerActivity.class);

        LinearLayout floatingCard = Ui.card(this);
        Ui.addText(this, floatingCard, "Floating Icon Settings", 18, Ui.TEXT, true, 0);
        Ui.addText(this, floatingCard,
                "Turn the floating sidebar ON or OFF independently of tool activity, enable or disable its 4-second edge auto-hide, change its size and opacity, and reset its position.",
                13, Ui.MUTED, false, 6);
        android.widget.Button floatingSettings = Ui.button(this, "Open Floating Icon Settings",
                () -> startActivity(new Intent(this, FloatingIconSettingsActivity.class)));
        LinearLayout.LayoutParams floatingButtonParams = new LinearLayout.LayoutParams(-1, -2);
        floatingButtonParams.topMargin = Ui.dp(this, 12);
        floatingCard.addView(floatingSettings, floatingButtonParams);
        Ui.addCard(this, body, floatingCard, 22);

        Ui.addText(this, body, "Floating sidebar controls", 17, Ui.TEXT, true, 18);
        Ui.addText(this, body, "The floating ST sidebar can stay available even when every tool is OFF. After your chosen delay, it tucks into a slim tab at the screen edge. Tap the tab to bring back the icon and quick controls. You can turn the sidebar on or off from Floating Icon Settings.", 13, Ui.MUTED, false, 6);

        Ui.addText(this, body, "Privacy first", 17, Ui.TEXT, true, 18);
        Ui.addText(this, body, "Scanned images and PDFs stay on your device unless you choose to share them. Permissions are requested only when a feature needs them.", 13, Ui.MUTED, false, 6);
        setContentView(page);
    }

    private void addTool(LinearLayout body, String icon, String name, String description, Class<?> target) {
        LinearLayout card = Ui.card(this);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView emoji = Ui.text(this, icon, 30, Ui.TEXT, false);
        row.addView(emoji, new LinearLayout.LayoutParams(Ui.dp(this, 48), -2));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView heading = Ui.text(this, name, 18, Ui.TEXT, true);
        labels.addView(heading);
        TextView detail = Ui.text(this, description, 13, Ui.MUTED, false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = Ui.dp(this, 4);
        labels.addView(detail, dp);
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = Ui.text(this, "›", 30, Ui.ACCENT, false);
        row.addView(arrow);
        card.addView(row);
        card.setOnClickListener(v -> startActivity(new Intent(this, target)));
        Ui.addCard(this, body, card, 12);
    }
}
