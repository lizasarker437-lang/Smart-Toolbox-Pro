package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AboutDeveloperActivity extends Activity {
    private static final String YOUTUBE_URL = "https://www.youtube.com/@SRCreation-farm";
    private static final String FACEBOOK_URL = "https://fb.com/srcreation.farm";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyToActivity(this);
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout page = Ui.page(this, "About the Developer");
        LinearLayout body = Ui.content(page);

        LinearLayout profile = Ui.card(this);
        TextView monogram = Ui.text(this, "SR", 42, Ui.ACCENT, true);
        monogram.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, Ui.dp(this, 92));
        profile.addView(monogram, logoParams);

        Ui.addText(this, profile, "Shahriar Rahman", 24, Ui.TEXT, true, 10);
        Ui.addText(this, profile, "Creator & Brand Owner", 15, Ui.ACCENT, true, 4);
        Ui.addText(this, profile, "SR Smart Toolbox Pro", 16, Ui.TEXT, true, 14);
        Ui.addText(this, profile,
                "A collection of practical Android tools, including Night Screen, system-wide audio controls, Thermal Monitor, QR / Barcode Scanner and SR Video Player.",
                14, Ui.MUTED, false, 6);
        Ui.addCard(this, body, profile, 12);

        LinearLayout social = Ui.card(this);
        Ui.addText(this, social, "Connect with SR Creation Farm", 18, Ui.TEXT, true, 0);
        Ui.addText(this, social, "YouTube: @SRCreation-farm", 14, Ui.MUTED, false, 8);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, -2);
        buttonParams.topMargin = Ui.dp(this, 12);
        android.widget.Button youtube = Ui.button(this, "Visit YouTube Channel",
                () -> openLink(YOUTUBE_URL));
        social.addView(youtube, buttonParams);

        Ui.addText(this, social, "Facebook: fb.com/srcreation.farm", 14, Ui.MUTED, false, 16);
        android.widget.Button facebook = Ui.button(this, "Visit Facebook Page",
                () -> openLink(FACEBOOK_URL));
        LinearLayout.LayoutParams facebookParams = new LinearLayout.LayoutParams(-1, -2);
        facebookParams.topMargin = Ui.dp(this, 12);
        social.addView(facebook, facebookParams);
        Ui.addCard(this, body, social, 14);

        LinearLayout credits = Ui.card(this);
        Ui.addText(this, credits, "App Credits", 17, Ui.TEXT, true, 0);
        Ui.addText(this, credits, "Created by Shahriar Rahman", 14, Ui.MUTED, false, 8);
        Ui.addText(this, credits, "© 2026 Shahriar Rahman. All rights reserved.", 12, Ui.MUTED, false, 8);
        Ui.addText(this, credits, "App: SR Smart Toolbox Pro  •  Version 1.5.5-alpha31",
                12, Ui.MUTED, false, 8);
        Ui.addCard(this, body, credits, 14);

        setContentView(page);
    }

    private void openLink(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        try {
            startActivity(Intent.createChooser(intent, "Open with"));
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(this, "No app is available to open this link.", Toast.LENGTH_LONG).show();
        }
    }
}
