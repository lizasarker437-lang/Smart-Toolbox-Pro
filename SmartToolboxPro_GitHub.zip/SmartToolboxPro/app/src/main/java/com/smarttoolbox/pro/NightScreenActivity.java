package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class NightScreenActivity extends Activity {
    private SeekBar dimSeek;
    private TextView amount;
    private Switch warmSwitch;
    private Switch keepOnSwitch;

    @Override public void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyToActivity(this);
        super.onCreate(savedInstanceState);
        LinearLayout page = Ui.page(this, "Night Screen");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body, "Make the display much darker with an adjustable black overlay.", 14, Ui.MUTED, false, 2);

        int savedLevel = getSharedPreferences("night", MODE_PRIVATE).getInt("level", 60);
        boolean savedWarm = getSharedPreferences("night", MODE_PRIVATE).getBoolean("warm", false);

        LinearLayout card = Ui.card(this);
        Ui.addText(this, card, "Extra-dark screen dimming", 19, Ui.TEXT, true, 0);
        amount = Ui.addText(this, card, "Dim level: " + savedLevel + "%", 14, Ui.ACCENT, true, 12);
        dimSeek = new SeekBar(this);
        dimSeek.setMax(95);
        dimSeek.setProgress(Math.max(0, Math.min(95, savedLevel)));
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(-1, -2);
        seekParams.topMargin = Ui.dp(this, 8);
        card.addView(dimSeek, seekParams);
        TextView hint = Ui.addText(this, card, "Up to 95% black overlay for an extra-dark view.", 12, Ui.MUTED, false, 5);
        dimSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                amount.setText("Dim level: " + progress + "%" + (progress >= 90 ? " · Extra dark" : ""));
                if (fromUser && isOverlayRunning()) updateOverlay();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        Ui.addCard(this, body, card, 18);

        LinearLayout controls = Ui.card(this);
        warmSwitch = new Switch(this);
        warmSwitch.setText("Blue light / warm filter");
        warmSwitch.setTextColor(Ui.TEXT);
        warmSwitch.setTextSize(16);
        warmSwitch.setChecked(savedWarm);
        controls.addView(warmSwitch);
        warmSwitch.setOnCheckedChangeListener((button, checked) -> {
            getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("warm", checked).apply();
            if (isOverlayRunning()) updateOverlay();
        });

        keepOnSwitch = new Switch(this);
        keepOnSwitch.setText("Keep screen on while this page is open");
        keepOnSwitch.setTextColor(Ui.TEXT);
        keepOnSwitch.setTextSize(15);
        LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(-1, -2);
        kp.topMargin = Ui.dp(this, 14);
        controls.addView(keepOnSwitch, kp);
        keepOnSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (checked) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
        Ui.addCard(this, body, controls, 12);

        TextView permissionInfo = Ui.addText(this, body,
                "The floating ST control appears over other apps while Night Screen is active. Android requires ‘Display over other apps’ permission. This app does not unlock or bypass the phone lock screen.",
                13, Ui.MUTED, false, 16);
        permissionInfo.setLineSpacing(Ui.dp(this, 2), 1f);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.Button start = Ui.button(this, "Start dimming", this::startDimming);
        android.widget.Button stop = Ui.button(this, "Turn off", this::stopDimming);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, -2, 1);
        ap.rightMargin = Ui.dp(this, 8);
        actions.addView(start, ap);
        actions.addView(stop, new LinearLayout.LayoutParams(0, -2, 1));
        Ui.addCard(this, body, actions, 18);

        android.widget.Button permission = Ui.button(this, "Grant floating / overlay permission", this::requestOverlayPermission);
        Ui.addCard(this, body, permission, 10);
        setContentView(page);
    }

    @Override protected void onResume() {
        super.onResume();
        if (dimSeek != null && isOverlayRunning()) {
            amount.setText("Dim level: " + dimSeek.getProgress() + "%  ·  Active");
            if (FloatingControlService.hasOverlayPermission(this)) FloatingControlService.refresh(this);
        }
    }

    private boolean isOverlayRunning() {
        return getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
    }

    private void requestOverlayPermission() {
        if (FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this, "Overlay permission is already enabled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }

    private void startDimming() {
        if (!FloatingControlService.hasOverlayPermission(this)) {
            requestOverlayPermission();
            Toast.makeText(this, "Allow Display over other apps, then tap Start dimming again.", Toast.LENGTH_LONG).show();
            return;
        }
        int level = dimSeek.getProgress();
        boolean warm = warmSwitch.isChecked();
        getSharedPreferences("night", MODE_PRIVATE).edit()
                .putInt("level", level).putBoolean("warm", warm).putBoolean("active", true).apply();

        Intent i = new Intent(this, DimOverlayService.class);
        i.putExtra("level", level);
        i.putExtra("warm", warm);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
        FloatingControlService.start(this);
    }

    private void updateOverlay() {
        int level = dimSeek.getProgress();
        boolean warm = warmSwitch.isChecked();
        getSharedPreferences("night", MODE_PRIVATE).edit()
                .putInt("level", level).putBoolean("warm", warm).apply();
        Intent i = new Intent(this, DimOverlayService.class);
        i.putExtra("level", level);
        i.putExtra("warm", warm);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
    }

    private void stopDimming() {
        getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", false).apply();
        Intent i = new Intent(this, DimOverlayService.class);
        i.setAction(DimOverlayService.ACTION_STOP);
        startService(i);
        FloatingControlService.refresh(this);
    }
}
