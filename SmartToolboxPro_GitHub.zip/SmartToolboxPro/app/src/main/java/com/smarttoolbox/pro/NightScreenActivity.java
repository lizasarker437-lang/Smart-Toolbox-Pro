package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class NightScreenActivity extends Activity {
    private SeekBar dimSeek;
    private TextView amount;
    private Switch warmSwitch;
    private Switch keepOnSwitch;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = Ui.page(this, "Night Screen");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body, "Give your eyes a more comfortable screen at night.", 14, Ui.MUTED, false, 2);

        LinearLayout card = Ui.card(this);
        Ui.addText(this, card, "Screen dimming", 19, Ui.TEXT, true, 0);
        amount = Ui.addText(this, card, "Dim level: 35%", 14, Ui.ACCENT, true, 12);
        dimSeek = new SeekBar(this);
        dimSeek.setMax(80);
        dimSeek.setProgress(35);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(-1, -2);
        seekParams.topMargin = Ui.dp(this, 8);
        card.addView(dimSeek, seekParams);
        dimSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                amount.setText("Dim level: " + progress + "%");
                if (fromUser && isOverlayRunning()) updateOverlay();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        Ui.addCard(this, body, card, 18);

        LinearLayout controls = Ui.card(this);
        warmSwitch = new Switch(this);
        warmSwitch.setText("Blue light / warm filter");
        warmSwitch.setTextColor(Ui.TEXT);
        warmSwitch.setTextSize(16);
        controls.addView(warmSwitch);
        warmSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (isOverlayRunning()) updateOverlay();
        });
        keepOnSwitch = new Switch(this);
        keepOnSwitch.setText("Keep screen on while this page is open");
        keepOnSwitch.setTextColor(Ui.TEXT);
        keepOnSwitch.setTextSize(15);
        LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(-1, -2);
        kp.topMargin = Ui.dp(this, 14);
        controls.addView(keepOnSwitch, kp);
        keepOnSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (checked) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
        Ui.addCard(this, body, controls, 12);

        TextView permissionInfo = Ui.addText(this, body,
                "Screen dimming uses an on-screen overlay. Android requires you to approve the ‘Display over other apps’ permission. The app does not unlock or bypass your phone lock screen.",
                13, Ui.MUTED, false, 16);
        permissionInfo.setLineSpacing(Ui.dp(this, 2), 1f);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.Button start = Ui.button(this, "Start dimming", this::startDimming);
        android.widget.Button stop = Ui.button(this, "Stop", this::stopDimming);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, -2, 1);
        ap.rightMargin = Ui.dp(this, 8);
        actions.addView(start, ap);
        actions.addView(stop, new LinearLayout.LayoutParams(0, -2, 1));
        Ui.addCard(this, body, actions, 18);

        android.widget.Button permission = Ui.button(this, "Grant overlay permission", () -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });
        Ui.addCard(this, body, permission, 10);
        setContentView(page);
    }

    @Override protected void onResume() {
        super.onResume();
        if (dimSeek != null) {
            boolean active = isOverlayRunning();
            if (active) amount.setText("Dim level: " + dimSeek.getProgress() + "%  •  Active");
        }
    }

    private boolean isOverlayRunning() {
        return getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
    }

    private void startDimming() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        Intent i = new Intent(this, DimOverlayService.class);
        i.putExtra("level", dimSeek.getProgress());
        i.putExtra("warm", warmSwitch.isChecked());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
        getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", true).apply();
    }

    private void updateOverlay() {
        Intent i = new Intent(this, DimOverlayService.class);
        i.putExtra("level", dimSeek.getProgress());
        i.putExtra("warm", warmSwitch.isChecked());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
    }

    private void stopDimming() {
        Intent i = new Intent(this, DimOverlayService.class);
        i.setAction(DimOverlayService.ACTION_STOP);
        startService(i);
        getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", false).apply();
    }
}
