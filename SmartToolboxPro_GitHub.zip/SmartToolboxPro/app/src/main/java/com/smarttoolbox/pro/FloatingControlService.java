package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class FloatingControlService extends Service {
    public static final String ACTION_SHOW = "com.smarttoolbox.pro.FLOAT_SHOW";
    public static final String ACTION_REFRESH = "com.smarttoolbox.pro.FLOAT_REFRESH";
    public static final String ACTION_HIDE = "com.smarttoolbox.pro.FLOAT_HIDE";

    private static final String CHANNEL_ID = "floating_controls";
    private static final int NOTIFICATION_ID = 2401;

    private WindowManager windowManager;
    private TextView bubble;
    private ScrollView panel;
    private LinearLayout panelContent;
    private TextView edgeHandle;
    private TextView thermalReadout;
    private WindowManager.LayoutParams edgeParams;
    private Runnable thermalReadoutRunnable;
    private Runnable brightnessPermissionRunnable;
    private final Handler sliderHandler = new Handler(Looper.getMainLooper());
    private final Handler autoHideHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingNightUpdate;
    private Runnable pendingAudioUpdate;
    private Runnable autoHideRunnable;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private boolean autoHidden;
    private int touchSlop;
    private float downRawX;
    private float downRawY;
    private int downX;
    private int downY;
    private boolean dragged;

    public static boolean hasOverlayPermission(Context context) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context);
    }

    public static boolean start(Context context) {
        if (!hasOverlayPermission(context)) return false;
        android.content.SharedPreferences prefs = context.getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.getBoolean("floating.enabled", true)) return false;
        prefs.edit().putBoolean("floating.hidden", false)
                .putBoolean("floating.auto_hidden", false).apply();
        Intent intent = new Intent(context, FloatingControlService.class);
        intent.setAction(ACTION_SHOW);
        ContextCompat.startForegroundService(context, intent);
        return true;
    }

    public static void refresh(Context context) {
        Intent intent = new Intent(context, FloatingControlService.class);
        intent.setAction(ACTION_REFRESH);
        android.content.SharedPreferences prefs = context.getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean hidden = prefs.getBoolean("floating.hidden", false);
        boolean enabled = prefs.getBoolean("floating.enabled", true);
        // The floating sidebar is an independent user-controlled feature.
        // It remains available even when every toolbox feature is OFF.
        if (hidden || !enabled || !hasOverlayPermission(context)) {
            context.stopService(new Intent(context, FloatingControlService.class));
        } else {
            ContextCompat.startForegroundService(context, intent);
        }
    }

    public static boolean anyFeatureActive(Context context) {
        boolean night = context.getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        boolean thermal = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("thermal.active", false);
        boolean audio = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("audio.active", false);
        boolean scanner = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("scanner.active", false);
        return night || thermal || audio || scanner;
    }

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_REFRESH : intent.getAction();

        if (ACTION_HIDE.equals(action)) {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("floating.hidden", true).putBoolean("floating.enabled", false).apply();
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (!hasOverlayPermission(this)) {
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification());
        }

        android.content.SharedPreferences floatingPrefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean hidden = floatingPrefs.getBoolean("floating.hidden", false);
        boolean enabled = floatingPrefs.getBoolean("floating.enabled", true);
        if (hidden || !enabled) {
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        boolean panelWasOpen = panel != null;
        boolean autoHideEnabled = floatingPrefs.getBoolean("floating.auto_hide", true);
        boolean savedAsAutoHidden = floatingPrefs.getBoolean("floating.auto_hidden", false);

        // Preserve the edge tab across ordinary refreshes and service restarts.
        // ACTION_SHOW is an explicit request to reveal the full icon.
        if (savedAsAutoHidden && autoHideEnabled && !ACTION_SHOW.equals(action)) {
            if (edgeHandle != null && bubble == null) return START_STICKY;
            removePanelAndBubble();
            autoHidden = true;
            showEdgeHandleFromSavedPosition();
            return START_STICKY;
        }

        if (ACTION_SHOW.equals(action) || !autoHideEnabled) {
            floatingPrefs.edit().putBoolean("floating.auto_hidden", false).apply();
            autoHidden = false;
        }

        boolean nightIsActive = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        if ((ACTION_SHOW.equals(action) || ACTION_REFRESH.equals(action) || nightIsActive) && bubble != null) {
            // Re-add after settings changes or Night Screen overlay so size, opacity and z-order refresh.
            removePanelAndBubble();
        }
        ensureBubble();
        if (panelWasOpen && getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.panel.enabled", true)) showPanel();
        return START_STICKY;
    }

    private void ensureBubble() {
        if (bubble != null) return;
        cancelAutoHide();
        removeEdgeHandle();
        autoHidden = false;
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.auto_hidden", false).apply();

        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        int sizeDp = Math.max(24, Math.min(76, prefs.getInt("floating.size", 54)));
        int opacity = Math.max(30, Math.min(100, prefs.getInt("floating.opacity", 100)));

        bubble = new TextView(this);
        bubble.setText("ST");
        bubble.setContentDescription("Smart Toolbox floating controls. Tap to open, drag to move.");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(Math.max(12, Math.min(18, sizeDp * 0.28f)));
        bubble.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(255, 166, 35));
        circle.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(circle);
        bubble.setAlpha(opacity / 100f);
        bubble.setElevation(dp(8));

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int sizePx = dp(sizeDp);
        bubbleParams = new WindowManager.LayoutParams(
                sizePx, sizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;

        int savedX = prefs.getInt("floating.x", -1);
        int savedY = prefs.getInt("floating.y", -1);
        bubbleParams.x = savedX >= 0
                ? Math.max(0, Math.min(metrics.widthPixels - sizePx, savedX))
                : Math.max(dp(8), metrics.widthPixels - sizePx - dp(14));
        bubbleParams.y = savedY >= 0
                ? Math.max(0, Math.min(metrics.heightPixels - sizePx, savedY))
                : Math.max(dp(90), metrics.heightPixels / 3);

        bubble.setOnTouchListener((view, event) -> handleBubbleTouch(event));
        try {
            windowManager.addView(bubble, bubbleParams);
            scheduleAutoHide();
        } catch (Exception e) {
            bubble = null;
            bubbleParams = null;
            stopSelf();
        }
    }

    private boolean handleBubbleTouch(MotionEvent event) {
        if (bubbleParams == null) return true;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                cancelAutoHide();
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                downX = bubbleParams.x;
                downY = bubbleParams.y;
                dragged = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                int dx = (int) (event.getRawX() - downRawX);
                int dy = (int) (event.getRawY() - downRawY);
                if (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop) dragged = true;
                if (dragged) {
                    DisplayMetrics metrics = new DisplayMetrics();
                    windowManager.getDefaultDisplay().getMetrics(metrics);
                    bubbleParams.x = Math.max(0, Math.min(metrics.widthPixels - bubbleParams.width, downX + dx));
                    bubbleParams.y = Math.max(0, Math.min(metrics.heightPixels - bubbleParams.height, downY + dy));
                    try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragged && bubbleParams != null) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("floating.x", bubbleParams.x)
                            .putInt("floating.y", bubbleParams.y).apply();
                } else if (getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getBoolean("floating.panel.enabled", true)) {
                    showPanel();
                } else {
                    scheduleAutoHide();
                }
                if (dragged) scheduleAutoHide();
                return true;
            case MotionEvent.ACTION_CANCEL:
                scheduleAutoHide();
                return true;
            default:
                return true;
        }
    }

    private boolean isAutoHideEnabled() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.auto_hide", true);
    }

    private void cancelAutoHide() {
        if (autoHideRunnable != null) {
            autoHideHandler.removeCallbacks(autoHideRunnable);
            autoHideRunnable = null;
        }
    }

    private void scheduleAutoHide() {
        cancelAutoHide();
        if (!isAutoHideEnabled() || bubble == null || panel != null) return;
        autoHideRunnable = this::hideBubbleToEdge;
        int delaySeconds = Math.max(1, Math.min(60,
                getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getInt("floating.auto_hide_seconds", 4)));
        autoHideHandler.postDelayed(autoHideRunnable, delaySeconds * 1000L);
    }

    private void hideBubbleToEdge() {
        autoHideRunnable = null;
        if (bubble == null || bubbleParams == null || panel != null || !isAutoHideEnabled()) return;

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        boolean leftSide = bubbleParams.x + bubbleParams.width / 2 < metrics.widthPixels / 2;
        int centerY = bubbleParams.y + bubbleParams.height / 2;

        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putInt("floating.x", bubbleParams.x)
                .putInt("floating.y", bubbleParams.y)
                .putBoolean("floating.edge.left", leftSide)
                .putInt("floating.edge.y", centerY)
                .putBoolean("floating.auto_hidden", true)
                .apply();

        try { windowManager.removeView(bubble); } catch (Exception ignored) {}
        bubble = null;
        bubbleParams = null;
        autoHidden = true;
        showEdgeHandle(leftSide, centerY);
    }

    private void showEdgeHandleFromSavedPosition() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        int savedX = prefs.getInt("floating.x", -1);
        int sizePx = dp(Math.max(24, Math.min(76, prefs.getInt("floating.size", 54))));
        boolean leftSide = prefs.getBoolean("floating.edge.left",
                savedX >= 0 && savedX + sizePx / 2 < metrics.widthPixels / 2);
        int centerY = prefs.getInt("floating.edge.y",
                prefs.getInt("floating.y", metrics.heightPixels / 3));
        showEdgeHandle(leftSide, centerY);
    }

    private void showEdgeHandle(boolean leftSide, int centerY) {
        if (edgeHandle != null) return;
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);

        edgeHandle = new TextView(this);
        int edgeWidthDp = Math.max(6, Math.min(26,
                getSharedPreferences("tool_state", MODE_PRIVATE).getInt("floating.edge.width", 12)));
        // At the thinnest widths, use a clean tappable strip rather than clipping the arrow glyph.
        edgeHandle.setText(edgeWidthDp <= 10 ? "" : (leftSide ? "›" : "‹"));
        edgeHandle.setTextColor(Color.WHITE);
        edgeHandle.setTextSize(Math.max(10, Math.min(18, edgeWidthDp * 1.15f)));
        edgeHandle.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        edgeHandle.setGravity(Gravity.CENTER);
        edgeHandle.setContentDescription("Show Smart Toolbox floating icon and controls");
        edgeHandle.setPadding(0, dp(4), 0, dp(4));

        GradientDrawable handleBackground = new GradientDrawable();
        handleBackground.setColor(Color.rgb(255, 166, 35));
        handleBackground.setCornerRadius(dp(18));
        handleBackground.setStroke(dp(1), Color.WHITE);
        edgeHandle.setBackground(handleBackground);
        int opacity = Math.max(30, Math.min(100,
                getSharedPreferences("tool_state", MODE_PRIVATE).getInt("floating.opacity", 100)));
        edgeHandle.setAlpha(Math.max(0.65f, opacity / 100f));
        edgeHandle.setElevation(dp(10));

        int width = dp(edgeWidthDp);
        int height = dp(60);
        edgeParams = new WindowManager.LayoutParams(
                width, height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        edgeParams.gravity = Gravity.TOP | Gravity.START;
        edgeParams.x = leftSide ? 0 : Math.max(0, metrics.widthPixels - width);
        edgeParams.y = Math.max(dp(8), Math.min(metrics.heightPixels - height - dp(8),
                centerY - height / 2));

        edgeHandle.setOnClickListener(v -> restoreBubbleFromEdge());
        try {
            windowManager.addView(edgeHandle, edgeParams);
        } catch (Exception e) {
            edgeHandle = null;
            edgeParams = null;
            stopSelf();
        }
    }

    private void restoreBubbleFromEdge() {
        cancelAutoHide();
        removeEdgeHandle();
        autoHidden = false;
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.auto_hidden", false).apply();
        ensureBubble();
        if (getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.panel.enabled", true)) {
            showPanel();
        }
    }

    private void removeEdgeHandle() {
        if (edgeHandle != null) {
            try { windowManager.removeView(edgeHandle); } catch (Exception ignored) {}
            edgeHandle = null;
            edgeParams = null;
        }
    }

    private void showPanel() {
        cancelAutoHide();
        removePanel();
        if (bubble == null || bubbleParams == null) return;

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(20, 26, 34));
        background.setCornerRadius(dp(18));
        background.setStroke(dp(1), Color.rgb(76, 88, 104));

        panel = new ScrollView(this) {
            @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int screenHeight = getResources().getDisplayMetrics().heightPixels;
                int maxHeight = Math.max(dp(240), Math.min(dp(580), screenHeight - dp(32)));
                int limitedHeightSpec = View.MeasureSpec.makeMeasureSpec(
                        maxHeight, View.MeasureSpec.AT_MOST);
                super.onMeasure(widthMeasureSpec, limitedHeightSpec);
            }
        };
        panel.setFillViewport(false);
        panel.setVerticalScrollBarEnabled(true);
        panel.setBackground(background);
        panel.setElevation(dp(12));
        panelContent = new LinearLayout(this);
        panelContent.setOrientation(LinearLayout.VERTICAL);
        panelContent.setPadding(dp(14), dp(14), dp(14), dp(14));
        panel.addView(panelContent, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("SMART TOOLBOX");
        title.setTextColor(Color.rgb(255, 194, 71));
        title.setTextSize(14);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        panelContent.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Quick controls · drag the ST icon to move it");
        hint.setTextColor(Color.LTGRAY);
        hint.setTextSize(11);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(3);
        panelContent.addView(hint, hintParams);

        boolean night = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        android.content.SharedPreferences toolPrefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean thermal = toolPrefs.getBoolean("thermal.active", false);
        boolean masterOn = toolPrefs.getBoolean("audio.master.enabled",
                toolPrefs.getBoolean("audio.active", false));
        boolean masterSupported = toolPrefs.getBoolean("audio.master.supported", false);
        boolean scanner = toolPrefs.getBoolean("scanner.active", false);
        String masterLabel = masterOn
                ? (masterSupported ? "ON  /  Turn off" : "ON · Support not confirmed  /  Turn off")
                : "OFF  /  Turn on";

        addPanelAction("🌙  Night Screen  ·  " + (night ? "ON  /  Turn off" : "OFF  /  Turn on"), this::toggleNight);
        addPanelAction("🌡️  Thermal Monitor  ·  " + (thermal ? "ON  /  Turn off" : "OFF  /  Turn on"), this::toggleThermal);
        addPanelAction("🔊  Master Volume Boost  ·  " + masterLabel, this::toggleAudio);
        addPanelAction("📷  Document Scanner  ·  " + (scanner ? "ON  /  Close scanner" : "OFF  /  Open scanner"), this::toggleScanner);

        thermalReadout = new TextView(this);
        thermalReadout.setTextColor(Color.rgb(210, 220, 232));
        thermalReadout.setTextSize(12);
        thermalReadout.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable thermalBackground = new GradientDrawable();
        thermalBackground.setColor(Color.rgb(31, 40, 52));
        thermalBackground.setCornerRadius(dp(10));
        thermalReadout.setBackground(thermalBackground);
        LinearLayout.LayoutParams thermalParams = new LinearLayout.LayoutParams(-1, -2);
        thermalParams.topMargin = dp(8);
        panelContent.addView(thermalReadout, thermalParams);
        updateThermalReadout();

        // These sliders remain available whenever the floating panel is open.
        // When a feature is off, the chosen value is saved for the next activation.
        int nightLevel = Math.max(0, Math.min(95,
                getSharedPreferences("night", MODE_PRIVATE).getInt("level", 60)));
        addPanelSlider(
                "Night Screen darkness",
                nightLevel,
                95,
                value -> value + "%  ·  " + (value >= 85 ? "Extra dark" : (value == 0 ? "Bright" : "Dim")),
                new PanelSliderListener() {
                    @Override public void onChange(int value) { scheduleNightLevelUpdate(value); }
                    @Override public void onRelease(int value) { flushNightLevelUpdate(value); }
                });

        int currentBrightness = getDisplayBrightness();
        addPanelSlider(
                "Display brightness",
                currentBrightness,
                255,
                value -> value * 100 / 255 + "%",
                new PanelSliderListener() {
                    @Override public void onChange(int value) {
                        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                                .putInt("display.brightness", value).apply();
                    }
                    @Override public void onRelease(int value) {
                        applyDisplayBrightness(value);
                    }
                });
        addPanelAction(Settings.System.canWrite(this)
                ? "☀️  Display brightness permission · Granted"
                : "☀️  Allow display brightness control", this::requestBrightnessPermission);

        int audioGain = Math.max(0, Math.min(1000,
                getSharedPreferences("tool_state", MODE_PRIVATE).getInt("audio.gain", 400)));
        addPanelSlider(
                "Master Volume level",
                audioGain,
                1000,
                value -> String.format(java.util.Locale.getDefault(), "+%.1f dB", value / 100f),
                new PanelSliderListener() {
                    @Override public void onChange(int value) { scheduleAudioGainUpdate(value); }
                    @Override public void onRelease(int value) { flushAudioGainUpdate(value); }
                });

        addPanelAction("Floating icon settings", this::openFloatingSettings);
        addPanelAction("Hide floating icon", this::hideBubble);

        TextView close = new TextView(this);
        close.setText("Close panel");
        close.setTextColor(Color.WHITE);
        close.setTextSize(12);
        close.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(-1, dp(38));
        closeParams.topMargin = dp(5);
        panelContent.addView(close, closeParams);
        close.setOnClickListener(v -> {
            removePanel();
            scheduleAutoHide();
        });

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int panelWidth = dp(276);
        int maxPanelHeight = Math.min(dp(580), metrics.heightPixels - dp(32));
        panelParams = new WindowManager.LayoutParams(
                panelWidth, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        int maxY = Math.max(dp(8), metrics.heightPixels - maxPanelHeight - dp(8));
        panelParams.x = Math.max(dp(6), Math.min(metrics.widthPixels - panelWidth - dp(6),
                bubbleParams.x - panelWidth + bubbleParams.width));
        panelParams.y = Math.max(dp(8), Math.min(maxY, bubbleParams.y));
        try {
            windowManager.addView(panel, panelParams);
            scheduleThermalReadout();
        } catch (Exception e) {
            panel = null;
            panelContent = null;
            panelParams = null;
            thermalReadout = null;
        }
    }

    private interface PanelSliderFormatter {
        String format(int value);
    }

    private interface PanelSliderListener {
        void onChange(int value);
        void onRelease(int value);
    }

    private void addPanelSlider(String title, int initialValue, int maxValue,
                                PanelSliderFormatter formatter, PanelSliderListener listener) {
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.VERTICAL);
        group.setPadding(dp(10), dp(9), dp(10), dp(8));
        GradientDrawable groupBackground = new GradientDrawable();
        groupBackground.setColor(Color.rgb(31, 40, 52));
        groupBackground.setCornerRadius(dp(12));
        group.setBackground(groupBackground);

        TextView label = new TextView(this);
        label.setText(title + "  ·  " + formatter.format(initialValue));
        label.setTextColor(Color.WHITE);
        label.setTextSize(12);
        label.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        group.addView(label, new LinearLayout.LayoutParams(-1, -2));

        SeekBar seek = new SeekBar(this);
        seek.setMax(maxValue);
        seek.setProgress(Math.max(0, Math.min(maxValue, initialValue)));
        seek.setContentDescription(title);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(-1, -2);
        seekParams.topMargin = dp(3);
        group.addView(seek, seekParams);

        LinearLayout.LayoutParams groupParams = new LinearLayout.LayoutParams(-1, -2);
        groupParams.topMargin = dp(9);
        panelContent.addView(group, groupParams);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                label.setText(title + "  ·  " + formatter.format(progress));
                if (fromUser) listener.onChange(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                listener.onRelease(seekBar.getProgress());
            }
        });
    }

    private void scheduleNightLevelUpdate(int level) {
        getSharedPreferences("night", MODE_PRIVATE).edit().putInt("level", level).apply();
        if (!getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false)) return;
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        pendingNightUpdate = () -> {
            pendingNightUpdate = null;
            applyNightLevel(level);
        };
        sliderHandler.postDelayed(pendingNightUpdate, 120);
    }

    private void flushNightLevelUpdate(int level) {
        getSharedPreferences("night", MODE_PRIVATE).edit().putInt("level", level).apply();
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        pendingNightUpdate = null;
        if (getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false)) {
            applyNightLevel(level);
        }
    }

    private void applyNightLevel(int level) {
        android.content.SharedPreferences prefs = getSharedPreferences("night", MODE_PRIVATE);
        Intent update = new Intent(this, DimOverlayService.class);
        update.putExtra("level", Math.max(0, Math.min(95, level)));
        update.putExtra("warm", prefs.getBoolean("warm", false));
        ContextCompat.startForegroundService(this, update);
    }

    private void scheduleAudioGainUpdate(int gain) {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putInt("audio.gain", gain).apply();
        if (!getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.master.enabled", false)) return;
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        pendingAudioUpdate = () -> {
            pendingAudioUpdate = null;
            applyAudioGain(gain);
        };
        sliderHandler.postDelayed(pendingAudioUpdate, 120);
    }

    private void flushAudioGainUpdate(int gain) {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putInt("audio.gain", gain).apply();
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        pendingAudioUpdate = null;
        if (getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.master.enabled", false)) {
            applyAudioGain(gain);
        }
    }

    private void applyAudioGain(int gain) {
        Intent update = new Intent(this, SystemAudioBoostService.class);
        update.setAction(SystemAudioBoostService.ACTION_UPDATE);
        update.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB, Math.max(0, Math.min(1000, gain)));
        ContextCompat.startForegroundService(this, update);
    }

    private int getDisplayBrightness() {
        try {
            int brightness = Settings.System.getInt(
                    getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            return Math.max(0, Math.min(255, brightness));
        } catch (Exception ignored) {
            return Math.max(0, Math.min(255,
                    getSharedPreferences("tool_state", MODE_PRIVATE)
                            .getInt("display.brightness", 128)));
        }
    }

    private void requestBrightnessPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(this)) {
            Toast.makeText(this, "Display brightness control is already allowed.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this,
                "Allow Smart Toolbox Pro to modify system settings, then return to the floating panel.",
                Toast.LENGTH_LONG).show();
        try {
            Intent permission = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            permission.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(permission);
            watchForBrightnessPermission(0);
        } catch (Exception error) {
            Toast.makeText(this, "Could not open brightness permission settings.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void watchForBrightnessPermission(int attempt) {
        if (Settings.System.canWrite(this)) {
            if (brightnessPermissionRunnable != null) {
                sliderHandler.removeCallbacks(brightnessPermissionRunnable);
                brightnessPermissionRunnable = null;
            }
            int saved = getSharedPreferences("tool_state", MODE_PRIVATE)
                    .getInt("display.brightness", getDisplayBrightness());
            applyDisplayBrightness(saved);
            return;
        }
        if (attempt >= 60) {
            brightnessPermissionRunnable = null;
            return;
        }
        brightnessPermissionRunnable = () -> watchForBrightnessPermission(attempt + 1);
        sliderHandler.postDelayed(brightnessPermissionRunnable, 1000L);
    }

    private void applyDisplayBrightness(int value) {
        int safeValue = Math.max(0, Math.min(255, value));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(this)) {
            requestBrightnessPermission();
            return;
        }
        try {
            Settings.System.putInt(getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            boolean saved = Settings.System.putInt(getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, safeValue);
            if (saved) {
                getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                        .putInt("display.brightness", safeValue).apply();
            } else {
                Toast.makeText(this, "The phone did not accept the brightness change.",
                        Toast.LENGTH_SHORT).show();
            }
        } catch (SecurityException error) {
            requestBrightnessPermission();
        } catch (Exception error) {
            Toast.makeText(this, "Display brightness could not be changed on this device.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void updateThermalReadout() {
        if (thermalReadout == null) return;
        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.getBoolean("thermal.active", false)) {
            thermalReadout.setText("Temperature: Monitoring is OFF · Turn on Thermal Monitor to view it here.");
        } else {
            String battery = prefs.getString("thermal.battery", "Battery temperature unavailable");
            String status = prefs.getString("thermal.status", "Thermal status unavailable");
            thermalReadout.setText("LIVE TEMPERATURE  ·  " + battery + "  ·  " + status);
        }
    }

    private void scheduleThermalReadout() {
        if (thermalReadoutRunnable != null) {
            sliderHandler.removeCallbacks(thermalReadoutRunnable);
        }
        thermalReadoutRunnable = () -> {
            if (thermalReadout == null || panel == null) return;
            updateThermalReadout();
            sliderHandler.postDelayed(thermalReadoutRunnable, 1500L);
        };
        sliderHandler.postDelayed(thermalReadoutRunnable, 1500L);
    }

    private void addPanelAction(String label, Runnable action) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextColor(Color.WHITE);
        item.setTextSize(13);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(10), dp(11), dp(10), dp(11));
        GradientDrawable itemBg = new GradientDrawable();
        itemBg.setColor(Color.rgb(39, 48, 60));
        itemBg.setCornerRadius(dp(11));
        item.setBackground(itemBg);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(8);
        panelContent.addView(item, params);
        item.setOnClickListener(v -> action.run());
    }

    private void toggleNight() {
        android.content.SharedPreferences prefs = getSharedPreferences("night", MODE_PRIVATE);
        boolean active = prefs.getBoolean("active", false);
        Intent intent = new Intent(this, DimOverlayService.class);
        if (active) {
            intent.setAction(DimOverlayService.ACTION_STOP);
            startService(intent);
            prefs.edit().putBoolean("active", false).apply();
        } else {
            int level = prefs.getInt("level", 60);
            boolean warm = prefs.getBoolean("warm", false);
            intent.putExtra("level", level);
            intent.putExtra("warm", warm);
            prefs.edit().putBoolean("active", true).apply();
            ContextCompat.startForegroundService(this, intent);
            FloatingControlService.start(this);
        }
        showPanel();
    }

    private void toggleThermal() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("thermal.active", false);
        Intent intent = new Intent(this, ThermalMonitorService.class);
        if (active) {
            intent.setAction(ThermalMonitorService.ACTION_STOP);
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("thermal.active", false).apply();
            startService(intent);
        } else {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("thermal.active", true).apply();
            ContextCompat.startForegroundService(this, intent);
        }
        showPanel();
    }

    private void toggleAudio() {
        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean masterOn = prefs.getBoolean("audio.master.enabled",
                prefs.getBoolean("audio.active", false));
        Intent control = new Intent(this, SystemAudioBoostService.class);
        if (masterOn) {
            prefs.edit().putBoolean("audio.master.enabled", false).apply();
            control.setAction(SystemAudioBoostService.ACTION_MASTER_OFF);
            startService(control);
        } else {
            prefs.edit().putBoolean("audio.master.enabled", true).apply();
            control.setAction(SystemAudioBoostService.ACTION_MASTER_ON);
            control.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB,
                    prefs.getInt("audio.gain", 400));
            ContextCompat.startForegroundService(this, control);
        }
        showPanel();
    }

    private void toggleScanner() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("scanner.active", false);
        if (active) {
            Intent close = new Intent(this, MainActivity.class);
            close.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(close);
        } else {
            Intent open = new Intent(this, DocumentScannerActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(open);
        }
        removePanel();
        scheduleAutoHide();
    }

    private void openFloatingSettings() {
        removePanel();
        scheduleAutoHide();
        Intent open = new Intent(this, FloatingIconSettingsActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(open);
    }

    private void hideBubble() {
        cancelAutoHide();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.hidden", true)
                .putBoolean("floating.enabled", false)
                .putBoolean("floating.auto_hidden", false).apply();
        removePanelAndBubble();
        stopForeground(true);
        stopSelf();
    }

    private void removePanel() {
        if (thermalReadoutRunnable != null) {
            sliderHandler.removeCallbacks(thermalReadoutRunnable);
            thermalReadoutRunnable = null;
        }
        thermalReadout = null;
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
            panelContent = null;
            panelParams = null;
        }
    }

    private void removePanelAndBubble() {
        cancelAutoHide();
        removePanel();
        removeEdgeHandle();
        autoHidden = false;
        if (bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
            bubbleParams = null;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Floating controls", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the user-enabled Smart Toolbox floating sidebar available, even when no tool is active.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Smart Toolbox floating control")
                .setContentText("Tap the edge tab or ST bubble for quick controls.")
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        if (thermalReadoutRunnable != null) sliderHandler.removeCallbacks(thermalReadoutRunnable);
        if (brightnessPermissionRunnable != null) sliderHandler.removeCallbacks(brightnessPermissionRunnable);
        cancelAutoHide();
        removePanelAndBubble();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
