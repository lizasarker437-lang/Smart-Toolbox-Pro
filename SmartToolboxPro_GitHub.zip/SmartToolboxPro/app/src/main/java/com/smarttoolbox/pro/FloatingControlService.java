package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

public class FloatingControlService extends Service {
    public static final String ACTION_SHOW = "com.smarttoolbox.pro.FLOAT_SHOW";
    public static final String ACTION_REFRESH = "com.smarttoolbox.pro.FLOAT_REFRESH";
    public static final String ACTION_HIDE = "com.smarttoolbox.pro.FLOAT_HIDE";

    private static final String CHANNEL_ID = "floating_controls";
    private static final int NOTIFICATION_ID = 2401;

    private WindowManager windowManager;
    private TextView bubble;
    private LinearLayout panel;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private int touchSlop;
    private float downRawX;
    private float downRawY;
    private int downX;
    private int downY;
    private boolean dragged;

    public static boolean hasOverlayPermission(Context context) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context);
    }

    public static boolean start(Context context) {
        if (!hasOverlayPermission(context)) return false;
        android.content.SharedPreferences prefs = context.getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.getBoolean("floating.enabled", true)) return false;
        prefs.edit().putBoolean("floating.hidden", false).apply();
        Intent intent = new Intent(context, FloatingControlService.class);
        intent.setAction(ACTION_SHOW);
        ContextCompat.startForegroundService(context, intent);
        return true;
    }

    public static void refresh(Context context) {
        Intent intent = new Intent(context, FloatingControlService.class);
        intent.setAction(ACTION_REFRESH);
        android.content.SharedPreferences prefs = context.getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean hidden = prefs.getBoolean("floating.hidden", false);
        boolean enabled = prefs.getBoolean("floating.enabled", true);
        if (hidden || !enabled || !hasOverlayPermission(context) || !anyFeatureActive(context)) {
            context.stopService(new Intent(context, FloatingControlService.class));
        } else {
            ContextCompat.startForegroundService(context, intent);
        }
    }

    public static boolean anyFeatureActive(Context context) {
        boolean night = context.getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        boolean thermal = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("thermal.active", false);
        boolean audio = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("audio.active", false);
        boolean scanner = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("scanner.active", false);
        return night || thermal || audio || scanner;
    }

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_REFRESH : intent.getAction();

        if (ACTION_HIDE.equals(action)) {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("floating.hidden", true).putBoolean("floating.enabled", false).apply();
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (!hasOverlayPermission(this)) {
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification());
        }

        android.content.SharedPreferences floatingPrefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean hidden = floatingPrefs.getBoolean("floating.hidden", false);
        boolean enabled = floatingPrefs.getBoolean("floating.enabled", true);
        if (hidden || !enabled || !anyFeatureActive(this)) {
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        boolean panelWasOpen = panel != null;
        boolean nightIsActive = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        if ((ACTION_SHOW.equals(action) || ACTION_REFRESH.equals(action) || nightIsActive) && bubble != null) {
            // Re-add after settings changes or Night Screen overlay so size, opacity and z-order refresh.
            removePanelAndBubble();
        }
        ensureBubble();
        if (panelWasOpen && getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.panel.enabled", true)) showPanel();
        return START_STICKY;
    }

    private void ensureBubble() {
        if (bubble != null) return;

        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        int sizeDp = Math.max(40, Math.min(76, prefs.getInt("floating.size", 54)));
        int opacity = Math.max(30, Math.min(100, prefs.getInt("floating.opacity", 100)));

        bubble = new TextView(this);
        bubble.setText("ST");
        bubble.setContentDescription("Smart Toolbox floating controls. Tap to open, drag to move.");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(Math.max(12, Math.min(18, sizeDp * 0.28f)));
        bubble.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(255, 166, 35));
        circle.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(circle);
        bubble.setAlpha(opacity / 100f);
        bubble.setElevation(dp(8));

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int sizePx = dp(sizeDp);
        bubbleParams = new WindowManager.LayoutParams(
                sizePx, sizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;

        int savedX = prefs.getInt("floating.x", -1);
        int savedY = prefs.getInt("floating.y", -1);
        bubbleParams.x = savedX >= 0
                ? Math.max(0, Math.min(metrics.widthPixels - sizePx, savedX))
                : Math.max(dp(8), metrics.widthPixels - sizePx - dp(14));
        bubbleParams.y = savedY >= 0
                ? Math.max(0, Math.min(metrics.heightPixels - sizePx, savedY))
                : Math.max(dp(90), metrics.heightPixels / 3);

        bubble.setOnTouchListener((view, event) -> handleBubbleTouch(event));
        try {
            windowManager.addView(bubble, bubbleParams);
        } catch (Exception e) {
            bubble = null;
            bubbleParams = null;
            stopSelf();
        }
    }

    private boolean handleBubbleTouch(MotionEvent event) {
        if (bubbleParams == null) return true;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                downX = bubbleParams.x;
                downY = bubbleParams.y;
                dragged = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                int dx = (int) (event.getRawX() - downRawX);
                int dy = (int) (event.getRawY() - downRawY);
                if (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop) dragged = true;
                if (dragged) {
                    DisplayMetrics metrics = new DisplayMetrics();
                    windowManager.getDefaultDisplay().getMetrics(metrics);
                    bubbleParams.x = Math.max(0, Math.min(metrics.widthPixels - bubbleParams.width, downX + dx));
                    bubbleParams.y = Math.max(0, Math.min(metrics.heightPixels - bubbleParams.height, downY + dy));
                    try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragged && bubbleParams != null) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("floating.x", bubbleParams.x)
                            .putInt("floating.y", bubbleParams.y).apply();
                } else if (getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getBoolean("floating.panel.enabled", true)) {
                    showPanel();
                }
                return true;
            default:
                return true;
        }
    }

    private void showPanel() {
        removePanel();
        if (bubble == null || bubbleParams == null) return;

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(20, 26, 34));
        background.setCornerRadius(dp(18));
        background.setStroke(dp(1), Color.rgb(76, 88, 104));
        panel.setBackground(background);
        panel.setElevation(dp(12));

        TextView title = new TextView(this);
        title.setText("SMART TOOLBOX");
        title.setTextColor(Color.rgb(255, 194, 71));
        title.setTextSize(14);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        panel.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Quick controls · drag the ST icon to move it");
        hint.setTextColor(Color.LTGRAY);
        hint.setTextSize(11);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(3);
        panel.addView(hint, hintParams);

        boolean night = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        boolean thermal = getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("thermal.active", false);
        boolean audio = getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("audio.active", false);
        boolean scanner = getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("scanner.active", false);

        addPanelAction("🌙  Night Screen  ·  " + (night ? "ON  /  Turn off" : "OFF  /  Turn on"), this::toggleNight);
        addPanelAction("🌡️  Thermal Monitor  ·  " + (thermal ? "ON  /  Turn off" : "OFF  /  Turn on"), this::toggleThermal);
        addPanelAction("🔊  System Audio Boost  ·  " + (audio ? "ON  /  Turn off" : "OFF  /  Open settings"), this::toggleAudio);
        addPanelAction("📷  Document Scanner  ·  " + (scanner ? "ON  /  Close scanner" : "OFF  /  Open scanner"), this::toggleScanner);
        addPanelAction("Floating icon settings", this::openFloatingSettings);
        addPanelAction("Hide floating icon", this::hideBubble);

        TextView close = new TextView(this);
        close.setText("Close panel");
        close.setTextColor(Color.WHITE);
        close.setTextSize(12);
        close.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(-1, dp(34));
        closeParams.topMargin = dp(4);
        panel.addView(close, closeParams);
        close.setOnClickListener(v -> removePanel());

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int panelWidth = dp(238);
        panelParams = new WindowManager.LayoutParams(
                panelWidth, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = Math.max(dp(6), Math.min(metrics.widthPixels - panelWidth - dp(6),
                bubbleParams.x - panelWidth + bubbleParams.width));
        panelParams.y = Math.max(dp(8), Math.min(metrics.heightPixels - dp(360), bubbleParams.y));
        try {
            windowManager.addView(panel, panelParams);
        } catch (Exception e) {
            panel = null;
            panelParams = null;
        }
    }

    private void addPanelAction(String label, Runnable action) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextColor(Color.WHITE);
        item.setTextSize(13);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(10), dp(11), dp(10), dp(11));
        GradientDrawable itemBg = new GradientDrawable();
        itemBg.setColor(Color.rgb(39, 48, 60));
        itemBg.setCornerRadius(dp(11));
        item.setBackground(itemBg);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(8);
        panel.addView(item, params);
        item.setOnClickListener(v -> action.run());
    }

    private void toggleNight() {
        android.content.SharedPreferences prefs = getSharedPreferences("night", MODE_PRIVATE);
        boolean active = prefs.getBoolean("active", false);
        Intent intent = new Intent(this, DimOverlayService.class);
        if (active) {
            intent.setAction(DimOverlayService.ACTION_STOP);
            startService(intent);
            prefs.edit().putBoolean("active", false).apply();
        } else {
            int level = prefs.getInt("level", 60);
            boolean warm = prefs.getBoolean("warm", false);
            intent.putExtra("level", level);
            intent.putExtra("warm", warm);
            prefs.edit().putBoolean("active", true).apply();
            ContextCompat.startForegroundService(this, intent);
            FloatingControlService.start(this);
        }
        showPanel();
    }

    private void toggleThermal() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("thermal.active", false);
        Intent intent = new Intent(this, ThermalMonitorService.class);
        if (active) {
            intent.setAction(ThermalMonitorService.ACTION_STOP);
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("thermal.active", false).apply();
            startService(intent);
        } else {
            ContextCompat.startForegroundService(this, intent);
        }
        showPanel();
    }

    private void toggleAudio() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.active", false);
        if (active) {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("audio.active", false).apply();
            Intent stop = new Intent(this, SystemAudioBoostService.class);
            stop.setAction(SystemAudioBoostService.ACTION_STOP);
            startService(stop);
            showPanel();
        } else {
            removePanel();
            Intent open = new Intent(this, VolumeBoosterActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(open);
        }
    }

    private void toggleScanner() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("scanner.active", false);
        if (active) {
            Intent close = new Intent(this, MainActivity.class);
            close.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(close);
        } else {
            Intent open = new Intent(this, DocumentScannerActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(open);
        }
        removePanel();
    }

    private void openFloatingSettings() {
        removePanel();
        Intent open = new Intent(this, FloatingIconSettingsActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(open);
    }

    private void hideBubble() {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.hidden", true).putBoolean("floating.enabled", false).apply();
        removePanelAndBubble();
        stopForeground(true);
        stopSelf();
    }

    private void removePanel() {
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
            panelParams = null;
        }
    }

    private void removePanelAndBubble() {
        removePanel();
        if (bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
            bubbleParams = null;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Floating controls", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the Smart Toolbox floating control available while a tool is active.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Smart Toolbox floating control")
                .setContentText("Tap the ST bubble for tool on/off controls.")
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        removePanelAndBubble();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
