package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.audiofx.LoudnessEnhancer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

public class AudioBoostService extends Service {
    public static final String ACTION_PLAY = "com.smarttoolbox.pro.PLAY_BOOSTED_AUDIO";
    public static final String ACTION_STOP = "com.smarttoolbox.pro.STOP_BOOSTED_AUDIO";
    public static final String EXTRA_GAIN_MB = "gain_millibels";

    private static final String CHANNEL_ID = "extra_audio_boost";
    private static final int NOTIFICATION_ID = 2403;

    private MediaPlayer player;
    private LoudnessEnhancer enhancer;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            releasePlayer();
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("audio.active", false).apply();
            stopForeground(true);
            stopSelf(startId);
            FloatingControlService.refresh(this);
            return START_NOT_STICKY;
        }

        Uri audioUri = intent.getData();
        if (audioUri == null) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        startAsForeground("Preparing selected audio…");
        int gainMb = Math.max(0, Math.min(1000, intent.getIntExtra(EXTRA_GAIN_MB, 0)));
        preparePlayback(audioUri, gainMb);
        return START_NOT_STICKY;
    }

    private void startAsForeground(String message) {
        Notification notification = buildNotification(message);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void preparePlayback(Uri uri, int gainMb) {
        releasePlayer();
        try {
            player = new MediaPlayer();
            player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setOnPreparedListener(mp -> {
                boolean enhancementApplied = false;
                try {
                    enhancer = new LoudnessEnhancer(mp.getAudioSessionId());
                    enhancer.setTargetGain(gainMb);
                    enhancer.setEnabled(true);
                    enhancementApplied = true;
                } catch (Exception ignored) {
                    // Playback can continue at the original digital level if enhancement is unavailable.
                }
                mp.start();
                getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                        .putBoolean("audio.active", true).apply();
                String boost = String.format(java.util.Locale.getDefault(), "+%.1f dB", gainMb / 100f);
                updateNotification(enhancementApplied
                        ? "Playing selected audio · Extra gain " + boost
                        : "Playing selected audio · Extra gain unavailable on this device");
                FloatingControlService.start(this);
            });
            player.setOnCompletionListener(mp -> stopSelf());
            player.setOnErrorListener((mp, what, extra) -> {
                stopSelf();
                return true;
            });
            player.setDataSource(this, uri);
            player.prepareAsync();
        } catch (Exception e) {
            releasePlayer();
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("audio.active", false).apply();
            stopForeground(true);
            stopSelf();
            FloatingControlService.refresh(this);
        }
    }

    private void releasePlayer() {
        if (enhancer != null) {
            try { enhancer.setEnabled(false); } catch (Exception ignored) {}
            try { enhancer.release(); } catch (Exception ignored) {}
            enhancer = null;
        }
        if (player != null) {
            try { player.setOnPreparedListener(null); } catch (Exception ignored) {}
            try { player.setOnCompletionListener(null); } catch (Exception ignored) {}
            try { player.setOnErrorListener(null); } catch (Exception ignored) {}
            try { player.reset(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Extra audio boost", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows when Smart Toolbox is playing audio with extra digital gain.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String message) {
        Intent stopIntent = new Intent(this, AudioBoostService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 2403, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Extra Volume Boost")
                .setContentText(message)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Stop", stopPending)
                .build();
    }

    private void updateNotification(String message) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(message));
    }

    @Override public void onDestroy() {
        releasePlayer();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("audio.active", false).apply();
        stopForeground(true);
        super.onDestroy();
        FloatingControlService.refresh(this);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
