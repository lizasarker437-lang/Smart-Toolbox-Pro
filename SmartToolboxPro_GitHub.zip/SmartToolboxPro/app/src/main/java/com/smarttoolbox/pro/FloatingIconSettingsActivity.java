package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingIconSettingsActivity extends Activity {
    private static final String PREFS = "tool_state";
    private Switch showSwitch;
    private Switch panelSwitch;
    private Switch autoHideSwitch;
    private SeekBar sizeSeek;
    private SeekBar opacitySeek;
    private SeekBar hideDelaySeek;
    private SeekBar edgeWidthSeek;
    private SeekBar toolboxWidthSeek;
    private SeekBar toolboxHeightSeek;
    private TextView toolboxWidthLabel;
    private TextView toolboxHeightLabel;
    private TextView sizeLabel;
    private TextView opacityLabel;
    private TextView hideDelayLabel;
    private TextView edgeWidthLabel;

    @Override public void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyToActivity(this);
        super.onCreate(savedInstanceState);

        LinearLayout page = Ui.page(this, "Floating Icon Settings");
        LinearLayout body = Ui.content(page);
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        Ui.addText(this, body,
                "Swipe inward from the edge to open Quick Controls directly. The panel closes after 3 seconds without interaction, or as soon as you tap outside it. The ST sidebar can stay available even when all tools are OFF.",
                14, Ui.MUTED, false, 2);

        LinearLayout visibilityCard = Ui.card(this);
        Ui.addText(this, visibilityCard, "Visibility", 18, Ui.TEXT, true, 0);

        showSwitch = new Switch(this);
        showSwitch.setText("Keep floating sidebar available (even when all tools are OFF)");
        showSwitch.setTextColor(Ui.TEXT);
        showSwitch.setTextSize(15);
        showSwitch.setChecked(prefs.getBoolean("floating.enabled", true)
                && !prefs.getBoolean("floating.hidden", false));
        LinearLayout.LayoutParams showParams = new LinearLayout.LayoutParams(-1, -2);
        showParams.topMargin = Ui.dp(this, 10);
        visibilityCard.addView(showSwitch, showParams);
        showSwitch.setOnCheckedChangeListener((button, checked) -> {
            android.content.SharedPreferences.Editor editor = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .edit().putBoolean("floating.enabled", checked);
            if (checked) {
                editor.putBoolean("floating.hidden", false)
                        .putBoolean("floating.auto_hidden", false);
            } else {
                editor.putBoolean("floating.hidden", true)
                        .putBoolean("floating.auto_hidden", false);
            }
            editor.apply();
            if (checked && !FloatingControlService.hasOverlayPermission(this)) {
                Toast.makeText(this,
                        "Allow Display over other apps to show the floating sidebar.",
                        Toast.LENGTH_LONG).show();
                requestOverlayPermission();
            }
            FloatingControlService.refresh(this);
        });

        panelSwitch = new Switch(this);
        panelSwitch.setText("Open quick control panel when the ST icon is tapped");
        panelSwitch.setTextColor(Ui.TEXT);
        panelSwitch.setTextSize(15);
        panelSwitch.setChecked(prefs.getBoolean("floating.panel.enabled", true));
        LinearLayout.LayoutParams panelParams = new LinearLayout.LayoutParams(-1, -2);
        panelParams.topMargin = Ui.dp(this, 12);
        visibilityCard.addView(panelSwitch, panelParams);
        panelSwitch.setOnCheckedChangeListener((button, checked) -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("floating.panel.enabled", checked).apply();
            FloatingControlService.refresh(this);
        });

        autoHideSwitch = new Switch(this);
        autoHideSwitch.setText("Auto-hide the floating icon to the screen edge");
        autoHideSwitch.setTextColor(Ui.TEXT);
        autoHideSwitch.setTextSize(15);
        autoHideSwitch.setChecked(prefs.getBoolean("floating.auto_hide", true));
        LinearLayout.LayoutParams autoHideParams = new LinearLayout.LayoutParams(-1, -2);
        autoHideParams.topMargin = Ui.dp(this, 12);
        visibilityCard.addView(autoHideSwitch, autoHideParams);
        autoHideSwitch.setOnCheckedChangeListener((button, checked) -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("floating.auto_hide", checked)
                    .putBoolean("floating.auto_hidden", false).apply();
            FloatingControlService.refresh(this);
        });

        int savedDelay = Math.max(1, Math.min(60,
                prefs.getInt("floating.auto_hide_seconds", 4)));
        hideDelayLabel = Ui.addText(this, visibilityCard,
                "Icon hides after: " + savedDelay + " seconds", 14, Ui.ACCENT, true, 14);
        hideDelaySeek = new SeekBar(this);
        hideDelaySeek.setMax(59);
        hideDelaySeek.setProgress(savedDelay - 1);
        visibilityCard.addView(hideDelaySeek, new LinearLayout.LayoutParams(-1, -2));
        hideDelaySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                hideDelayLabel.setText("Icon hides after: " + (progress + 1) + " seconds");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putInt("floating.auto_hide_seconds", seekBar.getProgress() + 1).apply();
                FloatingControlService.refresh(FloatingIconSettingsActivity.this);
            }
        });
        Ui.addCard(this, body, visibilityCard, 16);

        LinearLayout appearanceCard = Ui.card(this);
        Ui.addText(this, appearanceCard, "Icon appearance", 18, Ui.TEXT, true, 0);

        int savedSize = Math.max(24, Math.min(76, prefs.getInt("floating.size", 54)));
        sizeLabel = Ui.addText(this, appearanceCard,
                "Icon size: " + savedSize + " dp  ·  Minimum 24 dp",
                14, Ui.ACCENT, true, 12);
        sizeSeek = new SeekBar(this);
        sizeSeek.setMax(52);
        sizeSeek.setProgress(savedSize - 24);
        appearanceCard.addView(sizeSeek, new LinearLayout.LayoutParams(-1, -2));
        sizeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sizeLabel.setText("Icon size: " + (24 + progress) + " dp  ·  Minimum 24 dp");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putInt("floating.size", 24 + seekBar.getProgress()).apply();
                FloatingControlService.refresh(FloatingIconSettingsActivity.this);
            }
        });

        int savedOpacity = Math.max(30, Math.min(100, prefs.getInt("floating.opacity", 100)));
        opacityLabel = Ui.addText(this, appearanceCard,
                "Icon opacity: " + savedOpacity + "%", 14, Ui.ACCENT, true, 14);
        opacitySeek = new SeekBar(this);
        opacitySeek.setMax(70);
        opacitySeek.setProgress(savedOpacity - 30);
        appearanceCard.addView(opacitySeek, new LinearLayout.LayoutParams(-1, -2));
        opacitySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                opacityLabel.setText("Icon opacity: " + (30 + progress) + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putInt("floating.opacity", 30 + seekBar.getProgress()).apply();
                FloatingControlService.refresh(FloatingIconSettingsActivity.this);
            }
        });

        int savedEdgeWidth = Math.max(6, Math.min(26,
                prefs.getInt("floating.edge.width", 12)));
        edgeWidthLabel = Ui.addText(this, appearanceCard,
                "Collapsed side tab thickness: " + savedEdgeWidth + " dp",
                14, Ui.ACCENT, true, 14);
        edgeWidthSeek = new SeekBar(this);
        edgeWidthSeek.setMax(20);
        edgeWidthSeek.setProgress(savedEdgeWidth - 6);
        appearanceCard.addView(edgeWidthSeek, new LinearLayout.LayoutParams(-1, -2));
        edgeWidthSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                edgeWidthLabel.setText("Collapsed side tab thickness: " + (6 + progress) + " dp");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putInt("floating.edge.width", 6 + seekBar.getProgress()).apply();
                FloatingControlService.refresh(FloatingIconSettingsActivity.this);
            }
        });
        Ui.addCard(this, body, appearanceCard, 12);

        // These controls resize the toolbox panel itself, not the ST floating bubble.
        LinearLayout toolboxCard = Ui.card(this);
        Ui.addText(this, toolboxCard, "Toolbox panel size", 18, Ui.TEXT, true, 0);
        Ui.addText(this, toolboxCard,
                "Resize the Quick Controls panel that slides out of the floating icon. "
                        + "The icon size above stays independent. Smaller panels scroll internally.",
                13, Ui.MUTED, false, 6);

        int storedToolboxWidth = ToolboxPanelSize.clampWidthDp(
                prefs.getInt("floating.toolbox.width_dp", ToolboxPanelSize.DEFAULT_WIDTH_DP));
        toolboxWidthLabel = Ui.addText(this, toolboxCard,
                "Toolbox width: " + storedToolboxWidth + " dp",
                14, Ui.ACCENT, true, 14);
        toolboxWidthSeek = new SeekBar(this);
        toolboxWidthSeek.setMax(ToolboxPanelSize.MAX_WIDTH_DP - ToolboxPanelSize.MIN_WIDTH_DP);
        toolboxWidthSeek.setProgress(storedToolboxWidth - ToolboxPanelSize.MIN_WIDTH_DP);
        toolboxCard.addView(toolboxWidthSeek, new LinearLayout.LayoutParams(-1, -2));
        toolboxWidthSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                toolboxWidthLabel.setText("Toolbox width: "
                        + (ToolboxPanelSize.MIN_WIDTH_DP + progress) + " dp");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putInt("floating.toolbox.width_dp",
                                ToolboxPanelSize.MIN_WIDTH_DP + seekBar.getProgress()).apply();
                FloatingControlService.refresh(FloatingIconSettingsActivity.this);
            }
        });

        int storedToolboxHeight = ToolboxPanelSize.clampHeightDp(
                prefs.getInt("floating.toolbox.height_dp", ToolboxPanelSize.DEFAULT_HEIGHT_DP));
        toolboxHeightLabel = Ui.addText(this, toolboxCard,
                "Maximum toolbox height: " + storedToolboxHeight + " dp",
                14, Ui.ACCENT, true, 14);
        toolboxHeightSeek = new SeekBar(this);
        toolboxHeightSeek.setMax(ToolboxPanelSize.MAX_HEIGHT_DP - ToolboxPanelSize.MIN_HEIGHT_DP);
        toolboxHeightSeek.setProgress(storedToolboxHeight - ToolboxPanelSize.MIN_HEIGHT_DP);
        toolboxCard.addView(toolboxHeightSeek, new LinearLayout.LayoutParams(-1, -2));
        toolboxHeightSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                toolboxHeightLabel.setText("Maximum toolbox height: "
                        + (ToolboxPanelSize.MIN_HEIGHT_DP + progress) + " dp");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putInt("floating.toolbox.height_dp",
                                ToolboxPanelSize.MIN_HEIGHT_DP + seekBar.getProgress()).apply();
                FloatingControlService.refresh(FloatingIconSettingsActivity.this);
            }
        });

        Ui.addText(this, toolboxCard,
                "On smaller phones, width and height automatically fit the available screen. "
                        + "Everything stays clipped inside the rounded panel; swipe vertically inside the toolbox to see controls that do not fit at the minimum height.",
                12, Ui.MUTED, false, 10);
        android.widget.Button resetToolbox = Ui.button(this, "Reset toolbox size", () -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("floating.toolbox.width_dp", ToolboxPanelSize.DEFAULT_WIDTH_DP)
                    .putInt("floating.toolbox.height_dp", ToolboxPanelSize.DEFAULT_HEIGHT_DP)
                    .apply();
            toolboxWidthSeek.setProgress(ToolboxPanelSize.DEFAULT_WIDTH_DP - ToolboxPanelSize.MIN_WIDTH_DP);
            toolboxHeightSeek.setProgress(ToolboxPanelSize.DEFAULT_HEIGHT_DP - ToolboxPanelSize.MIN_HEIGHT_DP);
            FloatingControlService.refresh(this);
        });
        LinearLayout.LayoutParams toolboxResetParams = new LinearLayout.LayoutParams(-1, -2);
        toolboxResetParams.topMargin = Ui.dp(this, 12);
        toolboxCard.addView(resetToolbox, toolboxResetParams);
        Ui.addCard(this, body, toolboxCard, 12);

        LinearLayout positionCard = Ui.card(this);
        Ui.addText(this, positionCard, "Position", 18, Ui.TEXT, true, 0);
        Ui.addText(this, positionCard,
                "Drag the ST bubble to move it anywhere. After your chosen delay, it tucks into a thin tab on the nearest screen edge. Tap that tab to bring back the icon and quick controls.",
                13, Ui.MUTED, false, 6);
        android.widget.Button reset = Ui.button(this, "Reset icon position", () -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .remove("floating.x").remove("floating.y").apply();
            FloatingControlService.refresh(this);
            Toast.makeText(this, "Floating icon position reset.", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(-1, -2);
        resetParams.topMargin = Ui.dp(this, 12);
        positionCard.addView(reset, resetParams);
        Ui.addCard(this, body, positionCard, 12);

        LinearLayout permissionCard = Ui.card(this);
        Ui.addText(this, permissionCard, "Android permissions", 16, Ui.TEXT, true, 0);
        Ui.addText(this, permissionCard,
                "Display over other apps permission is required for this sidebar. Swipe inward on either screen-edge tab to open Quick Controls directly. Android system navigation gestures may take priority at the edge on some phones.",
                13, Ui.MUTED, false, 6);
        android.widget.Button permission = Ui.button(this, "Open overlay permission settings", this::requestOverlayPermission);
        LinearLayout.LayoutParams permissionParams = new LinearLayout.LayoutParams(-1, -2);
        permissionParams.topMargin = Ui.dp(this, 12);
        permissionCard.addView(permission, permissionParams);

        Ui.addCard(this, body, permissionCard, 12);

        setContentView(page);
    }

    @Override protected void onResume() {
        super.onResume();
        FloatingControlService.refresh(this);
    }

    private void requestOverlayPermission() {
        if (FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this, "Overlay permission is already enabled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

}
