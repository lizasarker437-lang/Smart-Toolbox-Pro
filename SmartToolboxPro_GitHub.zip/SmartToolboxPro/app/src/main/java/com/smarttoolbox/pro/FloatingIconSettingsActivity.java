package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingIconSettingsActivity extends Activity {
    private static final String PREFS = "tool_state";
    private Switch showSwitch;
    private Switch panelSwitch;
    private Switch autoHideSwitch;
    private SeekBar sizeSeek;
    private SeekBar opacitySeek;
    private TextView sizeLabel;
    private TextView opacityLabel;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = Ui.page(this, "Floating Icon Settings");
        LinearLayout body = Ui.content(page);
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        Ui.addText(this, body,
                "Control the floating ST sidebar. It can stay available over other apps even when every toolbox feature is OFF.",
                14, Ui.MUTED, false, 2);

        LinearLayout visibilityCard = Ui.card(this);
        Ui.addText(this, visibilityCard, "Visibility", 18, Ui.TEXT, true, 0);

        showSwitch = new Switch(this);
        showSwitch.setText("Keep floating sidebar available (even when all tools are OFF)");
        showSwitch.setTextColor(Ui.TEXT);
        showSwitch.setTextSize(15);
        showSwitch.setChecked(prefs.getBoolean("floating.enabled", true)
                && !prefs.getBoolean("floating.hidden", false));
        LinearLayout.LayoutParams showParams = new LinearLayout.LayoutParams(-1, -2);
        showParams.topMargin = Ui.dp(this, 10);
        visibilityCard.addView(showSwitch, showParams);
        showSwitch.setOnCheckedChangeListener((button, checked) -> {
            android.content.SharedPreferences.Editor editor = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .edit().putBoolean("floating.enabled", checked);
            if (checked) {
                editor.putBoolean("floating.hidden", false)
                        .putBoolean("floating.auto_hidden", false);
            } else {
                editor.putBoolean("floating.hidden", true)
                        .putBoolean("floating.auto_hidden", false);
            }
            editor.apply();
            if (checked && !FloatingControlService.hasOverlayPermission(this)) {
                Toast.makeText(this,
                        "Allow Display over other apps to show the floating sidebar.",
                        Toast.LENGTH_LONG).show();
                requestOverlayPermission();
            }
            FloatingControlService.refresh(this);
        });

        panelSwitch = new Switch(this);
        panelSwitch.setText("Open quick control panel when icon is tapped");
        panelSwitch.setTextColor(Ui.TEXT);
        panelSwitch.setTextSize(15);
        panelSwitch.setChecked(prefs.getBoolean("floating.panel.enabled", true));
        LinearLayout.LayoutParams panelParams = new LinearLayout.LayoutParams(-1, -2);
        panelParams.topMargin = Ui.dp(this, 12);
        visibilityCard.addView(panelSwitch, panelParams);
        panelSwitch.setOnCheckedChangeListener((button, checked) -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("floating.panel.enabled", checked).apply();
            FloatingControlService.refresh(this);
        });

        autoHideSwitch = new Switch(this);
        autoHideSwitch.setText("Auto-hide to the screen edge after 4 seconds");
        autoHideSwitch.setTextColor(Ui.TEXT);
        autoHideSwitch.setTextSize(15);
        autoHideSwitch.setChecked(prefs.getBoolean("floating.auto_hide", true));
        LinearLayout.LayoutParams autoHideParams = new LinearLayout.LayoutParams(-1, -2);
        autoHideParams.topMargin = Ui.dp(this, 12);
        visibilityCard.addView(autoHideSwitch, autoHideParams);
        autoHideSwitch.setOnCheckedChangeListener((button, checked) -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("floating.auto_hide", checked)
                    .putBoolean("floating.auto_hidden", false).apply();
            FloatingControlService.refresh(this);
        });
        Ui.addCard(this, body, visibilityCard, 16);

        LinearLayout appearanceCard = Ui.card(this);
        Ui.addText(this, appearanceCard, "Icon appearance", 18, Ui.TEXT, true, 0);

        int savedSize = Math.max(40, Math.min(76, prefs.getInt("floating.size", 54)));
        sizeLabel = Ui.addText(this, appearanceCard, "Icon size: " + savedSize + " dp", 14, Ui.ACCENT, true, 12);
        sizeSeek = new SeekBar(this);
        sizeSeek.setMax(36);
        sizeSeek.setProgress(savedSize - 40);
        appearanceCard.addView(sizeSeek, new LinearLayout.LayoutParams(-1, -2));
        sizeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sizeLabel.setText("Icon size: " + (40 + progress) + " dp");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putInt("floating.size", 40 + seekBar.getProgress()).apply();
                FloatingControlService.refresh(FloatingIconSettingsActivity.this);
            }
        });

        int savedOpacity = Math.max(30, Math.min(100, prefs.getInt("floating.opacity", 100)));
        opacityLabel = Ui.addText(this, appearanceCard, "Icon opacity: " + savedOpacity + "%", 14, Ui.ACCENT, true, 14);
        opacitySeek = new SeekBar(this);
        opacitySeek.setMax(70);
        opacitySeek.setProgress(savedOpacity - 30);
        appearanceCard.addView(opacitySeek, new LinearLayout.LayoutParams(-1, -2));
        opacitySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                opacityLabel.setText("Icon opacity: " + (30 + progress) + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putInt("floating.opacity", 30 + seekBar.getProgress()).apply();
                FloatingControlService.refresh(FloatingIconSettingsActivity.this);
            }
        });
        Ui.addCard(this, body, appearanceCard, 12);

        LinearLayout positionCard = Ui.card(this);
        Ui.addText(this, positionCard, "Position", 18, Ui.TEXT, true, 0);
        Ui.addText(this, positionCard,
                "Drag the ST bubble to move it anywhere. After 4 seconds without use, it tucks into a small tab on the nearest screen edge. Tap that tab to bring back the icon and quick controls.",
                13, Ui.MUTED, false, 6);
        android.widget.Button reset = Ui.button(this, "Reset icon position", () -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .remove("floating.x").remove("floating.y").apply();
            FloatingControlService.refresh(this);
            Toast.makeText(this, "Floating icon position reset.", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(-1, -2);
        resetParams.topMargin = Ui.dp(this, 12);
        positionCard.addView(reset, resetParams);
        Ui.addCard(this, body, positionCard, 12);

        LinearLayout permissionCard = Ui.card(this);
        Ui.addText(this, permissionCard, "Android permission", 16, Ui.TEXT, true, 0);
        Ui.addText(this, permissionCard,
                "Android requires Display over other apps permission. Once enabled, the floating sidebar stays available independently of whether Night Screen, Extra Volume, Thermal Monitor or Scanner is running.",
                13, Ui.MUTED, false, 6);
        android.widget.Button permission = Ui.button(this, "Open overlay permission settings", this::requestOverlayPermission);
        LinearLayout.LayoutParams permissionParams = new LinearLayout.LayoutParams(-1, -2);
        permissionParams.topMargin = Ui.dp(this, 12);
        permissionCard.addView(permission, permissionParams);
        Ui.addCard(this, body, permissionCard, 12);

        setContentView(page);
    }

    @Override protected void onResume() {
        super.onResume();
        FloatingControlService.refresh(this);
    }

    private void requestOverlayPermission() {
        if (FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this, "Overlay permission is already enabled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }
}
