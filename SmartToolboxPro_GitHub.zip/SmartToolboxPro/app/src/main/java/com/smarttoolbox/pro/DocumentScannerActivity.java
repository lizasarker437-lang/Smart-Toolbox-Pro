package com.smarttoolbox.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class DocumentScannerActivity extends Activity {
    private static final int REQ_CAMERA = 301;
    private static final int REQ_GALLERY = 302;
    private final List<Bitmap> pages = new ArrayList<>();
    private Uri cameraUri;
    private TextView countLabel;
    private TextView emptyHint;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = Ui.page(this, "Document Scanner");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body, "Capture pages or import images, then save them as a PDF.", 14, Ui.MUTED, false, 2);

        LinearLayout actions = Ui.card(this);
        android.widget.Button camera = Ui.button(this, "Open camera", this::openCamera);
        actions.addView(camera, new LinearLayout.LayoutParams(-1, -2));
        android.widget.Button gallery = Ui.button(this, "Choose images", this::openGallery);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = Ui.dp(this, 10);
        actions.addView(gallery, gp);
        Ui.addCard(this, body, actions, 18);

        LinearLayout preview = Ui.card(this);
        countLabel = Ui.addText(this, preview, "Pages selected: 0", 18, Ui.TEXT, true, 0);
        emptyHint = Ui.addText(this, preview, "No pages yet. Capture a document or choose images from your gallery.", 13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, preview, 12);

        android.widget.Button makePdf = Ui.button(this, "Create PDF", this::createPdf);
        Ui.addCard(this, body, makePdf, 14);
        android.widget.Button ocr = Ui.button(this, "Extract text (OCR)", this::extractText);
        Ui.addCard(this, body, ocr, 10);
        android.widget.Button clear = Ui.button(this, "Clear selected pages", () -> {
            pages.clear(); updateCount();
        });
        Ui.addCard(this, body, clear, 10);

        LinearLayout info = Ui.card(this);
        Ui.addText(this, info, "On-device processing", 16, Ui.ACCENT, true, 0);
        Ui.addText(this, info, "Images are kept in this app's private storage. PDF files are saved to Downloads/SmartToolboxPro on Android 10 and later. OCR runs on the selected page on this device.", 13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, info, 18);

        android.widget.Button floatingPermission = Ui.button(this, "Enable floating control permission", this::requestFloatingPermission);
        Ui.addCard(this, body, floatingPermission, 12);

        setContentView(page);
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putBoolean("scanner.active", true).apply();
        if (FloatingControlService.hasOverlayPermission(this)) FloatingControlService.start(this);
    }

    @Override protected void onResume() {
        super.onResume();
        if (getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("scanner.active", false)
                && FloatingControlService.hasOverlayPermission(this)) {
            FloatingControlService.refresh(this);
        }
    }

    @Override protected void onDestroy() {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putBoolean("scanner.active", false).apply();
        super.onDestroy();
        FloatingControlService.refresh(this);
    }

    private void requestFloatingPermission() {
        if (FloatingControlService.hasOverlayPermission(this)) {
            FloatingControlService.start(this);
            Toast.makeText(this, "Floating control is enabled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void openCamera() {
        try {
            File folder = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "scans");
            if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Cannot create scan folder");
            File output = new File(folder, "scan_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", output);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open camera: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, REQ_GALLERY);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        if (requestCode == REQ_CAMERA && cameraUri != null) {
            addImage(cameraUri);
        } else if (requestCode == REQ_GALLERY && data != null) {
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    Uri uri = data.getClipData().getItemAt(i).getUri();
                    addImage(uri);
                }
            } else if (data.getData() != null) addImage(data.getData());
        }
    }

    private void addImage(Uri uri) {
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IllegalStateException("Image could not be opened");
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            // Re-open the stream for bounds decoding, then decode at a safe size.
            try (InputStream bounds = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(bounds, null, options);
            }
            int sample = 1;
            while (options.outWidth / sample > 2200 || options.outHeight / sample > 3000) sample *= 2;
            BitmapFactory.Options decode = new BitmapFactory.Options();
            decode.inSampleSize = sample;
            Bitmap bitmap = BitmapFactory.decodeStream(input, null, decode);
            if (bitmap != null) {
                pages.add(bitmap);
                updateCount();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not load image: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void updateCount() {
        if (countLabel != null) countLabel.setText("Pages selected: " + pages.size());
        if (emptyHint != null) emptyHint.setText(pages.isEmpty()
                ? "No pages yet. Capture a document or choose images from your gallery."
                : "Ready to export. PDF pages will follow the order in which you selected them.");
    }

    private void createPdf() {
        if (pages.isEmpty()) {
            Toast.makeText(this, "Add at least one page first.", Toast.LENGTH_SHORT).show();
            return;
        }
        PdfDocument document = new PdfDocument();
        try {
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            for (int i = 0; i < pages.size(); i++) {
                Bitmap bitmap = pages.get(i);
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, i + 1).create();
                PdfDocument.Page page = document.startPage(info);
                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);
                float scale = Math.min(555f / bitmap.getWidth(), 802f / bitmap.getHeight());
                float width = bitmap.getWidth() * scale;
                float height = bitmap.getHeight() * scale;
                float left = (595f - width) / 2f;
                float top = (842f - height) / 2f;
                canvas.drawBitmap(bitmap, null, new RectF(left, top, left + width, top + height), paint);
                document.finishPage(page);
            }
            String name = "SmartToolbox_" + System.currentTimeMillis() + ".pdf";
            Uri savedUri = savePdf(document, name);
            Toast.makeText(this, "PDF saved: " + name, Toast.LENGTH_LONG).show();
            if (savedUri != null) sharePdf(savedUri);
        } catch (Exception e) {
            Toast.makeText(this, "PDF export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally {
            document.close();
        }
    }

    private Uri savePdf(PdfDocument document, String name) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SmartToolboxPro");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("Could not create PDF file");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IllegalStateException("Could not write PDF file");
                document.writeTo(output);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            return uri;
        } else {
            File folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "SmartToolboxPro");
            if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Cannot create documents folder");
            File file = new File(folder, name);
            try (FileOutputStream output = new FileOutputStream(file)) { document.writeTo(output); }
            return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        }
    }

    private void sharePdf(Uri uri) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("application/pdf");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(share, "Share PDF")); } catch (Exception ignored) {}
    }

    private void extractText() {
        if (pages.isEmpty()) {
            Toast.makeText(this, "Add an image first.", Toast.LENGTH_SHORT).show();
            return;
        }
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        InputImage image = InputImage.fromBitmap(pages.get(0), 0);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    String recognizedText = result.getText();
                    if (recognizedText == null || recognizedText.trim().isEmpty()) recognizedText = "No readable text found.";
                    final String finalText = recognizedText;
                    new AlertDialog.Builder(this)
                            .setTitle("Extracted text · Page 1")
                            .setMessage(finalText)
                            .setPositiveButton("Close", null)
                            .setNeutralButton("Copy", (dialog, which) -> {
                                android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("OCR text", finalText));
                                Toast.makeText(this, "Text copied", Toast.LENGTH_SHORT).show();
                            }).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "OCR failed: " + e.getMessage(), Toast.LENGTH_LONG).show())
                .addOnCompleteListener(task -> recognizer.close());
    }
}
