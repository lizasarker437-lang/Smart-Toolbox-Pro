package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;

/** Launcher-only short brand intro. No separate setting and no extra app permissions. */
public final class BrandSplashActivity extends Activity {
    private static final long INTRO_DURATION_MS = 1850L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable finishIntro = this::enterApp;
    private boolean entered;

    @Override public void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyToActivity(this);
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        FrameLayout canvas = new FrameLayout(this);
        GradientDrawable backdrop = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Ui.BG, Ui.CARD_2, Ui.BG});
        canvas.setBackground(backdrop);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER);
        column.setPadding(Ui.dp(this, 20), Ui.dp(this, 36),
                Ui.dp(this, 20), Ui.dp(this, 36));
        FrameLayout.LayoutParams columnParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        canvas.addView(column, columnParams);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("SR Smart Toolbox Pro app logo");
        column.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 115), Ui.dp(this, 115)));

        TextView brand = Ui.text(this, "SR CREATION FARM", 15, Ui.ACCENT, true);
        brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(-1, -2);
        brandLp.topMargin = Ui.dp(this, 23);
        column.addView(brand, brandLp);

        TextView app = Ui.text(this, "SR Smart Toolbox Pro", 28, Ui.TEXT, true);
        app.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams appLp = new LinearLayout.LayoutParams(-1, -2);
        appLp.topMargin = Ui.dp(this, 10);
        column.addView(app, appLp);

        TextView creator = Ui.text(this, "Created by Shahriar Rahman", 16, Ui.MUTED, false);
        creator.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams creditLp = new LinearLayout.LayoutParams(-1, -2);
        creditLp.topMargin = Ui.dp(this, 18);
        column.addView(creator, creditLp);

        TextView channel = Ui.text(this, "YouTube  @SRCreation-farm", 13, Ui.ACCENT, false);
        channel.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams channelLp = new LinearLayout.LayoutParams(-1, -2);
        channelLp.topMargin = Ui.dp(this, 16);
        column.addView(channel, channelLp);

        TextView facebook = Ui.text(this, "Facebook  fb.com/srcreation.farm", 13, Ui.MUTED, false);
        facebook.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams socialLp = new LinearLayout.LayoutParams(-1, -2);
        socialLp.topMargin = Ui.dp(this, 5);
        column.addView(facebook, socialLp);

        TextView version = Ui.text(this, "© 2026 SR Creation Farm   •   v1.5.12", 12, Ui.MUTED, false);
        version.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams versionLp = new FrameLayout.LayoutParams(-1, -2,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        versionLp.bottomMargin = Ui.dp(this, 32);
        canvas.addView(version, versionLp);
        canvas.setOnClickListener(v -> enterApp());
        canvas.setContentDescription("SR Creation Farm opening animation. Tap to skip.");
        setContentView(canvas);

        reveal(logo, 0, 700, true);
        reveal(brand, 180, 650, false);
        reveal(app, 330, 700, false);
        reveal(creator, 550, 650, false);
        reveal(channel, 750, 600, false);
        reveal(facebook, 900, 600, false);
        reveal(version, 1100, 550, false);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!entered) handler.postDelayed(finishIntro, INTRO_DURATION_MS);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(finishIntro);
        super.onPause();
    }

    private void reveal(View view, long delay, long duration, boolean zoom) {
        view.setAlpha(0f);
        if (zoom) {
            view.setScaleX(.72f);
            view.setScaleY(.72f);
        } else view.setTranslationY(Ui.dp(this, 18));
        view.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(delay).setDuration(duration).start();
    }

    private void enterApp() {
        if (entered || isFinishing() || isDestroyed()) return;
        entered = true;
        handler.removeCallbacks(finishIntro);
        Intent main = new Intent(this, MainActivity.class);
        // Reuse a previously opened Home rather than stacking duplicate Main activities.
        main.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(main);
        finish();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(finishIntro);
        super.onDestroy();
    }
}
