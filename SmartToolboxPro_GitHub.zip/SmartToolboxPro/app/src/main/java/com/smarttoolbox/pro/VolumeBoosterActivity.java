package com.smarttoolbox.pro;

import android.app.Activity;
import android.media.AudioManager;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class VolumeBoosterActivity extends Activity {
    private AudioManager audio;
    private int selectedStream = AudioManager.STREAM_MUSIC;
    private TextView mediaValue;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        LinearLayout page = Ui.page(this, "Volume Booster");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body, "Adjust your phone's built-in audio streams.", 14, Ui.MUTED, false, 2);

        LinearLayout media = Ui.card(this);
        Ui.addText(this, media, "Media volume", 19, Ui.TEXT, true, 0);
        mediaValue = Ui.addText(this, media, "", 14, Ui.ACCENT, true, 6);
        addStreamSlider(media, AudioManager.STREAM_MUSIC, mediaValue);
        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        int[] values = {40, 60, 80, 100};
        String[] labels = {"40%", "60%", "80%", "Max"};
        for (int i = 0; i < values.length; i++) {
            final int value = values[i];
            android.widget.Button b = Ui.button(this, labels[i], () -> setPercent(AudioManager.STREAM_MUSIC, value));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1);
            if (i != 0) p.leftMargin = Ui.dp(this, 6);
            presets.addView(b, p);
        }
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = Ui.dp(this, 10);
        media.addView(presets, pp);
        Ui.addCard(this, body, media, 18);

        LinearLayout ring = Ui.card(this);
        Ui.addText(this, ring, "Ringtone volume", 18, Ui.TEXT, true, 0);
        addStreamSlider(ring, AudioManager.STREAM_RING, null);
        Ui.addCard(this, body, ring, 12);

        LinearLayout notification = Ui.card(this);
        Ui.addText(this, notification, "Notification volume", 18, Ui.TEXT, true, 0);
        addStreamSlider(notification, AudioManager.STREAM_NOTIFICATION, null);
        Ui.addCard(this, body, notification, 12);

        LinearLayout info = Ui.card(this);
        Ui.addText(this, info, "About volume boost", 16, Ui.ACCENT, true, 0);
        Ui.addText(this, info, "Android and the phone's audio hardware set the maximum output. This tool controls the available system volume; it cannot safely force the speaker beyond its hardware limit. Equalizer and bass processing are device- and playback-app-dependent.", 13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, info, 18);
        setContentView(page);
    }

    private void addStreamSlider(LinearLayout parent, int stream, TextView valueLabel) {
        int max = audio.getStreamMaxVolume(stream);
        int current = audio.getStreamVolume(stream);
        if (valueLabel != null) valueLabel.setText(Math.round(current * 100f / Math.max(1, max)) + "%");
        SeekBar seek = new SeekBar(this);
        seek.setMax(max);
        seek.setProgress(current);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = Ui.dp(this, 6);
        parent.addView(seek, p);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser) audio.setStreamVolume(stream, progress, AudioManager.FLAG_SHOW_UI);
                if (valueLabel != null) valueLabel.setText(Math.round(progress * 100f / Math.max(1, max)) + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
    }

    private void setPercent(int stream, int percent) {
        int max = audio.getStreamMaxVolume(stream);
        int value = Math.max(0, Math.min(max, Math.round(max * percent / 100f)));
        audio.setStreamVolume(stream, value, AudioManager.FLAG_SHOW_UI);
        if (mediaValue != null) mediaValue.setText(Math.round(value * 100f / Math.max(1, max)) + "%");
    }
}
