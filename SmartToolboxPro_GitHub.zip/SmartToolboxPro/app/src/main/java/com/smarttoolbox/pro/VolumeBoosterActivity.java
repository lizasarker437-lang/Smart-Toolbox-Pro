package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class VolumeBoosterActivity extends Activity {
    private static final int REQ_AUDIO = 410;
    private Uri selectedAudio;
    private TextView selectedLabel;
    private TextView gainLabel;
    private TextView playbackStatus;
    private SeekBar gainSeek;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = Ui.page(this, "Extra Volume Booster");
        LinearLayout body = Ui.content(page);

        Ui.addText(this, body,
                "Boost a selected audio file inside Smart Toolbox Pro without changing your phone's volume slider.",
                14, Ui.MUTED, false, 2);

        LinearLayout selectCard = Ui.card(this);
        Ui.addText(this, selectCard, "1. Choose audio", 18, Ui.TEXT, true, 0);
        selectedLabel = Ui.addText(this, selectCard, "No audio file selected", 13, Ui.MUTED, false, 8);
        android.widget.Button choose = Ui.button(this, "Choose audio file", this::chooseAudio);
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(-1, -2);
        chooseParams.topMargin = Ui.dp(this, 12);
        selectCard.addView(choose, chooseParams);
        Ui.addCard(this, body, selectCard, 18);

        LinearLayout boostCard = Ui.card(this);
        Ui.addText(this, boostCard, "2. Extra digital gain", 18, Ui.TEXT, true, 0);
        gainLabel = Ui.addText(this, boostCard, "Extra gain: +0.0 dB", 14, Ui.ACCENT, true, 8);
        gainSeek = new SeekBar(this);
        gainSeek.setMax(1000);
        int savedGain = getSharedPreferences("tool_state", MODE_PRIVATE).getInt("audio.gain", 500);
        gainSeek.setProgress(Math.max(0, Math.min(1000, savedGain)));
        gainLabel.setText(formatGain(gainSeek.getProgress()));
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(-1, -2);
        seekParams.topMargin = Ui.dp(this, 6);
        boostCard.addView(gainSeek, seekParams);
        gainSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                gainLabel.setText(formatGain(progress));
                if (fromUser) getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                        .putInt("audio.gain", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        Ui.addCard(this, body, boostCard, 12);

        LinearLayout playback = Ui.card(this);
        Ui.addText(this, playback, "3. Play with extra boost", 18, Ui.TEXT, true, 0);
        playbackStatus = Ui.addText(this, playback, "Playback is stopped", 13, Ui.MUTED, false, 8);
        android.widget.Button play = Ui.button(this, "Play with Extra Volume", this::startBoost);
        LinearLayout.LayoutParams playParams = new LinearLayout.LayoutParams(-1, -2);
        playParams.topMargin = Ui.dp(this, 12);
        playback.addView(play, playParams);
        android.widget.Button stop = Ui.button(this, "Stop playback", this::stopBoost);
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, -2);
        stopParams.topMargin = Ui.dp(this, 8);
        playback.addView(stop, stopParams);
        Ui.addCard(this, body, playback, 12);

        LinearLayout note = Ui.card(this);
        Ui.addText(this, note, "Important limitation", 16, Ui.ACCENT, true, 0);
        Ui.addText(this, note,
                "This feature applies digital gain only to the audio file played by this screen. It does not change Android's media-volume setting and cannot boost YouTube, games, calls or other apps. The phone's master volume and speaker hardware remain the final output limit. High gain may cause distortion or damage hearing; start low.",
                13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, note, 18);

        android.widget.Button permission = Ui.button(this, "Enable floating control permission", this::requestFloatingPermission);
        Ui.addCard(this, body, permission, 12);

        setContentView(page);
    }

    private String formatGain(int millibels) {
        return String.format(java.util.Locale.getDefault(), "Extra gain: +%.1f dB", millibels / 100f);
    }

    private void chooseAudio() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_AUDIO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_AUDIO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedAudio = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                        selectedAudio, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) {}
            selectedLabel.setText(getDisplayName(selectedAudio));
            playbackStatus.setText("Audio file ready. Choose a gain level, then play.");
        }
    }

    private String getDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return uri.getLastPathSegment() == null ? "Selected audio file" : uri.getLastPathSegment();
    }

    private void requestFloatingPermission() {
        if (FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this, "Floating control permission is already enabled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    private void startBoost() {
        if (selectedAudio == null) {
            Toast.makeText(this, "Choose an audio file first.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this, "Allow Display over other apps, then tap Play again to show the floating control.", Toast.LENGTH_LONG).show();
            requestFloatingPermission();
            return;
        }

        int gain = gainSeek.getProgress();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putInt("audio.gain", gain).apply();

        Intent intent = new Intent(this, AudioBoostService.class);
        intent.setAction(AudioBoostService.ACTION_PLAY);
        intent.setDataAndType(selectedAudio, "audio/*");
        intent.putExtra(AudioBoostService.EXTRA_GAIN_MB, gain);
        ContextCompat.startForegroundService(this, intent);
        playbackStatus.setText("Preparing audio with " + formatGain(gain).replace("Extra gain: ", "") + " gain…");
    }

    private void stopBoost() {
        Intent intent = new Intent(this, AudioBoostService.class);
        intent.setAction(AudioBoostService.ACTION_STOP);
        startService(intent);
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("audio.active", false).apply();
        playbackStatus.setText("Playback is stopped");
        FloatingControlService.refresh(this);
    }

    @Override protected void onResume() {
        super.onResume();
        if (playbackStatus != null && getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.active", false)) {
            playbackStatus.setText("Extra-boost audio is playing. Use the floating ST icon to stop it.");
            FloatingControlService.refresh(this);
        }
    }
}
