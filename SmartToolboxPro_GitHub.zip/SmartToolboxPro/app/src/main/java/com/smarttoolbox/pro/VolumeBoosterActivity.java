package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class VolumeBoosterActivity extends Activity {
    private static final int MAX_GAIN_MB = 1000;
    private final Handler statusHandler = new Handler(Looper.getMainLooper());

    private SeekBar gainSeek;
    private TextView gainLabel;
    private TextView statusLabel;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = Ui.page(this, "System-Wide Extra Volume");
        LinearLayout body = Ui.content(page);

        Ui.addText(this, body,
                "Try to increase the loudness of the phone's global audio output, including sound from other apps, without moving the Android volume slider.",
                14, Ui.MUTED, false, 2);

        LinearLayout boostCard = Ui.card(this);
        Ui.addText(this, boostCard, "Global output gain", 18, Ui.TEXT, true, 0);
        int savedGain = Math.max(0, Math.min(MAX_GAIN_MB,
                getSharedPreferences("tool_state", MODE_PRIVATE).getInt("audio.gain", 400)));
        gainLabel = Ui.addText(this, boostCard, formatGain(savedGain), 14, Ui.ACCENT, true, 10);
        gainSeek = new SeekBar(this);
        gainSeek.setMax(MAX_GAIN_MB);
        gainSeek.setProgress(savedGain);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(-1, -2);
        seekParams.topMargin = Ui.dp(this, 6);
        boostCard.addView(gainSeek, seekParams);
        Ui.addText(this, boostCard, "0 dB = no extra gain · +10 dB = maximum app-requested boost",
                12, Ui.MUTED, false, 4);
        gainSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                gainLabel.setText(formatGain(progress));
                if (fromUser) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("audio.gain", progress).apply();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                if (getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getBoolean("audio.active", false)) {
                    sendGainUpdate(seekBar.getProgress());
                }
            }
        });
        Ui.addCard(this, body, boostCard, 18);

        LinearLayout actions = Ui.card(this);
        Ui.addText(this, actions, "System audio control", 18, Ui.TEXT, true, 0);
        statusLabel = Ui.addText(this, actions, "Global audio support has not been checked yet.",
                13, Ui.MUTED, false, 8);

        android.widget.Button start = Ui.button(this, "Turn on global audio boost", this::startBoost);
        LinearLayout.LayoutParams startParams = new LinearLayout.LayoutParams(-1, -2);
        startParams.topMargin = Ui.dp(this, 12);
        actions.addView(start, startParams);

        android.widget.Button stop = Ui.button(this, "Turn off global audio boost", this::stopBoost);
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, -2);
        stopParams.topMargin = Ui.dp(this, 8);
        actions.addView(stop, stopParams);
        Ui.addCard(this, body, actions, 12);

        LinearLayout note = Ui.card(this);
        Ui.addText(this, note, "Important Android / device limitation", 16, Ui.ACCENT, true, 0);
        Ui.addText(this, note,
                "This feature requests a global output-mix audio effect (session 0). Android deprecates or restricts global effects on some versions and phone brands. It may work for other apps on supported devices, but Android does not guarantee it. If the phone blocks the effect, the app will show Unsupported. This does not raise the speaker hardware's physical limit; high gain can distort sound or harm hearing.",
                13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, note, 18);

        android.widget.Button permission = Ui.button(this, "Enable floating icon permission", this::requestFloatingPermission);
        Ui.addCard(this, body, permission, 12);

        setContentView(page);
    }

    private String formatGain(int millibels) {
        return String.format(java.util.Locale.getDefault(),
                "Extra global gain: +%.1f dB", millibels / 100f);
    }

    private void startBoost() {
        int gain = gainSeek.getProgress();
        Intent intent = new Intent(this, SystemAudioBoostService.class);
        intent.setAction(SystemAudioBoostService.ACTION_START);
        intent.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB, gain);
        ContextCompat.startForegroundService(this, intent);
        statusLabel.setText("Checking whether this phone allows global audio processing…");
        statusHandler.postDelayed(this::updateStatus, 800);
        if (!FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this,
                    "Audio boost is starting. Allow overlay permission if you also want the floating icon.",
                    Toast.LENGTH_LONG).show();
            requestFloatingPermission();
        }
    }

    private void sendGainUpdate(int gain) {
        Intent intent = new Intent(this, SystemAudioBoostService.class);
        intent.setAction(SystemAudioBoostService.ACTION_UPDATE);
        intent.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB, gain);
        startService(intent);
    }

    private void stopBoost() {
        Intent intent = new Intent(this, SystemAudioBoostService.class);
        intent.setAction(SystemAudioBoostService.ACTION_STOP);
        startService(intent);
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("audio.active", false)
                .putString("audio.status", "Global audio boost is off.")
                .apply();
        updateStatus();
        FloatingControlService.refresh(this);
    }

    private void updateStatus() {
        if (statusLabel == null) return;
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean active = prefs.getBoolean("audio.active", false);
        String status = prefs.getString("audio.status", "");
        if (status == null || status.trim().isEmpty()) {
            status = active ? "Global audio boost is active." : "Global audio support has not been checked yet.";
        }
        statusLabel.setText((active ? "ON · " : "OFF · ") + status);
    }

    private void requestFloatingPermission() {
        if (FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this, "Floating icon permission is already enabled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
        if (getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("audio.active", false)) {
            FloatingControlService.refresh(this);
        }
    }

    @Override protected void onDestroy() {
        statusHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
