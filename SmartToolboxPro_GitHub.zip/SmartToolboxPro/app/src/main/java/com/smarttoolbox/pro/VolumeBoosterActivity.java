package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class VolumeBoosterActivity extends Activity {
    private static final int MAX_GAIN_MB = 1000;
    private static final int BAND_COUNT = 5;

    private static final String[] BAND_NAMES = {
            "Bass · 60 Hz", "Low Mid · 230 Hz", "Mid · 910 Hz",
            "High Mid · 3.6 kHz", "Treble · 14 kHz"
    };

    private static final String[] PRESET_NAMES = {
            "Custom", "Balanced", "Bass Boost", "Vocal", "Rock",
            "Classical", "Treble", "Podcast"
    };

    // Five-band values are in dB, clamped to -15 dB .. +15 dB.
    private static final int[][] PRESET_BANDS = {
            {0, 0, 0, 0, 0},          // Custom placeholder
            {0, 0, 0, 0, 0},          // Balanced
            {10, 7, 3, 0, 0},         // Bass Boost
            {-3, -1, 4, 6, 3},        // Vocal
            {6, 3, -2, 4, 7},         // Rock
            {4, 2, 0, 3, 5},          // Classical
            {0, -2, 0, 6, 10},        // Treble
            {-2, 0, 5, 4, -1}         // Podcast
    };

    private static final int[] PRESET_BASS = {
            0, 150, 850, 200, 550, 300, 100, 100
    };
    private static final int[] PRESET_VIRTUALIZER = {
            0, 100, 100, 150, 500, 300, 150, 0
    };

    private final Handler statusHandler = new Handler(Looper.getMainLooper());
    private final Handler equalizerHandler = new Handler(Looper.getMainLooper());

    private Runnable pendingEqualizerUpdate;
    private SeekBar gainSeek;
    private TextView gainLabel;
    private TextView statusLabel;

    private SeekBar[] bandSeeks = new SeekBar[BAND_COUNT];
    private TextView[] bandLabels = new TextView[BAND_COUNT];
    private SeekBar bassSeek;
    private SeekBar virtualizerSeek;
    private TextView bassLabel;
    private TextView virtualizerLabel;
    private Spinner presetSpinner;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = Ui.page(this, "Extra Volume & Equalizer");
        LinearLayout body = Ui.content(page);

        Ui.addText(this, body,
                "Control global master output gain and shape the sound with bass, treble, a five-band equalizer and spatial audio effects. Global processing depends on Android and phone support.",
                14, Ui.MUTED, false, 2);

        buildMasterVolumeCard(body);
        buildEqualizerCard(body);
        buildSystemControlCard(body);
        buildDeviceNote(body);

        android.widget.Button permission = Ui.button(this,
                "Enable floating icon permission", this::requestFloatingPermission);
        Ui.addCard(this, body, permission, 12);

        setContentView(page);
    }

    private void buildMasterVolumeCard(LinearLayout body) {
        LinearLayout boostCard = Ui.card(this);
        Ui.addText(this, boostCard, "Master Volume Control", 18, Ui.TEXT, true, 0);
        Ui.addText(this, boostCard,
                "Extra output gain applied to the global audio mix where the phone allows it. This is separate from the Android volume slider.",
                13, Ui.MUTED, false, 6);

        int savedGain = Math.max(0, Math.min(MAX_GAIN_MB,
                getSharedPreferences("tool_state", MODE_PRIVATE).getInt("audio.gain", 400)));
        gainLabel = Ui.addText(this, boostCard, formatGain(savedGain),
                14, Ui.ACCENT, true, 10);
        gainSeek = new SeekBar(this);
        gainSeek.setMax(MAX_GAIN_MB);
        gainSeek.setProgress(savedGain);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(-1, -2);
        seekParams.topMargin = Ui.dp(this, 6);
        boostCard.addView(gainSeek, seekParams);
        Ui.addText(this, boostCard,
                "0 dB = no extra master gain · +10 dB = maximum requested gain",
                12, Ui.MUTED, false, 4);

        gainSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                gainLabel.setText(formatGain(progress));
                if (fromUser) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("audio.gain", progress).apply();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                if (isAudioProcessingActive()) sendGainUpdate(seekBar.getProgress());
            }
        });
        Ui.addCard(this, body, boostCard, 18);
    }

    private void buildEqualizerCard(LinearLayout body) {
        LinearLayout eqCard = Ui.card(this);
        Ui.addText(this, eqCard, "Equalizer & Sound Effects", 18, Ui.TEXT, true, 0);
        Ui.addText(this, eqCard,
                "Choose a sound profile or adjust each frequency band. Bass Boost and Virtualizer are separate controls.",
                13, Ui.MUTED, false, 6);

        Ui.addText(this, eqCard, "Sound Profile", 14, Ui.ACCENT, true, 12);
        presetSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, PRESET_NAMES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        presetSpinner.setAdapter(adapter);
        presetSpinner.setSelection(0, false);
        LinearLayout.LayoutParams spinnerParams = new LinearLayout.LayoutParams(-1, -2);
        spinnerParams.topMargin = Ui.dp(this, 4);
        eqCard.addView(presetSpinner, spinnerParams);
        presetSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view,
                                                 int position, long id) {
                if (position > 0) applyPreset(position);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        Ui.addText(this, eqCard, "Five-band equalizer · -15 dB to +15 dB",
                14, Ui.ACCENT, true, 14);
        for (int i = 0; i < BAND_COUNT; i++) {
            int savedDb = getSharedPreferences("tool_state", MODE_PRIVATE)
                    .getInt("audio.eq.band." + i, 0);
            savedDb = Math.max(-15, Math.min(15, savedDb));
            addBandControl(eqCard, i, savedDb);
        }

        Ui.addText(this, eqCard, "Bass Boost", 14, Ui.ACCENT, true, 16);
        int savedBass = Math.max(0, Math.min(1000,
                getSharedPreferences("tool_state", MODE_PRIVATE).getInt("audio.bass", 0)));
        bassLabel = Ui.addText(this, eqCard, formatStrength("Bass strength", savedBass),
                13, Ui.TEXT, false, 4);
        bassSeek = new SeekBar(this);
        bassSeek.setMax(100);
        bassSeek.setProgress(savedBass / 10);
        eqCard.addView(bassSeek, new LinearLayout.LayoutParams(-1, -2));
        bassSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int strength = progress * 10;
                bassLabel.setText(formatStrength("Bass strength", strength));
                if (fromUser) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("audio.bass", strength).apply();
                    selectCustomProfile();
                    scheduleEqualizerUpdate();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                flushEqualizerUpdate();
            }
        });

        Ui.addText(this, eqCard, "Virtualizer / Spatial Effect", 14, Ui.ACCENT, true, 16);
        int savedVirtualizer = Math.max(0, Math.min(1000,
                getSharedPreferences("tool_state", MODE_PRIVATE).getInt("audio.virtualizer", 0)));
        virtualizerLabel = Ui.addText(this, eqCard,
                formatStrength("Spatial strength", savedVirtualizer), 13, Ui.TEXT, false, 4);
        virtualizerSeek = new SeekBar(this);
        virtualizerSeek.setMax(100);
        virtualizerSeek.setProgress(savedVirtualizer / 10);
        eqCard.addView(virtualizerSeek, new LinearLayout.LayoutParams(-1, -2));
        virtualizerSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int strength = progress * 10;
                virtualizerLabel.setText(formatStrength("Spatial strength", strength));
                if (fromUser) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("audio.virtualizer", strength).apply();
                    selectCustomProfile();
                    scheduleEqualizerUpdate();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                flushEqualizerUpdate();
            }
        });

        Ui.addText(this, eqCard,
                "The five displayed bands are mapped to the available hardware EQ bands. Exact frequencies and supported effects can vary by phone.",
                12, Ui.MUTED, false, 10);
        Ui.addCard(this, body, eqCard, 14);
    }

    private void addBandControl(LinearLayout container, int index, int savedDb) {
        TextView label = Ui.addText(this, container,
                formatBandLabel(index, savedDb), 13, Ui.TEXT, false, index == 0 ? 4 : 10);
        SeekBar seek = new SeekBar(this);
        seek.setMax(30);
        seek.setProgress(savedDb + 15);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = Ui.dp(this, 1);
        container.addView(seek, params);
        bandSeeks[index] = seek;
        bandLabels[index] = label;

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int db = progress - 15;
                label.setText(formatBandLabel(index, db));
                if (fromUser) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("audio.eq.band." + index, db).apply();
                    selectCustomProfile();
                    scheduleEqualizerUpdate();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                flushEqualizerUpdate();
            }
        });
    }

    private void buildSystemControlCard(LinearLayout body) {
        LinearLayout actions = Ui.card(this);
        Ui.addText(this, actions, "Audio Processing", 18, Ui.TEXT, true, 0);
        statusLabel = Ui.addText(this, actions,
                "Audio processing has not been checked yet.", 13, Ui.MUTED, false, 8);

        android.widget.Button start = Ui.button(this,
                "Turn on Master Volume & Equalizer", this::startBoost);
        LinearLayout.LayoutParams startParams = new LinearLayout.LayoutParams(-1, -2);
        startParams.topMargin = Ui.dp(this, 12);
        actions.addView(start, startParams);

        android.widget.Button stop = Ui.button(this,
                "Turn off all audio processing", this::stopBoost);
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, -2);
        stopParams.topMargin = Ui.dp(this, 8);
        actions.addView(stop, stopParams);
        Ui.addCard(this, body, actions, 12);
    }

    private void buildDeviceNote(LinearLayout body) {
        LinearLayout note = Ui.card(this);
        Ui.addText(this, note, "Android / device compatibility", 16, Ui.ACCENT, true, 0);
        Ui.addText(this, note,
                "Master gain, the five-band Equalizer, Bass Boost and Virtualizer request global output-mix effects (audio session 0). Android and some phone manufacturers restrict these effects. The app checks each effect separately and reports which controls are unavailable. This cannot raise the physical speaker's hardware limit. Excessive gain can distort sound and risk hearing damage.",
                13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, note, 18);
    }

    private String formatGain(int millibels) {
        return String.format(java.util.Locale.getDefault(),
                "Master extra gain: +%.1f dB", millibels / 100f);
    }

    private String formatBandLabel(int index, int db) {
        return BAND_NAMES[index] + "  ·  " + (db > 0 ? "+" : "")
                + db + " dB";
    }

    private String formatStrength(String title, int strength) {
        return title + "  ·  " + (strength / 10) + "%";
    }

    private void applyPreset(int position) {
        if (position < 1 || position >= PRESET_BANDS.length) return;
        android.content.SharedPreferences.Editor editor =
                getSharedPreferences("tool_state", MODE_PRIVATE).edit();

        for (int i = 0; i < BAND_COUNT; i++) {
            int db = PRESET_BANDS[position][i];
            editor.putInt("audio.eq.band." + i, db);
            if (bandSeeks[i] != null) bandSeeks[i].setProgress(db + 15);
        }

        int bass = PRESET_BASS[position];
        int virtualizer = PRESET_VIRTUALIZER[position];
        editor.putInt("audio.bass", bass)
                .putInt("audio.virtualizer", virtualizer)
                .apply();

        if (bassSeek != null) bassSeek.setProgress(bass / 10);
        if (virtualizerSeek != null) virtualizerSeek.setProgress(virtualizer / 10);
        flushEqualizerUpdate();
    }

    private void selectCustomProfile() {
        if (presetSpinner != null && presetSpinner.getSelectedItemPosition() != 0) {
            presetSpinner.setSelection(0);
        }
    }

    private void scheduleEqualizerUpdate() {
        if (!isAudioProcessingActive()) return;
        if (pendingEqualizerUpdate != null) {
            equalizerHandler.removeCallbacks(pendingEqualizerUpdate);
        }
        pendingEqualizerUpdate = this::sendEqualizerUpdate;
        equalizerHandler.postDelayed(pendingEqualizerUpdate, 120);
    }

    private void flushEqualizerUpdate() {
        if (pendingEqualizerUpdate != null) {
            equalizerHandler.removeCallbacks(pendingEqualizerUpdate);
            pendingEqualizerUpdate = null;
        }
        if (isAudioProcessingActive()) sendEqualizerUpdate();
    }

    private boolean isAudioProcessingActive() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.active", false);
    }

    private void sendEqualizerUpdate() {
        pendingEqualizerUpdate = null;
        Intent intent = new Intent(this, SystemAudioBoostService.class);
        intent.setAction(SystemAudioBoostService.ACTION_UPDATE_EQ);
        ContextCompat.startForegroundService(this, intent);
        statusHandler.postDelayed(this::updateStatus, 350);
    }

    private void startBoost() {
        int gain = gainSeek.getProgress();
        Intent intent = new Intent(this, SystemAudioBoostService.class);
        intent.setAction(SystemAudioBoostService.ACTION_START);
        intent.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB, gain);
        ContextCompat.startForegroundService(this, intent);
        statusLabel.setText("Checking master gain, equalizer and sound-effect support…");
        statusHandler.postDelayed(this::updateStatus, 900);
        if (!FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this,
                    "Audio processing is starting. Allow overlay permission if you also want the floating icon.",
                    Toast.LENGTH_LONG).show();
            requestFloatingPermission();
        }
    }

    private void sendGainUpdate(int gain) {
        Intent intent = new Intent(this, SystemAudioBoostService.class);
        intent.setAction(SystemAudioBoostService.ACTION_UPDATE);
        intent.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB, gain);
        startService(intent);
        statusHandler.postDelayed(this::updateStatus, 350);
    }

    private void stopBoost() {
        Intent intent = new Intent(this, SystemAudioBoostService.class);
        intent.setAction(SystemAudioBoostService.ACTION_STOP);
        startService(intent);
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("audio.active", false)
                .putString("audio.status", "All audio processing is off.")
                .apply();
        updateStatus();
        FloatingControlService.refresh(this);
    }

    private void updateStatus() {
        if (statusLabel == null) return;
        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean active = prefs.getBoolean("audio.active", false);
        String status = prefs.getString("audio.status", "");
        if (status == null || status.trim().isEmpty()) {
            status = active ? "Audio processing is active."
                    : "Audio processing has not been checked yet.";
        }
        statusLabel.setText((active ? "ON · " : "OFF · ") + status);
    }

    private void requestFloatingPermission() {
        if (FloatingControlService.hasOverlayPermission(this)) {
            Toast.makeText(this, "Floating icon permission is already enabled.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
        if (isAudioProcessingActive()) {
            FloatingControlService.refresh(this);
        }
    }

    @Override protected void onDestroy() {
        statusHandler.removeCallbacksAndMessages(null);
        equalizerHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
