package com.smarttoolbox.pro;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.speech.RecognizerIntent;
import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings;
import android.text.method.PasswordTransformationMethod;
import android.widget.Switch;
import java.util.Arrays;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.time.ZoneId;
import java.util.Locale;
import java.util.UUID;

public final class MessageSchedulerActivity extends Activity {
    private static final int REQUEST_CONTACT = 4201;
    private static final int REQUEST_VOICE = 4202;
    private static final int REQUEST_NOTIFICATIONS = 4203;
    private static final int REQUEST_GROUP_CONTACTS = 4204;
    private static final String EXTRA_SETTINGS_ONLY = "scheduler_settings_only";
    private static final int MENU_SETTINGS = 9101;
    private static final int MENU_RECIPIENTS = 9102;
    private static final int MENU_TEMPLATES = 9103;
    private static final int MENU_TEST = 9104;
    private static final int MENU_MANAGE_TEMPLATES = 9105;
    private static final int MENU_NOTEPAD = 9106;

    private final Calendar selectedTime = Calendar.getInstance();
    private EditText nameInput;
    private LinearLayout singleNameSection;
    private EditText groupNameInput;
    private LinearLayout groupNameSection;
    private EditText phoneInput;
    private EditText messageInput;
    private Spinner repeatSpinner;
    private RadioGroup recipientModeGroup;
    private RadioButton singleModeButton;
    private RadioButton groupModeButton;
    private TextView dateButton;
    private TextView timeButton;
    private TextView permissionStatus;
    private TextView accessibilityStatus;
    private EditText automationPin;
    private Switch autoSwitch;
    private Switch unlockSwitch;
    private Switch relockSwitch;
    private LinearLayout schedulesContainer;
    private static final String SECTION_PREFS = "sr_scheduler_section_ui_v1";
    private String lastSectionSignature = "";
    private LinearLayout recipientsContainer;
    private LinearLayout quickTemplateRow;
    private boolean recipientsExpanded;
    private boolean settingsOnly;
    private final List<CountdownView> countdownViews = new ArrayList<>();
    private final Handler countdownHandler = new Handler(Looper.getMainLooper());
    private final Runnable countdownUpdater = new Runnable() {
        @Override public void run() {
            refreshCountdowns();
            countdownHandler.postDelayed(this, 1000L);
        }
    };
    private ScrollView pageScroll;
    private String editingId;
    private final Map<String, String> selectedContactNames = new HashMap<>();
    private int themeWhenCreated;
    private static final int MODE_SINGLE = 1;
    private static final int MODE_GROUP = 2;

    private static final class CountdownView {
        final String id;
        final TextView label;
        CountdownView(String id, TextView label) {
            this.id = id;
            this.label = label;
        }
    }

    private static final String[] REPEAT_LABELS = {
            "একবার", "প্রতিদিন", "প্রতি সপ্তাহে"
    };
    private static final String[] REPEAT_VALUES = {
            "once", "daily", "weekly"
    };

    @Override public void onCreate(Bundle state) {
        ThemeManager.applyToActivity(this);
        super.onCreate(state);
        themeWhenCreated = ThemeManager.styleKey(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        selectedTime.add(Calendar.MINUTE, 10);
        selectedTime.set(Calendar.SECOND, 0);
        selectedTime.set(Calendar.MILLISECOND, 0);

        settingsOnly = getIntent() != null
                && getIntent().getBooleanExtra(EXTRA_SETTINGS_ONLY, false);
        LinearLayout page = Ui.page(this, settingsOnly
                ? "⚙ Scheduler Settings" : "🗓️ WhatsApp Smart Scheduler");
        pageScroll = (ScrollView) page.getChildAt(1);
        LinearLayout body = Ui.content(page);

        if (settingsOnly) {
            Ui.addText(this, body,
                    "Alarm, Notification এবং Experimental Automation-এর সেটিংস এখানে থাকবে। "
                    + "এগুলো পরিবর্তন করলে আগের শিডিউল মুছে যাবে না।",
                    13, Ui.MUTED, false, 2);
            buildPermissionCard(body);
            buildAutomationCard(body);
            setContentView(page);
            updatePermissionStatus();
            updateAutomationStatus();
            return;
        }

        LinearLayout header = (LinearLayout) page.getChildAt(0);
        TextView overflow = Ui.text(this, "⋮", 29, Ui.ACCENT, true);
        overflow.setGravity(Gravity.CENTER);
        overflow.setContentDescription("Scheduler options and settings");
        overflow.setClickable(true);
        overflow.setFocusable(true);
        header.addView(overflow, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 52)));
        overflow.setOnClickListener(v -> showSchedulerMenu(overflow));

        Ui.addText(this, body,
                "মেসেজ লিখুন, প্রাপক বাছুন এবং সময় নির্ধারণ করুন। "
                + "Alarm ও Automation সেটিংস উপরের ⋮ মেনুতে পাবেন।",
                13, Ui.MUTED, false, 2);

        buildComposer(body);
        buildScheduleList(body);

        setContentView(page);
        renderSchedules();
        renderRecipientHistory();
    }

    private void showSchedulerMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        Menu menu = popup.getMenu();
        menu.add(Menu.NONE, MENU_SETTINGS, 0, "⚙ Alarm, Notification & Automation Settings");
        menu.add(Menu.NONE, MENU_RECIPIENTS, 1, "👥 Recent Recipient Numbers");
        menu.add(Menu.NONE, MENU_TEMPLATES, 2, "⚡ Quick Message Templates");
        menu.add(Menu.NONE, MENU_TEST, 3, "🧪 Test after 10 seconds");
        menu.add(Menu.NONE, MENU_MANAGE_TEMPLATES, 4, "✏️ Manage / Add Quick Templates");
        menu.add(Menu.NONE, MENU_NOTEPAD, 5, "📝 Scheduler Notepad");
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case MENU_SETTINGS:
                    Intent settings = new Intent(this, MessageSchedulerActivity.class);
                    settings.putExtra(EXTRA_SETTINGS_ONLY, true);
                    startActivity(settings);
                    return true;
                case MENU_RECIPIENTS:
                    recipientsExpanded = true;
                    renderRecipientHistory();
                    if (pageScroll != null && recipientsContainer != null) {
                        pageScroll.post(() -> pageScroll.smoothScrollTo(0,
                                Math.max(0, recipientsContainer.getTop() - Ui.dp(this, 80))));
                    }
                    return true;
                case MENU_TEMPLATES:
                    showTemplatePicker();
                    return true;
                case MENU_TEST:
                    testAfterTenSeconds();
                    return true;
                case MENU_MANAGE_TEMPLATES:
                    showTemplateManager();
                    return true;
                case MENU_NOTEPAD:
                    openSchedulerNotepad();
                    return true;
                default: return false;
            }
        });
        popup.show();
    }

    private void buildPermissionCard(LinearLayout body) {
        LinearLayout card = Ui.card(this);
        Ui.addText(this, card, "Smart Scheduler permissions", 16, Ui.TEXT, true, 0);
        permissionStatus = Ui.addText(this, card, "Checking alarm and notification access…",
                12, Ui.MUTED, false, 6);
        addActionButton(card, "Enable precise schedule", this::requestExactAlarmAccess);
        addActionButton(card, "Allow reminder notifications", this::requestNotificationPermission);
        Ui.addCard(this, body, card, 12);
    }

    private void buildAutomationCard(LinearLayout body) {
        LinearLayout card = Ui.card(this);
        Ui.addText(this, card, "🧪 Experimental Auto-Send & Unlock", 18, Ui.ACCENT, true, 0);
        Ui.addText(this, card,
                "নিজের ফোনে পরীক্ষামূলক Accessibility Automation। ডিফল্ট OFF। "
                + "WhatsApp-এর UI পরিবর্তন হলে পাঠানো ব্যর্থ হতে পারে। একাধিক/অনাকাঙ্ক্ষিত "
                + "স্বয়ংক্রিয় মেসেজ পাঠাবেন না। Send বাটনে ক্লিক করা মানেই Delivery নয়।",
                12, Ui.MUTED, false, 8);

        autoSwitch = new Switch(this);
        autoSwitch.setText("Enable experimental automatic WhatsApp Send");
        autoSwitch.setTextColor(Ui.TEXT);
        autoSwitch.setChecked(AutoSendPreferences.enabled(this));
        autoSwitch.setOnCheckedChangeListener((button, checked) -> {
            AutoSendPreferences.setEnabled(this, checked);
            MessageScheduleStore.rescheduleAll(this);
            updateAutomationStatus();
        });
        LinearLayout.LayoutParams switchParams = new LinearLayout.LayoutParams(-1, -2);
        switchParams.topMargin = Ui.dp(this, 12);
        card.addView(autoSwitch, switchParams);

        unlockSwitch = new Switch(this);
        unlockSwitch.setText("Attempt owner PIN unlock (experimental, one try)");
        unlockSwitch.setTextColor(Ui.TEXT);
        unlockSwitch.setChecked(AutoSendPreferences.experimentalUnlock(this));
        unlockSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (checked && !SecurePinVault.exists(this)) {
                unlockSwitch.setChecked(false);
                Toast.makeText(this, "আগে নিচে PIN সেভ করুন।", Toast.LENGTH_LONG).show();
            } else {
                AutoSendPreferences.setExperimentalUnlock(this, checked);
            }
            updateAutomationStatus();
        });
        LinearLayout.LayoutParams unlockParams = new LinearLayout.LayoutParams(-1, -2);
        unlockParams.topMargin = Ui.dp(this, 8);
        card.addView(unlockSwitch, unlockParams);

        relockSwitch = new Switch(this);
        relockSwitch.setText("If originally locked: Home → Lock again");
        relockSwitch.setTextColor(Ui.TEXT);
        relockSwitch.setChecked(AutoSendPreferences.relock(this));
        relockSwitch.setOnCheckedChangeListener((button, checked) ->
                AutoSendPreferences.setRelock(this, checked));
        card.addView(relockSwitch, new LinearLayout.LayoutParams(-1, -2));

        Ui.addText(this, card,
                "⚠ Secure Android keyguard-এর Unlock নিশ্চিত নয়। নিজের PIN এই অ্যাপের "
                + "Android Keystore-encrypted storage-এ থাকবে। এটি ঝুঁকিপূর্ণ: ফোনের Accessibility "
                + "অনুমতি শুধু বিশ্বস্ত অ্যাপেই দিন। PIN কখনো লগ বা ইন্টারনেটে পাঠানো হয় না।",
                12, Ui.MUTED, false, 12);
        automationPin = createInput("নিজের ফোনের ৪–১২ সংখ্যার PIN", false);
        automationPin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        automationPin.setTransformationMethod(PasswordTransformationMethod.getInstance());
        addField(card, "Experimental owner PIN (optional)", automationPin);
        addActionButton(card, "🔒 Save encrypted PIN", () -> {
            char[] pin = automationPin.getText().toString().toCharArray();
            boolean stored = SecurePinVault.store(this, pin);
            Arrays.fill(pin, '\0');
            automationPin.setText("");
            Toast.makeText(this, stored ? "PIN encrypted and saved locally." :
                    "PIN সেভ করা যায়নি। ৪–১২টি সংখ্যা দিন।", Toast.LENGTH_LONG).show();
            updateAutomationStatus();
        });
        addActionButton(card, "🗑 Delete stored PIN", () -> {
            SecurePinVault.clear(this);
            unlockSwitch.setChecked(false);
            automationPin.setText("");
            updateAutomationStatus();
            Toast.makeText(this, "Stored PIN cleared.", Toast.LENGTH_SHORT).show();
        });
        addActionButton(card, "🖥 Allow 3s on-screen overlay", () -> {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception ignored) {
                Toast.makeText(this, "Display over other apps settings unavailable.",
                        Toast.LENGTH_SHORT).show();
            }
        });
        addActionButton(card, "♿ Enable Accessibility Service", () -> {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception error) {
                Toast.makeText(this, "Android Accessibility settings unavailable.",
                        Toast.LENGTH_LONG).show();
            }
        });
        accessibilityStatus = Ui.addText(this, card, "Checking Accessibility…",
                12, Ui.MUTED, false, 10);
        Ui.addText(this, card,
                "🔔 ফোন চালু থাকলে মেসেজের সময়ের ৩ সেকেন্ড আগে "
                + "screen overlay দেখাবে (Display over other apps Permission দরকার)। "
                + "পাঠানোর পর আগের অ্যাপে Back করবে। আগে Locked থাকলে Home → Lock চেষ্টা করবে। "
                + "কোনো ধাপে ব্যর্থ হলে WhatsApp draft সহ সাধারণ Reminder আসবে। "
                + "Android-এর battery/lock/gesture restriction-এর কারণে সময় বা আচরণ বদলাতে পারে।",
                12, Ui.MUTED, false, 12);
        Ui.addCard(this, body, card, 12);
        updateAutomationStatus();
    }

    private void updateAutomationStatus() {
        if (accessibilityStatus == null) return;
        accessibilityStatus.setText(
                (ScheduledWhatsAppAccessibilityService.isConnected() ?
                        "✓ Accessibility Service connected" : "⚠ Enable SR Scheduled WhatsApp Accessibility Service")
                + "\n" + (SecurePinVault.exists(this) ? "Encrypted PIN saved" : "No PIN stored")
                + "\n" + (AutoSendPreferences.enabled(this) ?
                        "Experimental auto-send is ON" : "Safe reminder-only mode (OFF)"));
    }

    private void buildComposer(LinearLayout body) {
        LinearLayout card = Ui.card(this);
        Ui.addText(this, card, "✍️ নতুন WhatsApp মেসেজ শিডিউল", 18, Ui.ACCENT, true, 0);

        singleNameSection = new LinearLayout(this);
        singleNameSection.setOrientation(LinearLayout.VERTICAL);
        nameInput = createInput("প্রাপকের নাম (ঐচ্ছিক)", false);
        addField(singleNameSection, "Single recipient name", nameInput);
        card.addView(singleNameSection);

        phoneInput = createInput("ফোন নম্বর লিখুন; একাধিক হলে কমা দিয়ে আলাদা করুন", false);
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);
        addField(card, "WhatsApp নম্বর / প্রাপক তালিকা", phoneInput);

        Ui.addText(this, card, "মেসেজের ধরন", 13, Ui.MUTED, true, 12);
        recipientModeGroup = new RadioGroup(this);
        recipientModeGroup.setOrientation(RadioGroup.HORIZONTAL);
        singleModeButton = new RadioButton(this);
        singleModeButton.setId(MODE_SINGLE);
        singleModeButton.setText("👤 Single message");
        singleModeButton.setTextColor(Ui.TEXT);
        groupModeButton = new RadioButton(this);
        groupModeButton.setId(MODE_GROUP);
        groupModeButton.setText("👥 Group / Broadcast");
        groupModeButton.setTextColor(Ui.TEXT);
        recipientModeGroup.addView(singleModeButton, new RadioGroup.LayoutParams(0, -2, 1f));
        recipientModeGroup.addView(groupModeButton, new RadioGroup.LayoutParams(0, -2, 1f));
        recipientModeGroup.check(MODE_SINGLE);
        recipientModeGroup.setOnCheckedChangeListener((group, checkedId) -> updateRecipientModeUi());
        LinearLayout.LayoutParams modeParams = new LinearLayout.LayoutParams(-1, -2);
        modeParams.topMargin = Ui.dp(this, 3);
        card.addView(recipientModeGroup, modeParams);
        groupNameSection = new LinearLayout(this);
        groupNameSection.setOrientation(LinearLayout.VERTICAL);
        groupNameInput = createInput("যেমন: Family / Office Team", false);
        addField(groupNameSection, "👥 Group name (Broadcast label)", groupNameInput);
        card.addView(groupNameSection);
        updateRecipientModeUi();
        Ui.addText(this, card,
                "Group-এর সবাই একই নির্ধারিত সময়ে due হবে। WhatsApp-এর আলাদা chat একসঙ্গে খোলা যায় না: UI automation একে একে Send চেষ্টা করবে, কিন্তু ১ মিনিটের বাধ্যতামূলক বিরতি থাকবে না। এটি WhatsApp Group Chat নয়।",
                11, Ui.MUTED, false, 3);

        LinearLayout contactRow = new LinearLayout(this);
        contactRow.setOrientation(LinearLayout.HORIZONTAL);
        Button pickContact = Ui.button(this, "👤 From Contacts", this::pickContact);
        contactRow.addView(pickContact, new LinearLayout.LayoutParams(0, -2, 1f));
        Button pickGroupContacts = Ui.button(this, "👥 Select many Contacts", this::pickMultipleContacts);
        LinearLayout.LayoutParams manyParams = new LinearLayout.LayoutParams(0, -2, 1f);
        manyParams.leftMargin = Ui.dp(this, 6);
        contactRow.addView(pickGroupContacts, manyParams);
        LinearLayout.LayoutParams contactParams = new LinearLayout.LayoutParams(-1, -2);
        contactParams.topMargin = Ui.dp(this, 8);
        card.addView(contactRow, contactParams);

        Ui.addText(this, card, "👥 Recent recipients · + যোগ করুন / − তালিকা থেকে সরান",
                13, Ui.MUTED, true, 13);
        recipientsContainer = new LinearLayout(this);
        recipientsContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams historyParams = new LinearLayout.LayoutParams(-1, -2);
        historyParams.topMargin = Ui.dp(this, 5);
        card.addView(recipientsContainer, historyParams);

        messageInput = createInput("আপনার WhatsApp মেসেজ লিখুন…", true);
        messageInput.setMinLines(4);
        messageInput.setMaxLines(8);
        addField(card, "মেসেজ", messageInput);

        addActionButton(card, "📝 Notepad থেকে মেসেজ নিন", this::openSchedulerNotepad);

        addActionButton(card, "🎙️ Voice typing (বাংলা / English)", this::startVoiceTyping);
        Ui.addText(this, card, "⚡ Short message templates", 13, Ui.MUTED, true, 14);
        HorizontalScrollView templateScroll = new HorizontalScrollView(this);
        templateScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout templateRow = new LinearLayout(this);
        templateRow.setOrientation(LinearLayout.HORIZONTAL);
        quickTemplateRow = templateRow;
        refreshQuickTemplateRow();
        templateScroll.addView(templateRow);
        LinearLayout.LayoutParams templatesParams = new LinearLayout.LayoutParams(-1, -2);
        templatesParams.topMargin = Ui.dp(this, 6);
        card.addView(templateScroll, templatesParams);

        Ui.addText(this, card, "কখন পাঠানোর রিমাইন্ডার চান?", 13, Ui.MUTED, true, 14);
        LinearLayout dateTimeRow = new LinearLayout(this);
        dateTimeRow.setOrientation(LinearLayout.HORIZONTAL);
        dateButton = Ui.text(this, "", 14, Ui.TEXT, true);
        dateButton.setGravity(Gravity.CENTER);
        dateButton.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12));
        dateButton.setBackground(inputBackground());
        dateButton.setOnClickListener(v -> chooseDate());
        timeButton = Ui.text(this, "", 14, Ui.TEXT, true);
        timeButton.setGravity(Gravity.CENTER);
        timeButton.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12));
        timeButton.setBackground(inputBackground());
        timeButton.setOnClickListener(v -> chooseTime());
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, -2, 1f);
        half.rightMargin = Ui.dp(this, 6);
        dateTimeRow.addView(dateButton, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, -2, 1f);
        half2.leftMargin = Ui.dp(this, 6);
        dateTimeRow.addView(timeButton, half2);
        LinearLayout.LayoutParams dtp = new LinearLayout.LayoutParams(-1, -2);
        dtp.topMargin = Ui.dp(this, 8);
        card.addView(dateTimeRow, dtp);
        updateDateTimeButtons();

        Ui.addText(this, card, "Repeat", 13, Ui.MUTED, true, 14);
        repeatSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, REPEAT_LABELS) {
            @Override public View getView(int position, View convertView,
                                          android.view.ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Ui.TEXT);
                view.setTextSize(14);
                return view;
            }
            @Override public View getDropDownView(int position, View convertView,
                                                  android.view.ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(Ui.TEXT);
                view.setBackgroundColor(Ui.CARD);
                view.setPadding(Ui.dp(MessageSchedulerActivity.this, 12),
                        Ui.dp(MessageSchedulerActivity.this, 12),
                        Ui.dp(MessageSchedulerActivity.this, 12),
                        Ui.dp(MessageSchedulerActivity.this, 12));
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        repeatSpinner.setAdapter(adapter);
        LinearLayout.LayoutParams spinnerParams = new LinearLayout.LayoutParams(-1, -2);
        spinnerParams.topMargin = Ui.dp(this, 4);
        card.addView(repeatSpinner, spinnerParams);

        Ui.addText(this, card, "Quick time", 13, Ui.MUTED, true, 14);
        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        addQuickButton(quickRow, "১০ মিনিট", 10 * 60 * 1000L);
        addQuickButton(quickRow, "১ ঘণ্টা", 60 * 60 * 1000L);
        addQuickButton(quickRow, "আগামীকাল", 24 * 60 * 60 * 1000L);
        LinearLayout.LayoutParams quickParams = new LinearLayout.LayoutParams(-1, -2);
        quickParams.topMargin = Ui.dp(this, 5);
        card.addView(quickRow, quickParams);
        addActionButton(card, "🧪 Test in 10 seconds (one recipient)", this::testAfterTenSeconds);
        Ui.addText(this, card,
                "১০ সেকেন্ডের টেস্টে একটি নম্বর ব্যবহার করুন। Exact Alarm অনুমতি না থাকলে "
                + "Android Reminder দেরিতে দিতে পারে। Experimental Auto-Send চালু থাকলে "
                + "এটি প্রকৃত WhatsApp মেসেজ পাঠানোর চেষ্টা করতে পারে।",
                12, Ui.MUTED, false, 4);

        Button save = Ui.button(this, "⏰ Schedule message", this::saveSchedule);
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(-1, -2);
        saveParams.topMargin = Ui.dp(this, 16);
        card.addView(save, saveParams);

        Button cancelEdit = Ui.button(this, "Cancel edit / Clear form", this::resetForm);
        LinearLayout.LayoutParams clearParams = new LinearLayout.LayoutParams(-1, -2);
        clearParams.topMargin = Ui.dp(this, 8);
        card.addView(cancelEdit, clearParams);

        Ui.addCard(this, body, card, 14);
    }

    private void renderRecipientHistory() {
        if (recipientsContainer == null) return;
        recipientsContainer.removeAllViews();
        List<SchedulerRecipientHistory.Entry> entries = SchedulerRecipientHistory.getAll(this);
        if (entries.isEmpty()) {
            Ui.addText(this, recipientsContainer,
                    "আগের কোনো প্রাপক নেই। শিডিউল সেভ করলে নম্বর এখানে থাকবে।",
                    12, Ui.MUTED, false, 3);
            return;
        }
        int shown = recipientsExpanded ? entries.size() : Math.min(4, entries.size());
        for (int i = 0; i < shown; i++) {
            SchedulerRecipientHistory.Entry entry = entries.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = Ui.text(this, (entry.name.isEmpty() ? "" : entry.name + " · ")
                    + "+" + entry.phone, 12, Ui.TEXT, false);
            row.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
            Button add = smallHistoryButton("+", () -> addNumberToComposer(entry));
            row.addView(add, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 42)));
            Button remove = smallHistoryButton("−", () -> {
                SchedulerRecipientHistory.remove(this, entry.phone);
                renderRecipientHistory();
            });
            LinearLayout.LayoutParams minusParams = new LinearLayout.LayoutParams(
                    Ui.dp(this, 46), Ui.dp(this, 42));
            minusParams.leftMargin = Ui.dp(this, 6);
            row.addView(remove, minusParams);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
            rowParams.topMargin = Ui.dp(this, 5);
            recipientsContainer.addView(row, rowParams);
        }
        if (entries.size() > 4) {
            Button more = Ui.button(this, recipientsExpanded ? "কম দেখুন" : "সব নম্বর দেখুন (" + entries.size() + ")",
                    () -> {
                        recipientsExpanded = !recipientsExpanded;
                        renderRecipientHistory();
                    });
            LinearLayout.LayoutParams moreParams = new LinearLayout.LayoutParams(-1, -2);
            moreParams.topMargin = Ui.dp(this, 6);
            recipientsContainer.addView(more, moreParams);
        }
    }

    private Button smallHistoryButton(String text, Runnable action) {
        Button button = Ui.button(this, text, action);
        button.setTextSize(20);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(0, 0, 0, 0);
        button.setContentDescription("+".equals(text) ? "Add recipient to message" : "Remove recipient from history");
        return button;
    }

    private void addNumberToComposer(SchedulerRecipientHistory.Entry entry) {
        if (phoneInput == null) return;
        List<String> existing = RecipientSelectionLogic.appendUnique(
                phoneInput.getText().toString(), entry.phone);
        phoneInput.setText(RecipientSelectionLogic.asCommaSeparatedNumbers(existing));
        phoneInput.setSelection(phoneInput.length());
        if (nameInput != null && nameInput.getText().toString().trim().isEmpty()
                && existing.size() == 1 && !entry.name.isEmpty()) {
            nameInput.setText(entry.name);
        }
        Toast.makeText(this, "প্রাপক যুক্ত হয়েছে।", Toast.LENGTH_SHORT).show();
    }

    private void refreshQuickTemplateRow() {
        if (quickTemplateRow == null) return;
        quickTemplateRow.removeAllViews();
        List<SchedulerTemplateStore.Entry> quickTemplates = SchedulerTemplateStore.getAll(this);
        for (int index = 0; index < Math.min(3, quickTemplates.size()); index++) {
            SchedulerTemplateStore.Entry choice = quickTemplates.get(index);
            Button shortcut = Ui.button(this, choice.title, () -> applyTemplate(choice));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
            params.rightMargin = Ui.dp(this, 5);
            quickTemplateRow.addView(shortcut, params);
        }
        Button allTemplates = Ui.button(this, "আরও…", this::showTemplatePicker);
        quickTemplateRow.addView(allTemplates);
        Button manageTemplates = Ui.button(this, "✏️ Edit / Add", this::showTemplateManager);
        quickTemplateRow.addView(manageTemplates);
    }

    private void showTemplatePicker() {
        if (messageInput == null) return;
        List<SchedulerTemplateStore.Entry> entries = SchedulerTemplateStore.getAll(this);
        if (entries.isEmpty()) {
            showTemplateManager();
            return;
        }
        String[] titles = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) titles[i] = entries.get(i).title;
        new AlertDialog.Builder(this)
                .setTitle("⚡ Quick WhatsApp message templates")
                .setItems(titles, (dialog, position) -> applyTemplate(entries.get(position)))
                .setPositiveButton("✏️ Manage", (dialog, which) -> showTemplateManager())
                .setNegativeButton("Close", null)
                .show();
    }

    private void applyTemplate(SchedulerTemplateStore.Entry entry) {
        if (messageInput == null || entry == null) return;
        String template = entry.message;
        if (template.trim().isEmpty()) return;
        if (messageInput.getText().toString().trim().isEmpty()) {
            messageInput.setText(template);
            messageInput.setSelection(messageInput.length());
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Replace or append message?")
                    .setPositiveButton("Replace", (d, which) -> {
                        messageInput.setText(template);
                        messageInput.setSelection(messageInput.length());
                    })
                    .setNeutralButton("Append", (d, which) -> {
                        messageInput.append("\n" + template);
                        messageInput.setSelection(messageInput.length());
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    private void showTemplateManager() {
        List<SchedulerTemplateStore.Entry> entries = SchedulerTemplateStore.getAll(this);
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        scroll.addView(list);
        AlertDialog managerDialog = new AlertDialog.Builder(this)
                .setTitle("✏️ Manage Quick Templates")
                .create();
        if (entries.isEmpty()) {
            Ui.addText(this, list, "এখনো কোনো Template নেই। Add New চাপুন।", 13, Ui.MUTED, false, 5);
        }
        for (SchedulerTemplateStore.Entry entry : entries) {
            LinearLayout row = Ui.card(this);
            Ui.addText(this, row, entry.title, 15, Ui.TEXT, true, 0);
            Ui.addText(this, row, SchedulerDisplayLogic.messagePreview(entry.message, 100),
                    12, Ui.MUTED, false, 4);
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit = Ui.button(this, "✏️ Edit", () -> {
                managerDialog.dismiss();
                showTemplateEditor(entry);
            });
            Button delete = Ui.button(this, "🗑 Delete", () -> {
                managerDialog.dismiss();
                new AlertDialog.Builder(this)
                        .setTitle("Delete template?")
                        .setMessage(entry.title)
                        .setPositiveButton("Delete", (d, w) -> {
                            SchedulerTemplateStore.delete(this, entry.id);
                            refreshQuickTemplateRow();
                            showTemplateManager();
                        })
                        .setNegativeButton("Cancel", (d, w) -> showTemplateManager())
                        .show();
            });
            actions.addView(edit, new LinearLayout.LayoutParams(0, -2, 1f));
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, -2, 1f);
            dp.leftMargin = Ui.dp(this, 6);
            actions.addView(delete, dp);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
            ap.topMargin = Ui.dp(this, 8);
            row.addView(actions, ap);
            Ui.addCard(this, list, row, 8);
        }
        managerDialog.setView(scroll);
        managerDialog.setButton(AlertDialog.BUTTON_POSITIVE, "＋ Add New",
                (dialog, which) -> showTemplateEditor(null));
        managerDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Done", (dialog, which) -> dialog.dismiss());
        managerDialog.show();
    }

    private void showTemplateEditor(SchedulerTemplateStore.Entry existing) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4));
        EditText title = createInput("Template title", false);
        EditText message = createInput("Template message", true);
        message.setMinLines(4);
        message.setMaxLines(8);
        if (existing != null) {
            title.setText(existing.title);
            message.setText(existing.message);
        }
        addField(form, "নাম (সর্বোচ্চ ৪৮ অক্ষর)", title);
        addField(form, "মেসেজ (সর্বোচ্চ ২০০০ অক্ষর)", message);
        new AlertDialog.Builder(this)
                .setTitle(existing == null ? "＋ Add Quick Template" : "✏️ Edit Quick Template")
                .setView(form)
                .setPositiveButton("Save", (d, w) -> {
                    String t = title.getText().toString();
                    String m = message.getText().toString();
                    boolean saved = existing == null
                            ? SchedulerTemplateStore.add(this, t, m)
                            : SchedulerTemplateStore.update(this, existing.id, t, m);
                    Toast.makeText(this, saved ? "Template saved." :
                            "নাম ও মেসেজ লিখুন; সর্বোচ্চ ৫০টি Template রাখা যাবে।", Toast.LENGTH_LONG).show();
                    if (saved) {
                        refreshQuickTemplateRow();
                        showTemplateManager();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateRecipientModeUi() {
        if (phoneInput == null || recipientModeGroup == null) return;
        boolean group = recipientModeGroup.getCheckedRadioButtonId() == MODE_GROUP;
        phoneInput.setHint(group
                ? "একাধিক WhatsApp নম্বর: কমা / সেমিকোলন / নতুন লাইন দিয়ে আলাদা করুন"
                : "একটি WhatsApp নম্বর লিখুন");
        if (groupNameSection != null) groupNameSection.setVisibility(group ? View.VISIBLE : View.GONE);
        if (singleNameSection != null) singleNameSection.setVisibility(group ? View.GONE : View.VISIBLE);
    }

    private boolean isGroupMode() {
        return recipientModeGroup != null && recipientModeGroup.getCheckedRadioButtonId() == MODE_GROUP;
    }

    private static final class ContactChoice {
        final String name;
        final String phone;
        ContactChoice(String name, String phone) { this.name = name; this.phone = phone; }
    }

    private void pickMultipleContacts() {
        if (!isGroupMode()) recipientModeGroup.check(MODE_GROUP);
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQUEST_GROUP_CONTACTS);
            return;
        }
        List<ContactChoice> choices = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
            if (cursor != null) {
                java.util.HashSet<String> seen = new java.util.HashSet<>();
                while (cursor.moveToNext() && choices.size() < 250) {
                    String name = cursor.getString(0);
                    String raw = cursor.getString(1);
                    String normalized = MessageScheduleLogic.normalizePhone("880", raw);
                    if (MessageScheduleLogic.isValidPhone(normalized) && seen.add(normalized)) {
                        choices.add(new ContactChoice(name == null ? "" : name, normalized));
                    }
                }
            }
        } catch (Exception error) {
            Toast.makeText(this, "Contacts পড়া যায়নি। Permission পরীক্ষা করুন।", Toast.LENGTH_LONG).show();
            return;
        } finally { if (cursor != null) cursor.close(); }
        if (choices.isEmpty()) {
            Toast.makeText(this, "কোনো বৈধ ফোন নম্বর পাওয়া যায়নি।", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[choices.size()];
        boolean[] checked = new boolean[choices.size()];
        java.util.HashSet<String> existingPhones = new java.util.HashSet<>(
                MessageScheduleLogic.normalizePhones("880", phoneInput.getText().toString()));
        for (int i = 0; i < choices.size(); i++) {
            ContactChoice choice = choices.get(i);
            labels[i] = (choice.name.isEmpty() ? "Contact" : choice.name) + " · +" + choice.phone;
            checked[i] = existingPhones.contains(choice.phone);
        }
        new AlertDialog.Builder(this)
                .setTitle("Select group recipients (max 20)")
                .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("Add selected", (dialog, which) -> {
                    List<String> current = MessageScheduleLogic.normalizePhones("880", phoneInput.getText().toString());
                    for (int i = 0; i < choices.size(); i++) {
                        if (checked[i] && current.size() < GroupScheduleLogic.MAX_RECIPIENTS) {
                            selectedContactNames.put(choices.get(i).phone, choices.get(i).name);
                            current = RecipientSelectionLogic.appendUnique(
                                    RecipientSelectionLogic.asCommaSeparatedNumbers(current), choices.get(i).phone);
                        }
                    }
                    phoneInput.setText(RecipientSelectionLogic.asCommaSeparatedNumbers(current));
                    phoneInput.setSelection(phoneInput.length());
                    Toast.makeText(this, current.size() + " জন প্রাপক নির্বাচন করা হয়েছে।", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void testAfterTenSeconds() {
        if (settingsOnly || phoneInput == null) return;
        List<String> phones = MessageScheduleLogic.normalizePhones("880",
                phoneInput.getText().toString());
        if (phones.size() != 1) {
            Toast.makeText(this, "টেস্টের জন্য একটি সঠিক নম্বর নির্বাচন করুন।",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (!MessageScheduleLogic.isValidMessage(messageInput.getText().toString().trim())) {
            Toast.makeText(this, "টেস্টের জন্য একটি মেসেজ লিখুন বা টেমপ্লেট নিন।",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (AutoSendPreferences.enabled(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("10-second live WhatsApp test")
                    .setMessage("Experimental Auto-Send চালু আছে। এই টেস্ট ১০ সেকেন্ড পরে "
                            + "আসল WhatsApp মেসেজ পাঠানোর চেষ্টা করতে পারে। "
                            + "শুধু নিজের অনুমতি পাওয়া নম্বরে পরীক্ষা করুন।")
                    .setPositiveButton("Schedule test", (d, w) -> {
                        saveScheduleInternal(SchedulerDisplayLogic.tenSecondTrigger(System.currentTimeMillis()), true);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        } else {
            saveScheduleInternal(SchedulerDisplayLogic.tenSecondTrigger(System.currentTimeMillis()), true);
        }
    }

    private static final int REQUEST_SR_NOTE_PICK = 5221;

    private void openSchedulerNotepad() {
        android.content.Intent intent = new android.content.Intent(this, SchedulerNotepadActivity.class);
        intent.putExtra(SchedulerNotepadActivity.EXTRA_PICK_MODE, true);
        startActivityForResult(intent, REQUEST_SR_NOTE_PICK);
    }

    private void useNotepadMessage(String selectedNote) {
        if (messageInput == null || selectedNote == null || selectedNote.trim().isEmpty()) return;
        String existing = messageInput.getText().toString();
        if (existing.trim().isEmpty()) {
            messageInput.setText(selectedNote);
            messageInput.setSelection(messageInput.length());
            return;
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("নোটপ্যাড থেকে মেসেজ নিন")
                .setMessage("আগের মেসেজ Replace করবেন, নাকি নোটটি Append করবেন?")
                .setPositiveButton("Replace", (dialog, which) -> {
                    messageInput.setText(selectedNote);
                    messageInput.setSelection(messageInput.length());
                })
                .setNeutralButton("Append", (dialog, which) -> {
                    messageInput.append("\n" + selectedNote);
                    messageInput.setSelection(messageInput.length());
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void buildScheduleList(LinearLayout body) {
        Ui.addText(this, body, "🗂️ Schedule Inbox", 19, Ui.TEXT, true, 22);
        Ui.addText(this, body,
                "আজ, আগামীকাল, পরবর্তী দিন এবং আগের মেসেজ আলাদা ফোল্ডারে। "
                + "যেকোনো ফোল্ডারে চাপ দিয়ে খুলুন বা বন্ধ করুন।",
                12, Ui.MUTED, false, 6);
        schedulesContainer = new LinearLayout(this);
        schedulesContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(-1, -2);
        listParams.topMargin = Ui.dp(this, 8);
        body.addView(schedulesContainer, listParams);
    }

    private EditText createInput(String hint, boolean multiline) {
        EditText input = new EditText(this);
        input.setSingleLine(!multiline);
        input.setTextSize(14);
        input.setTextColor(Ui.TEXT);
        input.setHintTextColor(Ui.MUTED);
        input.setHint(hint);
        input.setPadding(Ui.dp(this, 12), Ui.dp(this, 10),
                Ui.dp(this, 12), Ui.dp(this, 10));
        input.setBackground(inputBackground());
        if (multiline) {
            input.setGravity(Gravity.TOP | Gravity.START);
            input.setInputType(InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        }
        return input;
    }

    private GradientDrawable inputBackground() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.CARD_2);
        bg.setCornerRadius(Ui.dp(this, 12));
        bg.setStroke(Ui.dp(this, 1), Ui.MUTED);
        return bg;
    }

    private void addField(LinearLayout parent, String label, EditText field) {
        Ui.addText(this, parent, label, 13, Ui.MUTED, true, 12);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = Ui.dp(this, 5);
        parent.addView(field, params);
    }

    private void addActionButton(LinearLayout parent, String label, Runnable action) {
        Button button = Ui.button(this, label, action);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = Ui.dp(this, 8);
        parent.addView(button, params);
    }

    private void addQuickButton(LinearLayout parent, String label, long delayMillis) {
        Button button = Ui.button(this, label, () -> {
            selectedTime.setTimeInMillis(System.currentTimeMillis() + delayMillis);
            selectedTime.set(Calendar.SECOND, 0);
            selectedTime.set(Calendar.MILLISECOND, 0);
            updateDateTimeButtons();
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1f);
        params.rightMargin = Ui.dp(this, 4);
        params.leftMargin = Ui.dp(this, 4);
        parent.addView(button, params);
    }

    private void chooseDate() {
        DatePickerDialog dialog = new DatePickerDialog(this, (view, year, month, day) -> {
            selectedTime.set(Calendar.YEAR, year);
            selectedTime.set(Calendar.MONTH, month);
            selectedTime.set(Calendar.DAY_OF_MONTH, day);
            updateDateTimeButtons();
        }, selectedTime.get(Calendar.YEAR), selectedTime.get(Calendar.MONTH),
                selectedTime.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    private void chooseTime() {
        TimePickerDialog dialog = new TimePickerDialog(this, (view, hour, minute) -> {
            selectedTime.set(Calendar.HOUR_OF_DAY, hour);
            selectedTime.set(Calendar.MINUTE, minute);
            selectedTime.set(Calendar.SECOND, 0);
            selectedTime.set(Calendar.MILLISECOND, 0);
            updateDateTimeButtons();
        }, selectedTime.get(Calendar.HOUR_OF_DAY), selectedTime.get(Calendar.MINUTE), false);
        dialog.show();
    }

    private void updateDateTimeButtons() {
        if (dateButton == null || timeButton == null) return;
        dateButton.setText("📅 " + new SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                .format(new Date(selectedTime.getTimeInMillis())));
        timeButton.setText("🕒 " + new SimpleDateFormat("hh:mm a", Locale.getDefault())
                .format(new Date(selectedTime.getTimeInMillis())));
    }

    private void pickContact() {
        try {
            Intent pick = new Intent(Intent.ACTION_PICK,
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(pick, REQUEST_CONTACT);
        } catch (Exception error) {
            Toast.makeText(this, "Contacts app is not available.", Toast.LENGTH_SHORT).show();
        }
    }

    private void startVoiceTyping() {
        try {
            Intent speech = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
            speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
            speech.putExtra(RecognizerIntent.EXTRA_PROMPT, "আপনার WhatsApp মেসেজ বলুন");
            startActivityForResult(speech, REQUEST_VOICE);
        } catch (Exception error) {
            Toast.makeText(this, "Voice typing is not available on this device.",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SR_NOTE_PICK) {
            if (resultCode == RESULT_OK && data != null) {
                useNotepadMessage(data.getStringExtra(SchedulerNotepadActivity.EXTRA_NOTE_BODY));
            }
            return;
        }

        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_VOICE) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                messageInput.setText(results.get(0));
                messageInput.setSelection(messageInput.getText().length());
            }
        } else if (requestCode == REQUEST_CONTACT && data.getData() != null) {
            fillContact(data.getData());
        }
    }

    private void fillContact(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri,
                    new String[] {
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER
                    }, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0);
                String phone = cursor.getString(1);
                if (nameInput.getText().toString().trim().isEmpty()) nameInput.setText(name);
                String normalizedContact = MessageScheduleLogic.normalizePhone("880", phone);
                if (MessageScheduleLogic.isValidPhone(normalizedContact)) {
                    selectedContactNames.put(normalizedContact, name == null ? "" : name);
                }
                if (isGroupMode()) {
                    List<String> existing = RecipientSelectionLogic.appendUnique(
                            phoneInput.getText().toString(), phone);
                    phoneInput.setText(RecipientSelectionLogic.asCommaSeparatedNumbers(existing));
                } else {
                    phoneInput.setText(phone);
                }
            }
        } catch (Exception error) {
            Toast.makeText(this, "Could not read the selected contact.", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void saveSchedule() {
        saveScheduleInternal(selectedTime.getTimeInMillis(), false);
    }

    private void saveScheduleInternal(long when, boolean testMode) {
        String name = nameInput.getText().toString().trim();
        String rawPhones = phoneInput.getText().toString().trim();
        String message = messageInput.getText().toString().trim();
        String repeat = testMode ? "once" : REPEAT_VALUES[Math.max(0,
                Math.min(repeatSpinner.getSelectedItemPosition(), REPEAT_VALUES.length - 1))];

        List<String> phones = MessageScheduleLogic.normalizePhones("880", rawPhones);
        if (phones.isEmpty()) {
            Toast.makeText(this, "একটি সঠিক WhatsApp নম্বর লিখুন বা Contacts থেকে নিন।",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (!MessageScheduleLogic.isValidMessage(message)) {
            Toast.makeText(this, "মেসেজ লিখুন।", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!MessageScheduleLogic.isValidFutureTime(when, System.currentTimeMillis())) {
            Toast.makeText(this, "ভবিষ্যতের তারিখ ও সময় নির্বাচন করুন।", Toast.LENGTH_SHORT).show();
            return;
        }

        if (testMode && phones.size() != 1) {
            Toast.makeText(this, "টেস্টের জন্য একটি নম্বর রাখুন।", Toast.LENGTH_LONG).show();
            return;
        }
        if (!testMode && isGroupMode()) {
            String groupName = GroupScheduleLogic.cleanGroupName(groupNameInput.getText().toString());
            if (!GroupScheduleLogic.validCount(phones.size())) {
                Toast.makeText(this, "Group mode-এ ২ থেকে ২০টি আলাদা নম্বর নির্বাচন করুন।", Toast.LENGTH_LONG).show();
                return;
            }
            if (editingId != null) {
                Toast.makeText(this, "Group batch আলাদা করে এডিট করতে হলে আগে এই edit বাতিল করুন।", Toast.LENGTH_LONG).show();
                return;
            }
            if (!GroupScheduleLogic.allTimesFuture(when, phones.size(), System.currentTimeMillis())) {
                Toast.makeText(this, "নির্ধারিত সময়টি ভবিষ্যতে নির্বাচন করুন।", Toast.LENGTH_LONG).show();
                return;
            }
            String details = "Group: " + GroupScheduleLogic.displayName(groupName)
                    + "\nসবার শিডিউল একই সময়ে due হবে। WhatsApp-এর আলাদা chat-এ Send চেষ্টা "
                    + "ক্রমে হবে, তবে ইচ্ছাকৃত ৬০ সেকেন্ডের বিরতি থাকবে না। "
                    + "সবাইকে একই সেকেন্ডে ডেলিভারি নিশ্চিত করা যায় না। "
                    + "শুধু অনুমতিপ্রাপ্ত প্রাপকদের ব্যবহার করুন।";
            new AlertDialog.Builder(this).setTitle("Create group / broadcast schedule?")
                    .setMessage(details)
                    .setPositiveButton("Create batch", (dialog, which) ->
                            persistGroupSchedules(groupName, phones, message, when, repeat))
                    .setNegativeButton("Cancel", null).show();
            return;
        }
        if (!testMode && phones.size() != 1) {
            Toast.makeText(this, "একটি নম্বরের জন্য Single mode অথবা একাধিকের জন্য Group mode নির্বাচন করুন।",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (editingId != null && !testMode) {
            if (phones.size() != 1) {
                Toast.makeText(this, "এডিট করার সময় একটি নম্বর রাখুন।", Toast.LENGTH_SHORT).show();
                return;
            }
            MessageScheduleStore.Item item = MessageScheduleStore.get(this, editingId);
            if (item == null) {
                resetForm();
                Toast.makeText(this, "এই শিডিউলটি আর পাওয়া যাচ্ছে না।", Toast.LENGTH_SHORT).show();
                return;
            }
            MessageScheduleStore.cancel(this, item);
            item.contactName = name;
            item.phone = phones.get(0);
            item.message = message;
            item.scheduledAtMillis = when;
            item.repeatMode = repeat;
            item.status = MessageScheduleStore.STATUS_PENDING;
            item.lastTriggeredAtMillis = 0L;
            boolean scheduled = MessageScheduleStore.schedule(this, item);
            if (!scheduled) item.status = MessageScheduleStore.STATUS_PAUSED;
            MessageScheduleStore.save(this, item);
            SchedulerRecipientHistory.record(this, item.phone, item.contactName);
            Toast.makeText(this, scheduled ? "শিডিউল আপডেট হয়েছে।" :
                    "শিডিউল সেভ হয়েছে, কিন্তু Alarm সেট হয়নি। Permission পরীক্ষা করুন।",
                    Toast.LENGTH_LONG).show();
        } else {
            int saved = 0;
            int failed = 0;
            for (String phone : phones) {
                MessageScheduleStore.Item item = MessageScheduleStore.Item.create(
                        name, phone, message, when, repeat);
                boolean scheduled = MessageScheduleStore.schedule(this, item);
                if (!scheduled) {
                    item.status = MessageScheduleStore.STATUS_PAUSED;
                    failed++;
                } else {
                    saved++;
                }
                MessageScheduleStore.save(this, item);
                SchedulerRecipientHistory.record(this, item.phone, item.contactName);
            }
            Toast.makeText(this,
                    saved + (testMode ? "টি ১০ সেকেন্ডের টেস্ট শিডিউল তৈরি হয়েছে" : "টি শিডিউল তৈরি হয়েছে") + (failed > 0
                            ? " · " + failed + "টির Alarm সেট হয়নি" : ""),
                    Toast.LENGTH_LONG).show();
        }
        resetForm();
        renderSchedules();
        renderRecipientHistory();
        updatePermissionStatus();
    }

    private void persistGroupSchedules(String groupName, List<String> phones, String message,
                                       long when, String repeat) {
        if (!GroupScheduleLogic.allTimesFuture(when, phones.size(), System.currentTimeMillis())) {
            Toast.makeText(this, "নিশ্চিত করার সময় পেরিয়ে গেছে। Group schedule-এর সময় আবার নির্বাচন করুন।",
                    Toast.LENGTH_LONG).show();
            return;
        }
        String batchId = UUID.randomUUID().toString();
        int saved = 0;
        int failed = 0;
        for (int i = 0; i < phones.size(); i++) {
            long recipientTime = GroupScheduleLogic.scheduledAt(when, i);
            String recipientLabel = selectedContactNames.containsKey(phones.get(i))
                    ? selectedContactNames.get(phones.get(i)) : phones.get(i);
            MessageScheduleStore.Item item = MessageScheduleStore.Item.createBatch(
                    recipientLabel, phones.get(i), message, recipientTime, repeat,
                    batchId, i + 1, phones.size());
            item.groupName = GroupScheduleLogic.cleanGroupName(groupName);
            boolean scheduled = MessageScheduleStore.schedule(this, item);
            if (!scheduled) { item.status = MessageScheduleStore.STATUS_PAUSED; failed++; }
            else saved++;
            MessageScheduleStore.save(this, item);
            SchedulerRecipientHistory.record(this, item.phone, item.contactName);
        }
        Toast.makeText(this, saved + " জনের Group batch তৈরি হয়েছে" + (failed > 0
                ? " · " + failed + "টির Alarm সেট হয়নি" : "")
                + " · একই due time (Send attempts sequential)", Toast.LENGTH_LONG).show();
        resetForm();
        renderSchedules();
        renderRecipientHistory();
        updatePermissionStatus();
    }

    private void resetForm() {
        editingId = null;
        if (recipientModeGroup != null) recipientModeGroup.check(MODE_SINGLE);
        if (nameInput != null) nameInput.setText("");
        if (groupNameInput != null) groupNameInput.setText("");
        selectedContactNames.clear();
        if (phoneInput != null) phoneInput.setText("");
        if (messageInput != null) messageInput.setText("");
        if (repeatSpinner != null) repeatSpinner.setSelection(0);
        selectedTime.setTimeInMillis(System.currentTimeMillis() + 10 * 60 * 1000L);
        selectedTime.set(Calendar.SECOND, 0);
        selectedTime.set(Calendar.MILLISECOND, 0);
        updateDateTimeButtons();
    }

    private void renderSchedules() {
        if (schedulesContainer == null) return;
        schedulesContainer.removeAllViews();
        countdownViews.clear();
        List<MessageScheduleStore.Item> items = MessageScheduleStore.getAll(this);
        long now = System.currentTimeMillis();
        ZoneId zone = ZoneId.systemDefault();
        lastSectionSignature = sectionSignature(items, now, zone);
        Map<String, List<MessageScheduleStore.Item>> sections = new LinkedHashMap<>();
        for (String key : SchedulerSectionLogic.ORDER) sections.put(key, new ArrayList<>());
        for (MessageScheduleStore.Item item : items) {
            String key = SchedulerSectionLogic.sectionFor(item.status, item.scheduledAtMillis, now, zone);
            sections.get(key).add(item);
        }

        if (items.isEmpty()) {
            Ui.addText(this, schedulesContainer,
                    "এখনো কোনো শিডিউল নেই। উপরের ফর্ম থেকে নতুন মেসেজ তৈরি করুন।",
                    13, Ui.MUTED, false, 8);
            return;
        }

        for (String key : SchedulerSectionLogic.ORDER) {
            List<MessageScheduleStore.Item> sectionItems = sections.get(key);
            sectionItems.sort((a, b) -> SchedulerSectionLogic.mostRecentFirst(key)
                    ? Long.compare(b.scheduledAtMillis, a.scheduledAtMillis)
                    : Long.compare(a.scheduledAtMillis, b.scheduledAtMillis));
            addScheduleSection(key, sectionItems);
        }
    }

    /** Reorganize only if an item moves to a different section. Called by the existing 1s timer. */
    private String sectionSignature(List<MessageScheduleStore.Item> items, long now, ZoneId zone) {
        StringBuilder signature = new StringBuilder();
        for (MessageScheduleStore.Item item : items) {
            signature.append(item.id).append(':')
                    .append(SchedulerSectionLogic.sectionFor(item.status, item.scheduledAtMillis,
                            now, zone)).append(';');
        }
        return signature.toString();
    }

    private boolean isSectionExpanded(String key) {
        return getSharedPreferences(SECTION_PREFS, MODE_PRIVATE).getBoolean(
                "section_" + key, SchedulerSectionLogic.defaultExpanded(key));
    }

    private void addScheduleSection(String key, List<MessageScheduleStore.Item> items) {
        LinearLayout folder = Ui.card(this);
        boolean expanded = isSectionExpanded(key);
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setClickable(true);
        header.setFocusable(true);
        header.setContentDescription(SchedulerSectionLogic.title(key) + ", " + items.size()
                + " messages. Tap to " + (expanded ? "collapse" : "expand"));

        TextView icon = Ui.text(this, SchedulerSectionLogic.icon(key), 25, Ui.ACCENT, true);
        icon.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 38), -2));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(Ui.text(this, SchedulerSectionLogic.title(key), 16, Ui.TEXT, true));
        String sub = items.isEmpty() ? "কোনো মেসেজ নেই" : items.size() + "টি মেসেজ";
        if (!items.isEmpty() && SchedulerSectionLogic.TODAY.equals(key)) {
            sub += " · আজকের নির্ধারিত সময়";
        } else if (!items.isEmpty() && SchedulerSectionLogic.HISTORY.equals(key)) {
            sub += " · শেষ হওয়া, চেষ্টা করা বা সময় পেরোনো";
        }
        Ui.addText(this, labels, sub, 12, Ui.MUTED, false, 3);
        header.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView chevron = Ui.text(this, (expanded ? "▴" : "▾") + "  " + items.size(),
                18, Ui.ACCENT, true);
        chevron.setGravity(Gravity.CENTER);
        header.addView(chevron, new LinearLayout.LayoutParams(Ui.dp(this, 63), -2));
        header.setOnClickListener(v -> {
            getSharedPreferences(SECTION_PREFS, MODE_PRIVATE).edit()
                    .putBoolean("section_" + key, !expanded).apply();
            renderSchedules();
        });
        folder.addView(header, new LinearLayout.LayoutParams(-1, -2));

        if (expanded) {
            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            if (items.isEmpty()) {
                Ui.addText(this, content, "এই ফোল্ডারে এখনো কোনো মেসেজ নেই।",
                        12, Ui.MUTED, false, 12);
            } else {
                for (MessageScheduleStore.Item item : items) addScheduleItem(content, item);
            }
            folder.addView(content, new LinearLayout.LayoutParams(-1, -2));
        }
        Ui.addCard(this, schedulesContainer, folder, 10);
    }

    private void addScheduleItem(LinearLayout parent, MessageScheduleStore.Item item) {
            LinearLayout card = Ui.card(this);
            String label = item.contactName.isEmpty() ? item.phone : item.contactName;
            Ui.addText(this, card, label, 16, Ui.TEXT, true, 0);
            Ui.addText(this, card, "+" + item.phone + "  ·  "
                            + MessageScheduleLogic.repeatLabel(item.repeatMode),
                    12, Ui.MUTED, false, 4);
            if (item.batchId != null && !item.batchId.isEmpty()) {
                Ui.addText(this, card, "👥 " + GroupScheduleLogic.displayName(item.groupName)
                                + " · " + GroupScheduleLogic.recipientPosition(item.batchIndex, item.batchSize)
                                + " · একই scheduled time",
                        11, Ui.ACCENT, true, 5);
            }
            Ui.addText(this, card, MessageScheduleLogic.messagePreview(item.message, 110),
                    13, Ui.TEXT, false, 10);

            String status;
            int statusColor;
            if (MessageScheduleStore.STATUS_DUE.equals(item.status)) {
                status = "● Ready · WhatsApp খুলে Send চাপুন";
                statusColor = Ui.ACCENT;
            } else if (MessageScheduleStore.STATUS_DONE.equals(item.status)) {
                status = "✓ Marked as sent";
                statusColor = Ui.GREEN;
            } else if (MessageScheduleStore.STATUS_ATTEMPTED.equals(item.status)) {
                status = "➤ Auto-send attempted · verify in WhatsApp";
                statusColor = Ui.ACCENT;
            } else if (MessageScheduleStore.STATUS_PAUSED.equals(item.status)) {
                status = "Ⅱ Paused · Alarm permission বা সময় ঠিক করুন";
                statusColor = Ui.MUTED;
            } else {
                status = "⏳ " + new SimpleDateFormat("dd MMM yyyy · hh:mm a",
                        Locale.getDefault()).format(new Date(item.scheduledAtMillis));
                statusColor = Ui.GREEN;
            }
            Ui.addText(this, card, status, 12, statusColor, true, 9);
            if (MessageScheduleStore.STATUS_PENDING.equals(item.status)) {
                Ui.addText(this, card, "📤 মেসেজটি পাঠানোর বাকি সময়", 11, Ui.MUTED, false, 5);
            }
            TextView remaining = Ui.addText(this, card,
                    SchedulerDisplayLogic.remainingLabel(item.scheduledAtMillis,
                            System.currentTimeMillis(), item.status),
                    13, Ui.ACCENT, true, 6);
            countdownViews.add(new CountdownView(item.id, remaining));

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setGravity(Gravity.CENTER_VERTICAL);

            Button open = Ui.button(this,
                    MessageScheduleStore.STATUS_DONE.equals(item.status)
                            ? "Open again" : "Open WhatsApp",
                    () -> openWhatsApp(item));
            actions.addView(open, new LinearLayout.LayoutParams(0, -2, 1f));

            if (MessageScheduleStore.STATUS_DUE.equals(item.status)
                    && "once".equals(item.repeatMode)) {
                Button done = Ui.button(this, "Mark sent", () -> markDone(item));
                LinearLayout.LayoutParams doneParams = new LinearLayout.LayoutParams(0, -2, 1f);
                doneParams.leftMargin = Ui.dp(this, 5);
                actions.addView(done, doneParams);
            } else if ((MessageScheduleStore.STATUS_PENDING.equals(item.status)
                    || MessageScheduleStore.STATUS_PAUSED.equals(item.status))
                    && (item.batchId == null || item.batchId.isEmpty())) {
                Button edit = Ui.button(this, "Edit", () -> loadForEdit(item));
                LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(0, -2, 1f);
                editParams.leftMargin = Ui.dp(this, 5);
                actions.addView(edit, editParams);
            }

            Button delete = Ui.button(this, "Delete", () -> {
                MessageScheduleStore.delete(this, item);
                renderSchedules();
            });
            LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(0, -2, 1f);
            deleteParams.leftMargin = Ui.dp(this, 5);
            actions.addView(delete, deleteParams);

            LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(-1, -2);
            actionParams.topMargin = Ui.dp(this, 12);
            card.addView(actions, actionParams);
            // A sent/attempted record is immutable. Editing it copies its content into
            // a new schedule, preserving what happened in the original history.
            if (MessageScheduleStore.STATUS_DONE.equals(item.status)
                    || MessageScheduleStore.STATUS_ATTEMPTED.equals(item.status)
                    || MessageScheduleStore.STATUS_DUE.equals(item.status)
                    || (item.batchId != null && !item.batchId.isEmpty())) {
                if (item.lastTriggeredAtMillis > 0L) {
                    Ui.addText(this, card, "History: " + new SimpleDateFormat(
                            "dd MMM yyyy · hh:mm a", Locale.getDefault())
                            .format(new Date(item.lastTriggeredAtMillis))
                            + " · status: " + item.status, 11, Ui.MUTED, false, 8);
                }
                Button reuse = Ui.button(this, "✏ Edit message & schedule again",
                        () -> reuseHistoryItem(item));
                LinearLayout.LayoutParams reuseParams = new LinearLayout.LayoutParams(-1, -2);
                reuseParams.topMargin = Ui.dp(this, 8);
                card.addView(reuse, reuseParams);
            }
            Ui.addCard(this, parent, card, 9);
    }

    private void refreshCountdowns() {
        if (settingsOnly || schedulesContainer == null) return;
        List<MessageScheduleStore.Item> latest = MessageScheduleStore.getAll(this);
        long now = System.currentTimeMillis();
        String signature = sectionSignature(latest, now, ZoneId.systemDefault());
        if (!signature.equals(lastSectionSignature)) {
            renderSchedules();
            return;
        }
        Map<String, MessageScheduleStore.Item> current = new HashMap<>();
        for (MessageScheduleStore.Item item : latest) current.put(item.id, item);
        for (CountdownView view : countdownViews) {
            MessageScheduleStore.Item item = current.get(view.id);
            if (item != null) {
                view.label.setText(SchedulerDisplayLogic.remainingLabel(
                        item.scheduledAtMillis, now, item.status));
            } else {
                view.label.setText("শিডিউল সরানো হয়েছে");
            }
        }
    }

    private void openWhatsApp(MessageScheduleStore.Item item) {
        try {
            String url = MessageScheduleLogic.buildWhatsAppUrl(item.phone, item.message);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception error) {
            Toast.makeText(this,
                    "WhatsApp বা কোনো supported browser পাওয়া যায়নি।",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void markDone(MessageScheduleStore.Item item) {
        item.status = MessageScheduleStore.STATUS_DONE;
        MessageScheduleStore.cancel(this, item);
        MessageScheduleStore.save(this, item);
        renderSchedules();
        Toast.makeText(this, "এই মেসেজটি সম্পন্ন হিসেবে চিহ্নিত হয়েছে।",
                Toast.LENGTH_SHORT).show();
    }

    private void loadForEdit(MessageScheduleStore.Item item) {
        if (recipientModeGroup != null) recipientModeGroup.check(MODE_SINGLE);
        editingId = item.id;
        nameInput.setText(item.contactName);
        phoneInput.setText("+" + item.phone);
        messageInput.setText(item.message);
        selectedTime.setTimeInMillis(item.scheduledAtMillis);
        int repeatIndex = 0;
        for (int i = 0; i < REPEAT_VALUES.length; i++) {
            if (REPEAT_VALUES[i].equals(item.repeatMode)) repeatIndex = i;
        }
        repeatSpinner.setSelection(repeatIndex);
        updateDateTimeButtons();
        if (pageScroll != null) pageScroll.smoothScrollTo(0, 0);
        Toast.makeText(this, "শিডিউলটি এডিট করুন এবং Schedule message চাপুন।",
                Toast.LENGTH_SHORT).show();
    }

    /** Copy historical content into a NEW schedule; never falsify a sent/attempted record. */
    private void reuseHistoryItem(MessageScheduleStore.Item source) {
        editingId = null;
        selectedContactNames.clear();
        if (source.batchId != null && !source.batchId.isEmpty()) {
            recipientModeGroup.check(MODE_GROUP);
            groupNameInput.setText(GroupScheduleLogic.displayName(source.groupName));
            List<String> phones = new ArrayList<>();
            for (MessageScheduleStore.Item item : MessageScheduleStore.getAll(this)) {
                if (source.batchId.equals(item.batchId) && !phones.contains(item.phone)) {
                    phones.add(item.phone);
                    selectedContactNames.put(item.phone, item.contactName);
                }
            }
            phoneInput.setText(RecipientSelectionLogic.asCommaSeparatedNumbers(phones));
        } else {
            recipientModeGroup.check(MODE_SINGLE);
            groupNameInput.setText("");
            nameInput.setText(source.contactName);
            phoneInput.setText("+" + source.phone);
        }
        messageInput.setText(source.message);
        int repeatIndex = 0;
        for (int i = 0; i < REPEAT_VALUES.length; i++) {
            if (REPEAT_VALUES[i].equals(source.repeatMode)) repeatIndex = i;
        }
        repeatSpinner.setSelection(repeatIndex);
        long next = System.currentTimeMillis() + 10 * 60 * 1000L;
        selectedTime.setTimeInMillis(Math.max(next, source.scheduledAtMillis));
        updateDateTimeButtons();
        if (pageScroll != null) pageScroll.smoothScrollTo(0, 0);
        Toast.makeText(this,
                "History অপরিবর্তিত থাকবে। তথ্য এডিট করে নতুন Schedule সেভ করুন।",
                Toast.LENGTH_LONG).show();
    }

    private void requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && !MessageScheduleStore.hasExactAlarmAccess(this)) {
            try {
                Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception error) {
                Toast.makeText(this, "Android Settings থেকে Alarms & reminders চালু করুন।",
                        Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Precise scheduling is already available.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS },
                    REQUEST_NOTIFICATIONS);
        } else {
            Toast.makeText(this, "Reminder notifications are already allowed or managed in Android Settings.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void updatePermissionStatus() {
        if (permissionStatus == null) return;
        boolean exact = MessageScheduleStore.hasExactAlarmAccess(this);
        boolean notifications = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifications = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        permissionStatus.setText(
                (exact ? "✓ Precise alarms available" : "⚠ Exact alarm access not granted; Android may delay reminders")
                + "\n"
                + (notifications ? "✓ Notifications allowed" : "⚠ Notifications are blocked; allow them for reminder alerts")
                + "\nAutomation OFF: manual Send. If experimental mode enabled, Accessibility may attempt Send.");
    }

    @Override protected void onResume() {
        super.onResume();
        if (themeWhenCreated != ThemeManager.styleKey(this)) {
            recreate();
            return;
        }
        updatePermissionStatus();
        updateAutomationStatus();
        if (!settingsOnly) {
            renderSchedules();
            renderRecipientHistory();
            countdownHandler.removeCallbacks(countdownUpdater);
            countdownHandler.post(countdownUpdater);
        }
    }

    @Override protected void onPause() {
        countdownHandler.removeCallbacks(countdownUpdater);
        super.onPause();
    }

    @Override protected void onDestroy() {
        countdownHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                                      int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATIONS) updatePermissionStatus();
        if (requestCode == REQUEST_GROUP_CONTACTS && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            pickMultipleContacts();
        }
    }
}
