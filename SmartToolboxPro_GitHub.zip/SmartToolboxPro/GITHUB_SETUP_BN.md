# GitHub মোবাইল দিয়ে Smart Toolbox Pro APK তৈরি

1. Repository-তে `SmartToolboxPro_GitHub.zip` ফাইলটি রাখুন।
2. Repository root-এ `.github/workflows/build-apk.yml` workflow থাকতে হবে। এই workflow ZIP-টি extract করে `SmartToolboxPro` project folder থেকে `:app:assembleDebug` চালাবে।
3. নতুন source version আপলোড করলে পুরোনো ZIP replace করে একই filename `SmartToolboxPro_GitHub.zip` রাখুন।
4. Commit Changes দিন।
5. `Actions` tab-এ গিয়ে নতুন run খুলুন।
6. Build সফল হলে `Artifacts` থেকে `SmartToolboxPro-debug-apk` download করুন।
7. Artifact ZIP extract করে `app-debug.apk` ইনস্টল করুন।

## Android permission
- Floating icon এবং Night Screen-এর জন্য `Display over other apps` permission দিন।
- Android 13+ এ foreground notification permission চাইতে পারে।

## System-wide audio note
Global output-mix `LoudnessEnhancer` session 0 ব্যবহার করা হয়। Android/OEM সব ফোনে এই পদ্ধতি অনুমোদন করে না। Build সফল হলেও আপনার ফোনে চালু করার সময় effect control না পেলে অ্যাপ `Unsupported` দেখাবে। এটি Android-এর master volume slider পরিবর্তন করে না।
