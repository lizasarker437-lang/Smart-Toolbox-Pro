# GitHub মোবাইল দিয়ে Smart Toolbox Pro APK তৈরি

1. Repository-তে পুরোনো `SmartToolboxPro_GitHub.zip` Delete করুন।
2. নতুন ZIP-টি **একই নাম** `SmartToolboxPro_GitHub.zip` দিয়ে আপলোড করুন।
3. Repository root-এ `.github/workflows/build-apk.yml` ফাইলটি আছে কিনা নিশ্চিত করুন। আপনার বর্তমান repo-level workflow ZIP Extract করে Gradle Build চালালে সেটি রেখে দিতে পারবেন।
4. Commit Changes দিন।
5. Actions > সর্বশেষ Build খুলুন।
6. Build সফল হলে Artifacts থেকে APK ডাউনলোড করুন।
7. Build ব্যর্থ হলে `Build debug APK` ধাপে **প্রথম `.java:... error:` লাইনগুলো** দেখুন বা `SmartToolboxPro-build-errors` Artifact ডাউনলোড করুন।

## ফিচার ও Permission
- Floating Icon ও Night Screen Overlay: `Display over other apps`।
- Native Media Volume +/-: Android Media Volume, Boost Gain Slider থেকে আলাদা।
- Native Brightness Slider সরানো হয়েছে; `WRITE_SETTINGS` লাগে না।
- Extra Global Audio Effects: সব Android/OEM-এ সমর্থিত নয়।
