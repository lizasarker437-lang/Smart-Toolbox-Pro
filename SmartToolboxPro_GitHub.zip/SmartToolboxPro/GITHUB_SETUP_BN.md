# মোবাইল থেকে GitHub-এ Smart Toolbox Pro Build — 1.2.9-alpha12

আপনার Repository-তে একই সঙ্গে দুটি ফাইল প্রয়োজন:

1. `SmartToolboxPro_GitHub.zip` — সম্পূর্ণ Android সোর্স প্রজেক্ট। ZIP Extract করার দরকার নেই।
2. `.github/workflows/build-apk.yml` — নতুন Workflow। **ZIP-এর ভেতরের Workflow নিজে থেকে Repository-তে চালু হবে না**; এই ফাইলটি Repository-র `.github/workflows/` ফোল্ডারে আলাদাভাবে দিতে হবে।

## ফোনে কী করবেন
1. এই উত্তরের নতুন `SmartToolboxPro_GitHub.zip` ডাউনলোড করুন।
2. GitHub Repository-এর root-এ পুরোনো একই নামের ZIP বদলে নতুন ZIP আপলোড করুন।
3. Repository-এর `.github/workflows/build-apk.yml` খুলে Edit করুন; এই উত্তরের নতুন `build-apk.yml`-এর কোড দিয়ে পুরোনো Workflow প্রতিস্থাপন করুন।
4. Commit Changes চাপুন।
5. Actions ট্যাবে `Build Smart Toolbox Pro APK` নির্বাচন করুন।
6. Build সফল হলে `SmartToolboxPro-debug-apk` Artifact ডাউনলোড করুন।
7. Build ব্যর্থ হলে `SmartToolboxPro-build-errors` Artifact থেকে লগ দেখুন অথবা `Print Java compiler errors (if build fails)` ধাপের স্ক্রিনশট দিন।

## গুরুত্বপূর্ণ
- Workflow ZIP-only repository, `SmartToolboxPro/` folder অথবা সরাসরি source root—তিনটি বিন্যাসেই প্রজেক্ট শনাক্ত করে Build চালাবে।
- ZIP Extract করে শুধু ZIP ফাইল Commit করলে Android Project-এর workflow স্বয়ংক্রিয়ভাবে GitHub Actions হিসেবে রেজিস্টার হয় না; উপরের দ্বিতীয় ফাইলটি অবশ্যই থাকতে হবে।
- Android SDK / Gradle এখানে না থাকায় পূর্ণ APK কম্পাইল করা হয়নি; GitHub Actions-এর Build সফল হওয়ার পরই APK যাচাই হবে।
