# GitHub দিয়ে Smart Toolbox Pro APK তৈরি করার নিয়ম

এই প্রজেক্টে GitHub Actions workflow যুক্ত করা আছে। Repository-তে source code push/commit করলে GitHub নিজে থেকে Debug APK build করবে এবং Artifact হিসেবে সংরক্ষণ করবে।

## ১. ZIP Extract করুন

`SmartToolboxPro_GitHub.zip` ফাইলটি Extract করুন। ভিতরের `SmartToolboxPro` ফোল্ডারের সব ফাইল ও ফোল্ডার GitHub repository-তে আপলোড করতে হবে। ZIP ফাইলটি নিজে repository-তে আপলোড করবেন না।

## ২. GitHub Repository তৈরি করুন

1. https://github.com এ সাইন ইন করুন।
2. `New repository` চাপুন।
3. Repository name দিন: `SmartToolboxPro`
4. Public বা Private বেছে নিন।
5. `Create repository` চাপুন।

## ৩. Source code আপলোড করুন

1. নতুন repository-তে `Add file` → `Upload files` নির্বাচন করুন।
2. Extract করা `SmartToolboxPro` ফোল্ডারের ভেতরের সব ফাইল/ফোল্ডার নির্বাচন করে আপলোড করুন।
3. `.github/workflows/build-apk.yml` ফাইলটি অবশ্যই আপলোড হয়েছে কি না নিশ্চিত করুন।
4. নিচে `Commit changes` চাপুন।

**গুরুত্বপূর্ণ:** `.github` একটি hidden folder। মোবাইলের file picker-এ এটি দেখা না গেলে repository-তে `Add file` → `Create new file` নির্বাচন করে filename হিসেবে ঠিক এই path লিখুন:

`.github/workflows/build-apk.yml`

তারপর ZIP-এর একই নামে থাকা workflow ফাইলের সম্পূর্ণ লেখা পেস্ট করে `Commit changes` করুন।

## ৪. GitHub থেকে APK Build করুন

1. Repository-র `Actions` tab খুলুন।
2. `Build Android APK` workflow নির্বাচন করুন।
3. প্রথম commit-এর পর workflow নিজে থেকেই চলার কথা। না চললে `Run workflow` চাপুন।
4. Build job-এ সবুজ টিক চিহ্ন আসা পর্যন্ত অপেক্ষা করুন।
5. সফল run খুলে নিচের `Artifacts` অংশে যান।
6. `SmartToolboxPro-debug-apk` ডাউনলোড করুন।
7. ডাউনলোড করা ZIP Extract করে `app-debug.apk` ফোনে ইনস্টল করুন।

## ৫. Build ব্যর্থ হলে

`Actions` → ব্যর্থ run → `Build debug APK` ধাপের log খুলে error দেখুন। Error log কপি করে সাহায্য চাইলে পাঠাতে পারেন।

## APK সম্পর্কে

- এটি Debug APK; পরীক্ষামূলকভাবে নিজের Android ফোনে ইনস্টল করার জন্য।
- এটি Play Store release/signing build নয়। Public release-এর আগে নিজের release keystore দিয়ে sign করতে হবে।
- প্রথমবার build-এ Android SDK ও Gradle dependency ডাউনলোড হওয়ায় কয়েক মিনিট লাগতে পারে।
- GitHub Actions সফলভাবে APK build করেছে—এটি নিশ্চিত না হওয়া পর্যন্ত APK তৈরি হয়েছে ধরে নেবেন না।
