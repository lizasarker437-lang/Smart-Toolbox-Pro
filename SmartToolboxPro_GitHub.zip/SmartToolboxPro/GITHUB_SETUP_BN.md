# মোবাইল থেকে GitHub-এ SR Smart Toolbox Pro 1.4.4-alpha19 Build

১. `SmartToolboxPro_GitHub.zip` ফাইলটি GitHub Repository-এর root-এ আপলোড / Replace করুন।
২. Repository-এর `.github/workflows/build-apk.yml` ফাইলটি নতুন `build-apk.yml` দিয়ে Replace করুন।
৩. Commit Changes দিন।
৪. GitHub Actions-এ `Build SR Smart Toolbox Pro APK` Workflow চালান।
৫. Build সফল হলে `SR-Smart-Toolbox-Pro-debug-apk` Artifact থেকে APK ডাউনলোড করুন।
৬. ব্যর্থ হলে `SR-Smart-Toolbox-Pro-build-errors` Artifact-এর প্রথম `.java:LINE: error:` লাইনগুলো দেখুন।

পুরোনো অ্যাপের package ID একই (`com.smarttoolbox.pro`), কিন্তু APK update ইনস্টল করতে আগের Signing Key একই হতে হবে।

**পরীক্ষার অবস্থা:** এখানে পূর্ণ Android Gradle Compile হয়নি। GitHub Actions-এর সফল Build ও ফোনে ইনস্টল করে পরীক্ষার পরই এটি বিতরণের উপযোগী বলা যাবে।
