# GitHub Mobile Build — SR Smart Toolbox Pro 1.5.5-alpha31

1. Repository root-এর পুরোনো `SmartToolboxPro_GitHub.zip` নতুন ZIP দিয়ে Replace করো।
2. Repository-এর `.github/workflows/build-apk.yml` ফাইলটি নতুন `build-apk.yml` দিয়ে Replace করো।
3. Commit Changes → Actions → `Build SR Smart Toolbox Pro APK` চালাও।
4. Build সফল হলে `SR-Smart-Toolbox-Pro-debug-apk` Artifact ডাউনলোড করো।
5. ব্যর্থ হলে `Build debug APK` অথবা `Print Java compiler errors (if build fails)`-এ প্রথম `.java:line: error` পাঠাও।

**শুধু `build-apk.yml` আপডেট করলেই নতুন Accessibility Service আসবে না।** নতুন Source ZIP-ও লাগবে।
**Android SDK/Gradle এই পরিবেশে নেই।** পূর্ণ APK Build GitHub Actions-এ করতে হবে।

## Experimental automation চালু করতে
1. অ্যাপ → WhatsApp Smart Scheduler → ⋮ → Alarm, Notification & Automation Settings → Experimental Auto-Send & Unlock (ডিফল্ট OFF)।
2. Accessibility Service ম্যানুয়ালি চালু করো; Overlay, Alarm ও Notification permission দাও।
3. Locked PIN Attempt চাইলে আগে PIN encrypted storage-এ Save করে আলাদা toggle ON করো।
4. নিজের নম্বরে পরীক্ষা করো। Android/WhatsApp restriction-এর কারণে ফলাফল নিশ্চয়তাপূর্ণ নয়।

### নতুন UI
Recent Recipient History-এর +/−, Quick Templates, 10s Test এবং শিডিউলের Remaining Time-এর তথ্য `SMART_SCHEDULER_UI_UPDATE_BN.md`-এ আছে।

## Update 1.5.4-alpha30
Repository-তে `SmartToolboxPro_GitHub.zip` ও `.github/workflows/build-apk.yml` একই release থেকে Replace করুন। Actions সফল হলে APK Artifact ডাউনলোড করুন।
Screen ON-এর 3→2→1 Reminder দেখাতে Display Over Other Apps Permission এবং Accessibility Service চালু প্রয়োজন। Restore App Android-এর Task Back Stack অনুযায়ী best-effort।

## Update 1.5.4-alpha30 — Template, Group Message & Theme Studio
- Scheduler-এ ⋮ → Manage / Add Quick Templates থেকে built-in বা custom template Add, Edit, Delete করা যাবে।
- Single Message এবং Group / Broadcast mode আলাদা। Group mode-এ Contacts থেকে একাধিক নম্বর বেছে নেওয়া বা comma/semicolon/new line দিয়ে নম্বর দেওয়া যাবে।
- Group mode সর্বোচ্চ ২০ জনকে একই মেসেজ আলাদা WhatsApp chat-এ পাঠানোর শিডিউল করে; সবার নির্ধারিত সময় একই; আলাদা চ্যাটে Send চেষ্টা পর্যায়ক্রমে। এটি WhatsApp group chat নয়।
- প্রথমবার Select many চাপলে Contacts permission চাইবে।
- Theme Settings-এ ৯টি palette এবং System / Light / Dark appearance mode আছে।
- Source ZIP এবং workflow একই release থেকে Replace করতে হবে।

## Compile fix — 1.5.4-alpha30
`MessageSchedulerActivity.java`-এর missing `SchedulerDisplayLogic.messagePreview(String, int)` method যোগ করা হয়েছে। এই fix-এর জন্য Source ZIP এবং workflow দুটোই নতুন release থেকে Replace করতে হবে। Build-এর পূর্ণ ফলাফল Actions-এ যাচাই করো।

## Update 1.5.5-alpha31 — Group Name / Contacts / History
- **From Contacts** দিয়ে ১ জন; **Select many Contacts** দিয়ে সর্বোচ্চ ২০ জন যোগ করা যায়। একাধিক Contacts পড়তে READ_CONTACTS অনুমতি দিতে হবে।
- **Group Name** ব্যাচ চিহ্নিত করার নাম, নতুন WhatsApp Group তৈরি নয়। সব প্রাপকের due-time একই।
- আগের ৬০ সেকেন্ড ইচ্ছাকৃত Interval নেই; WhatsApp UI একসঙ্গে একাধিক chat চালাতে পারে না, তাই Automation queue-তে একে একে Send চেষ্টা করবে।
- আগের History থেকে **Edit message & schedule again** করলে পুরোনো History না পাল্টিয়ে নতুন Schedule তৈরি হবে।
- GitHub Actions থেকে APK Build সফল হয়েছে কি না যাচাই করে তারপর ইনস্টল করুন।
