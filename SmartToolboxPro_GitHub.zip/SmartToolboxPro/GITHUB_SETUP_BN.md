# GitHub Mobile Build — SR Smart Toolbox Pro 1.5.12-alpha38

এই আপডেটের জন্য **SmartToolboxPro_GitHub.zip** এবং **.github/workflows/build-apk.yml** দুটি একই Release থেকে আপলোড করুন।
App Launcher-এ Branding Animation, Scheduler Group Card-এ সব নম্বর একসঙ্গে থাকবে।
Android SDK / Gradle এখানে নেই, তাই GitHub Actions Build এবং ফোনে UI পরীক্ষা প্রয়োজন।

# GitHub Mobile Build — SR Smart Toolbox Pro 1.5.10-alpha36

1. Repository root-এর পুরোনো `SmartToolboxPro_GitHub.zip` নতুন ZIP দিয়ে Replace করো।
2. Repository-এর `.github/workflows/build-apk.yml` ফাইলটি নতুন `build-apk.yml` দিয়ে Replace করো।
3. Commit Changes → Actions → `Build SR Smart Toolbox Pro APK` চালাও।
4. Build সফল হলে `SR-Smart-Toolbox-Pro-debug-apk` Artifact ডাউনলোড করো।
5. ব্যর্থ হলে `Build debug APK` অথবা `Print Java compiler errors (if build fails)`-এ প্রথম `.java:line: error` পাঠাও।

**শুধু `build-apk.yml` আপডেট করলেই নতুন Accessibility Service আসবে না।** নতুন Source ZIP-ও লাগবে।
**Android SDK/Gradle এই পরিবেশে নেই।** পূর্ণ APK Build GitHub Actions-এ করতে হবে।

## Experimental automation চালু করতে
1. অ্যাপ → WhatsApp Smart Scheduler → ⋮ → Alarm, Notification & Automation Settings → Experimental Auto-Send & Unlock (ডিফল্ট OFF)।
2. Accessibility Service ম্যানুয়ালি চালু করো; Overlay, Alarm ও Notification permission দাও।
3. Locked PIN Attempt চাইলে আগে PIN encrypted storage-এ Save করে আলাদা toggle ON করো।
4. নিজের নম্বরে পরীক্ষা করো। Android/WhatsApp restriction-এর কারণে ফলাফল নিশ্চয়তাপূর্ণ নয়।

### নতুন UI
Recent Recipient History-এর +/−, Quick Templates, 10s Test এবং শিডিউলের Remaining Time-এর তথ্য `SMART_SCHEDULER_UI_UPDATE_BN.md`-এ আছে।

## Update 1.5.4-alpha30
Repository-তে `SmartToolboxPro_GitHub.zip` ও `.github/workflows/build-apk.yml` একই release থেকে Replace করুন। Actions সফল হলে APK Artifact ডাউনলোড করুন।
Screen ON-এর 3→2→1 Reminder দেখাতে Display Over Other Apps Permission এবং Accessibility Service চালু প্রয়োজন। Restore App Android-এর Task Back Stack অনুযায়ী best-effort।

## Update 1.5.4-alpha30 — Template, Group Message & Theme Studio
- Scheduler-এ ⋮ → Manage / Add Quick Templates থেকে built-in বা custom template Add, Edit, Delete করা যাবে।
- Single Message এবং Group / Broadcast mode আলাদা। Group mode-এ Contacts থেকে একাধিক নম্বর বেছে নেওয়া বা comma/semicolon/new line দিয়ে নম্বর দেওয়া যাবে।
- Group mode সর্বোচ্চ ২০ জনকে একই মেসেজ আলাদা WhatsApp chat-এ পাঠানোর শিডিউল করে; সবার নির্ধারিত সময় একই; আলাদা চ্যাটে Send চেষ্টা পর্যায়ক্রমে। এটি WhatsApp group chat নয়।
- প্রথমবার Select many চাপলে Contacts permission চাইবে।
- Theme Settings-এ ৯টি palette এবং System / Light / Dark appearance mode আছে।
- Source ZIP এবং workflow একই release থেকে Replace করতে হবে।

## Compile fix — 1.5.4-alpha30
`MessageSchedulerActivity.java`-এর missing `SchedulerDisplayLogic.messagePreview(String, int)` method যোগ করা হয়েছে। এই fix-এর জন্য Source ZIP এবং workflow দুটোই নতুন release থেকে Replace করতে হবে। Build-এর পূর্ণ ফলাফল Actions-এ যাচাই করো।

## Update 1.5.5-alpha31 — Group Name / Contacts / History
- **From Contacts** দিয়ে ১ জন; **Select many Contacts** দিয়ে সর্বোচ্চ ২০ জন যোগ করা যায়। একাধিক Contacts পড়তে READ_CONTACTS অনুমতি দিতে হবে।
- **Group Name** ব্যাচ চিহ্নিত করার নাম, নতুন WhatsApp Group তৈরি নয়। সব প্রাপকের due-time একই।
- আগের ৬০ সেকেন্ড ইচ্ছাকৃত Interval নেই; WhatsApp UI একসঙ্গে একাধিক chat চালাতে পারে না, তাই Automation queue-তে একে একে Send চেষ্টা করবে।
- আগের History থেকে **Edit message & schedule again** করলে পুরোনো History না পাল্টিয়ে নতুন Schedule তৈরি হবে।
- GitHub Actions থেকে APK Build সফল হয়েছে কি না যাচাই করে তারপর ইনস্টল করুন।

## Update 1.5.6-alpha32 — Scheduler Inbox Folders
- নতুন `SmartToolboxPro_GitHub.zip` এবং `build-apk.yml` একই release থেকে আপলোড করুন।
- আজ/আগামীকাল/পরবর্তী/History/Paused ফোল্ডারে শিডিউল সাজানো থাকবে; আগে সেভ করা মেসেজ মুছে যাবে না।
- নতুন GitHub Workflow-এ `Verify collapsible scheduler inbox sections and local-date grouping` Test আছে।

## Update 1.5.7-alpha33 — Notepad ও Portrait Video Edge
- পুরোনো `SmartToolboxPro_GitHub.zip` সম্পূর্ণ Replace করুন, সঙ্গে `.github/workflows/build-apk.yml`-ও এই release-এরটি দিয়ে Replace করুন।
- Auto Scheduler → ⋮ → Scheduler Notepad অথবা Message Input-এর নিচে **Notepad থেকে মেসেজ নিন**।
- Floating Icon Settings → **Portrait video-তে floating icon কিনারায় রাখুন**।
- ভিডিও চলা শুরু করলে Portrait-এ Edge Tab; ভিডিও Pause/Exit করলে আগের অবস্থান। Android Overlay Permission প্রয়োজন।
- GitHub Actions-এ `Verify scheduler notepad and portrait video edge` এবং `Build debug APK` দুটোই PASS হয়েছে কি না পরীক্ষা করুন।

## v1.5.8-alpha34 — All Apps Portrait Edge
1. GitHub root-এ একই Release থেকে `SmartToolboxPro_GitHub.zip` Replace করুন।
2. `.github/workflows/build-apk.yml` Replace করুন।
3. Actions → Build SR Smart Toolbox Pro APK চালান।
4. APK ইনস্টল → Floating Icon Settings → **Portrait Edge — ALL apps** ON। Display over other apps Permission চালু রাখতে হবে।
5. YouTube, Gallery, অন্য Player ও Home Screen-এ Portrait/Landscape ঘুরিয়ে পরীক্ষা করুন।

Android/OEM Overlay Restriction ও Lock Screen-এ Edge Tab সবসময় দৃশ্যমান নাও থাকতে পারে।

## Update 1.5.9-alpha35 — Floating Bar Swipe Menu
Repository root-এ নতুন `SmartToolboxPro_GitHub.zip` ও `.github/workflows/build-apk.yml` একই release থেকে Replace করুন। Actions-এ `Verify floating bar swipe opens controls in Home and other apps` এবং `Build debug APK` পরীক্ষার ফলাফল দেখুন।
ফোনে Home, YouTube, অন্য অ্যাপের ওপর Edge Tab-এ Tap, ভিতরের দিকে Swipe ও উপর/নিচে Slide করে দেখুন। Android Gesture Navigation বা Protected Window Overlay বন্ধ করতে পারে।

## Update 1.5.10-alpha36 — Night Screen Minimum Brightness
- `SmartToolboxPro_GitHub.zip` এবং `build-apk.yml` দুটোই একই Release থেকে Replace করুন।
- Night Screen-এর Black Overlay-এর জন্য Display over other apps অনুমতি; Physical Brightness কমাতে আলাদা Modify system settings অনুমতি দিন।
- System Brightness documented minimum 1/255 (০ নয়)। Night Screen OFF করলে আগের Brightness ও Auto Mode ফিরবে, যদি অন্য কেউ সেটা ইতোমধ্যে পরিবর্তন না করে থাকে।
- GitHub Actions-এ `Verify minimum-brightness Night Screen and restore-safety regression` Test যোগ হয়েছে।

## Update 1.5.11-alpha37
- Repo-তে নতুন `SmartToolboxPro_GitHub.zip` আপলোড/Replace করুন।
- `.github/workflows/build-apk.yml` ফাইলে নতুন দেওয়া `build-apk.yml` আপলোড/Replace করুন।
- Actions-এ Android APK Build চালান। GitHub Source ZIP ও YAML অবশ্যই একই Release-এর হতে হবে।
- APK-তে Floating Icon Settings → Tap to Open / Swipe to Open দুটি আলাদা অপশন পাবেন। Hold 2 Seconds then Drag দিয়ে বড় আইকন বা Edge Bar নড়ানো যাবে।
