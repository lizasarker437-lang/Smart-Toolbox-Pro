# Smart Toolbox Pro 1.2.5-alpha8 — Floating Sidebar

- The floating quick panel is organized into four feature cards: Night Screen, Thermal Monitor, Master Volume and Document Scanner.
- Each card keeps its own ON/OFF action and related controls together.
- The Night Screen card includes darkness and system-brightness sliders.
- The Thermal Monitor card shows live battery temperature and Android thermal status.
- The Master Volume card includes its own gain slider.
- The former separate bottom actions are removed; a compact × control in the top header closes the panel.
- Auto-hide delay is configurable from 1 to 60 seconds in Floating Icon Settings.
- Edge-tab thickness is adjustable from 6 dp to 26 dp.
- Floating bubble size is adjustable from 24 dp to 76 dp.
- Opacity remains adjustable from 30% to 100%.
- Sidebar can remain enabled even when all tools are OFF.
- Android Display over other apps permission is required.
