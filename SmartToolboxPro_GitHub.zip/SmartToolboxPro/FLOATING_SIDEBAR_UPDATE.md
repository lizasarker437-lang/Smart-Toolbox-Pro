# Smart Toolbox Pro 1.2.2-alpha5 — Floating Sidebar

Changes:
- The ST floating bubble now auto-hides after 4 seconds without interaction.
- When hidden, a small vertical tab remains attached to the nearest screen edge.
- Tapping the edge tab restores the floating icon and opens the quick control panel.
- The auto-hidden state and edge position are saved and restored if Android restarts the service.
- Auto-hide can be turned on/off in Floating Icon Settings.
- Floating sidebar visibility is now independent of tool activity.
- The sidebar can remain enabled when Night Screen, Extra Volume, Thermal Monitor and Scanner are all OFF.
- The main app and Floating Icon Settings can turn the sidebar on/off.
- Android's Display over other apps permission is still required.

Compatibility:
- The foreground notification remains while the floating sidebar is enabled.
- If the sidebar is disabled in settings or from the quick panel, its service stops.
- Existing Night Screen and Extra Volume quick sliders remain in the panel.
