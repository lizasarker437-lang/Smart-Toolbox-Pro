# Smart Toolbox Pro 1.2.4-alpha7 — Floating Sidebar

- Auto-hide delay is configurable from 1 to 60 seconds in Floating Icon Settings.
- When hidden, a thin tab remains attached to the nearest screen edge.
- Edge-tab thickness is adjustable from 6 dp to 26 dp.
- Floating bubble size is adjustable from 24 dp to 76 dp.
- Opacity remains adjustable from 30% to 100%.
- Sidebar can remain enabled even when all tools are OFF.
- Tap the edge tab to restore the icon and quick controls.
- Android Display over other apps permission is required.
