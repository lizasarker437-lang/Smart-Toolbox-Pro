# Smart Toolbox Pro 1.2.6-alpha9 — Floating Sidebar and Quick Controls

- Night Screen ON/OFF, darkness and system-brightness sliders are integrated in one feature card.
- Thermal Monitor ON/OFF and live temperature readout are integrated in one feature card.
- Master Volume ON/OFF and boost slider are integrated in one feature card.
- Document Scanner remains the fourth feature card.
- Floating panel auto-close uses the configured 1–60 second Auto-hide delay.
- The countdown starts when the panel opens and restarts after feature actions, touch/scroll, and slider release.
- Countdown pauses while a slider is being dragged.
- When it expires, the panel always closes; the floating bubble collapses to its edge handle only if Auto-hide is enabled.
- No separate Cancel action is required.
- Auto-hide can be configured in Floating Icon Settings.
- Edge-tab thickness is adjustable from 6 dp to 26 dp.
- Floating bubble size is adjustable from 24 dp to 76 dp.
- Opacity remains adjustable from 30% to 100%.
- Sidebar can remain enabled even when all tools are OFF.
- Android Display over other apps permission is required.
