# মোবাইল দিয়ে SR Smart Toolbox Pro 1.4.7-alpha22 Build

১. GitHub Repository root-এ পুরোনো `SmartToolboxPro_GitHub.zip` ফাইলটি নতুনটি দিয়ে Replace করুন।
২. `.github/workflows/build-apk.yml` ফাইলটিও নতুন `build-apk.yml` দিয়ে Replace করুন।
৩. Commit Changes দিন।
৪. GitHub Actions → **Build SR Smart Toolbox Pro APK** খুলুন।
৫. Build সফল হলে **SR-Smart-Toolbox-Pro-debug-apk** Artifact ডাউনলোড করুন।
৬. Build ব্যর্থ হলে **SR-Smart-Toolbox-Pro-build-errors** Artifact বা প্রথম `.java:LINE: error:` লাইনগুলো দেখুন।

নতুন UI: Home → ⋮ → Floating Icon Settings → **Toolbox panel size**।

**সতর্কতা:** এখানে Full Android Gradle Build করা হয়নি। GitHub Actions সফল ও ফোনে পরীক্ষা হওয়ার পরই APK Compile/Runtime যাচাই সম্পূর্ণ হবে। পুরোনো APK-কে সরাসরি আপডেট করতে Signing Key একই থাকতে হবে।
