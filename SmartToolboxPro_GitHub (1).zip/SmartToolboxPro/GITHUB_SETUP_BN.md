# SR Smart Toolbox Pro 1.4.2-alpha17 — মোবাইল থেকে GitHub Build

Repository-তে এই দুইটি জিনিস আপডেট করতে হবে:

1. `SmartToolboxPro_GitHub.zip` — সম্পূর্ণ Android source project।
2. `.github/workflows/build-apk.yml` — GitHub Actions workflow।

## ফোন থেকে আপডেট
1. `SmartToolboxPro_GitHub.zip` ডাউনলোড করুন।
2. GitHub Repository-এর root-এ পুরোনো একই নামের ZIP বদলে নতুন ZIP আপলোড করুন।
3. `.github/workflows/build-apk.yml` খুলে নতুন workflow ফাইলের কোড দিয়ে প্রতিস্থাপন করুন।
4. Commit Changes চাপুন।
5. Actions → `Build SR Smart Toolbox Pro APK` খুলুন।
6. Run সফল হলে `SR-Smart-Toolbox-Pro-debug-apk` Artifact ডাউনলোড করুন।
7. ব্যর্থ হলে `SR-Smart-Toolbox-Pro-build-errors` Artifact অথবা build log দেখুন।

## Build configuration
- JDK 17
- Android Gradle Plugin 8.10.0
- Gradle 8.11.1
- Android platform 36, build-tools 35.0.0
- compileSdk 36 / targetSdk 35
- Media3 1.11.1

## গুরুত্বপূর্ণ
- Workflow ZIP-এর মধ্যে `SmartToolboxPro/app/build.gradle` খুঁজে Android project root শনাক্ত করে।
- শুধু MP4 / PNG / TXT-সহ media package Android source ZIP নয়।
- এই workspace-এ Android SDK / Gradle নেই; তাই APK তৈরি হয়েছে বলে দাবি করা হচ্ছে না। GitHub Actions Build সফল হওয়ার পরই APK ডাউনলোড করুন।
- APK install করার আগে ফোনে আগের অ্যাপের signing key সামঞ্জস্য থাকতে হবে।
