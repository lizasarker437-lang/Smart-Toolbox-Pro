# Smart Toolbox Pro — Android Project

চারটি Android utility feature এক অ্যাপে আনার Alpha source project। GitHub Actions workflow যুক্ত আছে; repository-তে commit করলে Debug APK build করার চেষ্টা করবে।

## অন্তর্ভুক্ত ফিচার

### Night Screen
- অন্য অ্যাপের ওপর dim overlay
- Dim level slider
- Warm / blue-light style overlay
- Android Quick Settings tile

### Volume Controls
- Media, ringtone ও notification volume slider
- Media volume-এর 40%, 60%, 80% ও Max preset
- Android-এর নির্ধারিত সর্বোচ্চ ভলিউম অতিক্রম করে না

### Thermal Monitor
- Battery temperature (যদি ডিভাইস রিপোর্ট করে)
- Android 10+ thermal status listener
- Thermal status অনুযায়ী সতর্কতা

### Document Scanner
- Camera app দিয়ে ছবি তোলা
- Gallery থেকে একাধিক ছবি বাছাই
- একাধিক ছবিকে PDF-এ রূপান্তর
- OCR text extraction

## GitHub দিয়ে APK তৈরি

বিস্তারিত বাংলা নির্দেশনা: [`GITHUB_SETUP_BN.md`](GITHUB_SETUP_BN.md)

Workflow: [`.github/workflows/build-apk.yml`](.github/workflows/build-apk.yml)

সংক্ষেপে: প্রজেক্টের সব ফাইল GitHub repository-তে upload/commit করুন → `Actions` tab খুলুন → `Build Android APK` run সফল হলে `SmartToolboxPro-debug-apk` Artifact ডাউনলোড করুন।

## এখনো পরের সংস্করণে যোগ করতে হবে

- Camera preview-এর মধ্যে automatic document-edge detection ও auto crop
- Manual crop / perspective correction / scan filters
- Night Screen-এর schedule-based auto start/stop
- Advanced equalizer / bass processing (সব ডিভাইসে global audio processing সম্ভব নয়)
- উন্নত thermal history chart ও floating status widget

## প্রযুক্তিগত তথ্য

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (GitHub Actions-এ provision করা হয়)
- Java: 17
- Compile SDK: 35
- Minimum Android: 8.0 (API 26)

## সীমাবদ্ধতা ও সতর্কতা

- এই পরিবেশে Android SDK/Gradle build চালানো হয়নি। GitHub Actions-এ প্রথম build চালিয়ে compilation যাচাই করতে হবে।
- Debug APK পরীক্ষার জন্য; Play Store release-এর জন্য release keystore দিয়ে আলাদা signing configuration প্রয়োজন।
- CPU/GPU-এর প্রকৃত তাপমাত্রা সব Android ডিভাইসে পাওয়া যায় না।
- Volume control ফোনের Android/audio hardware-এর সর্বোচ্চ সীমার মধ্যে কাজ করে।
