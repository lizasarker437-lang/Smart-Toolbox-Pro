package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

public class FloatingControlService extends Service {
    public static final String ACTION_SHOW = "com.smarttoolbox.pro.FLOAT_SHOW";
    public static final String ACTION_REFRESH = "com.smarttoolbox.pro.FLOAT_REFRESH";
    public static final String ACTION_HIDE = "com.smarttoolbox.pro.FLOAT_HIDE";

    private static final String CHANNEL_ID = "floating_controls";
    private static final int NOTIFICATION_ID = 2401;
    // Floating quick controls close after 3 seconds of inactivity.
    private static final long PANEL_IDLE_TIMEOUT_MS = 3000L;

    private WindowManager windowManager;
    private TextView bubble;
    private ScrollView panel;
    private LinearLayout panelContent;
    private FrameLayout edgeHandle;
    private TextView thermalReadout;
    private WindowManager.LayoutParams edgeParams;
    private Runnable thermalReadoutRunnable;
    private final Handler sliderHandler = new Handler(Looper.getMainLooper());
    private final Handler autoHideHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingNightUpdate;
    private Runnable pendingAudioUpdate;
    private Runnable autoHideRunnable;
    private Runnable panelAutoCloseRunnable;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private boolean autoHidden;
    private int touchSlop;
    private float downRawX;
    private float downRawY;
    private int downX;
    private int downY;
    private boolean dragged;
    private float edgeTouchStartX;
    private float edgeTouchStartY;
    private boolean edgeSwipeHandled;

    public static boolean hasOverlayPermission(Context context) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context);
    }

    public static boolean start(Context context) {
        if (!hasOverlayPermission(context)) return false;
        android.content.SharedPreferences prefs = context.getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.getBoolean("floating.enabled", true)) return false;
        prefs.edit().putBoolean("floating.hidden", false)
                .putBoolean("floating.auto_hidden", false).apply();
        Intent intent = new Intent(context, FloatingControlService.class);
        intent.setAction(ACTION_SHOW);
        ContextCompat.startForegroundService(context, intent);
        return true;
    }

    public static void refresh(Context context) {
        Intent intent = new Intent(context, FloatingControlService.class);
        intent.setAction(ACTION_REFRESH);
        android.content.SharedPreferences prefs = context.getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean hidden = prefs.getBoolean("floating.hidden", false);
        boolean enabled = prefs.getBoolean("floating.enabled", true);
        // The floating sidebar is an independent user-controlled feature.
        // It remains available even when every toolbox feature is OFF.
        if (hidden || !enabled || !hasOverlayPermission(context)) {
            context.stopService(new Intent(context, FloatingControlService.class));
        } else {
            ContextCompat.startForegroundService(context, intent);
        }
    }

    public static boolean anyFeatureActive(Context context) {
        boolean night = context.getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        boolean thermal = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("thermal.active", false);
        boolean audio = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("audio.active", false);
        boolean scanner = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("scanner.active", false);
        return night || thermal || audio || scanner;
    }

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_REFRESH : intent.getAction();

        if (ACTION_HIDE.equals(action)) {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("floating.hidden", true).putBoolean("floating.enabled", false).apply();
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (!hasOverlayPermission(this)) {
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification());
        }

        android.content.SharedPreferences floatingPrefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean hidden = floatingPrefs.getBoolean("floating.hidden", false);
        boolean enabled = floatingPrefs.getBoolean("floating.enabled", true);
        if (hidden || !enabled) {
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        boolean panelWasOpen = panel != null;
        boolean autoHideEnabled = floatingPrefs.getBoolean("floating.auto_hide", true);
        boolean savedAsAutoHidden = floatingPrefs.getBoolean("floating.auto_hidden", false);

        // Preserve the edge tab across ordinary refreshes and service restarts.
        // ACTION_SHOW is an explicit request to reveal the full icon.
        if (savedAsAutoHidden && autoHideEnabled && !ACTION_SHOW.equals(action)) {
            if (edgeHandle != null && bubble == null) return START_STICKY;
            removePanelAndBubble();
            autoHidden = true;
            showEdgeHandleFromSavedPosition();
            return START_STICKY;
        }

        if (ACTION_SHOW.equals(action) || !autoHideEnabled) {
            floatingPrefs.edit().putBoolean("floating.auto_hidden", false).apply();
            autoHidden = false;
        }

        boolean nightIsActive = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        if ((ACTION_SHOW.equals(action) || ACTION_REFRESH.equals(action) || nightIsActive) && bubble != null) {
            // Re-add after settings changes or Night Screen overlay so size, opacity and z-order refresh.
            removePanelAndBubble();
        }
        ensureBubble();
        if (panelWasOpen && getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.panel.enabled", true)) showPanel();
        return START_STICKY;
    }

    private void ensureBubble() {
        if (bubble != null) return;
        cancelAutoHide();
        removeEdgeHandle();
        autoHidden = false;
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.auto_hidden", false).apply();

        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        int sizeDp = Math.max(24, Math.min(76, prefs.getInt("floating.size", 54)));
        int opacity = Math.max(30, Math.min(100, prefs.getInt("floating.opacity", 100)));

        bubble = new TextView(this);
        bubble.setText("ST");
        bubble.setContentDescription("SR Smart Toolbox floating controls. Tap to open, drag to move.");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(Math.max(12, Math.min(18, sizeDp * 0.28f)));
        bubble.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(255, 166, 35));
        circle.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(circle);
        bubble.setAlpha(opacity / 100f);
        bubble.setElevation(dp(8));

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int sizePx = dp(sizeDp);
        bubbleParams = new WindowManager.LayoutParams(
                sizePx, sizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;

        int savedX = prefs.getInt("floating.x", -1);
        int savedY = prefs.getInt("floating.y", -1);
        bubbleParams.x = savedX >= 0
                ? Math.max(0, Math.min(metrics.widthPixels - sizePx, savedX))
                : Math.max(dp(8), metrics.widthPixels - sizePx - dp(14));
        bubbleParams.y = savedY >= 0
                ? Math.max(0, Math.min(metrics.heightPixels - sizePx, savedY))
                : Math.max(dp(90), metrics.heightPixels / 3);

        bubble.setOnTouchListener((view, event) -> handleBubbleTouch(event));
        try {
            windowManager.addView(bubble, bubbleParams);
            scheduleAutoHide();
        } catch (Exception e) {
            bubble = null;
            bubbleParams = null;
            stopSelf();
        }
    }

    private boolean handleBubbleTouch(MotionEvent event) {
        if (bubbleParams == null) return true;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                cancelAutoHide();
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                downX = bubbleParams.x;
                downY = bubbleParams.y;
                dragged = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                int dx = (int) (event.getRawX() - downRawX);
                int dy = (int) (event.getRawY() - downRawY);
                if (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop) dragged = true;
                if (dragged) {
                    DisplayMetrics metrics = new DisplayMetrics();
                    windowManager.getDefaultDisplay().getMetrics(metrics);
                    bubbleParams.x = Math.max(0, Math.min(metrics.widthPixels - bubbleParams.width, downX + dx));
                    bubbleParams.y = Math.max(0, Math.min(metrics.heightPixels - bubbleParams.height, downY + dy));
                    try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragged && bubbleParams != null) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("floating.x", bubbleParams.x)
                            .putInt("floating.y", bubbleParams.y).apply();
                } else if (panel != null) {
                    // The floating bubble is outside the quick panel; tapping it dismisses.
                    dismissPanelFromOutsideTouch();
                } else if (getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getBoolean("floating.panel.enabled", true)) {
                    showPanel();
                } else {
                    scheduleAutoHide();
                }
                if (dragged) scheduleAutoHide();
                return true;
            case MotionEvent.ACTION_CANCEL:
                scheduleAutoHide();
                return true;
            default:
                return true;
        }
    }

    private boolean isAutoHideEnabled() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.auto_hide", true);
    }

    private void cancelAutoHide() {
        if (autoHideRunnable != null) {
            autoHideHandler.removeCallbacks(autoHideRunnable);
            autoHideRunnable = null;
        }
    }

    private void cancelPanelAutoClose() {
        if (panelAutoCloseRunnable != null) {
            autoHideHandler.removeCallbacks(panelAutoCloseRunnable);
            panelAutoCloseRunnable = null;
        }
    }

    private void schedulePanelAutoClose() {
        cancelPanelAutoClose();
        if (panel == null) return;

        panelAutoCloseRunnable = () -> {
            panelAutoCloseRunnable = null;
            if (panel == null) return;
            removePanel();
            // The quick panel has a fixed three-second idle timeout.
            // Edge-collapse separately follows the user-selected icon auto-hide setting.
            if (isAutoHideEnabled() && bubble != null && bubbleParams != null) {
                hideBubbleToEdge();
            }
        };
        autoHideHandler.postDelayed(panelAutoCloseRunnable, PANEL_IDLE_TIMEOUT_MS);
    }

    // An outside tap should dismiss the panel immediately, even during the first 3 seconds.
    // We do not capture or consume touches made in another application.
    private void dismissPanelFromOutsideTouch() {
        if (panel == null) return;
        removePanel();
        if (isAutoHideEnabled() && bubble != null && bubbleParams != null) {
            hideBubbleToEdge();
        } else {
            scheduleAutoHide();
        }
    }

    private void scheduleAutoHide() {
        cancelAutoHide();
        if (!isAutoHideEnabled() || bubble == null || panel != null) return;
        autoHideRunnable = this::hideBubbleToEdge;
        int delaySeconds = Math.max(1, Math.min(60,
                getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getInt("floating.auto_hide_seconds", 4)));
        autoHideHandler.postDelayed(autoHideRunnable, delaySeconds * 1000L);
    }

    private void hideBubbleToEdge() {
        autoHideRunnable = null;
        if (bubble == null || bubbleParams == null || panel != null || !isAutoHideEnabled()) return;

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        boolean leftSide = bubbleParams.x + bubbleParams.width / 2 < metrics.widthPixels / 2;
        int centerY = bubbleParams.y + bubbleParams.height / 2;

        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putInt("floating.x", bubbleParams.x)
                .putInt("floating.y", bubbleParams.y)
                .putBoolean("floating.edge.left", leftSide)
                .putInt("floating.edge.y", centerY)
                .putBoolean("floating.auto_hidden", true)
                .apply();

        try { windowManager.removeView(bubble); } catch (Exception ignored) {}
        bubble = null;
        bubbleParams = null;
        autoHidden = true;
        showEdgeHandle(leftSide, centerY);
    }

    private void showEdgeHandleFromSavedPosition() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        int savedX = prefs.getInt("floating.x", -1);
        int sizePx = dp(Math.max(24, Math.min(76, prefs.getInt("floating.size", 54))));
        boolean leftSide = prefs.getBoolean("floating.edge.left",
                savedX >= 0 && savedX + sizePx / 2 < metrics.widthPixels / 2);
        int centerY = prefs.getInt("floating.edge.y",
                prefs.getInt("floating.y", metrics.heightPixels / 3));
        showEdgeHandle(leftSide, centerY);
    }

    private void showEdgeHandle(boolean leftSide, int centerY) {
        if (edgeHandle != null) return;
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        int edgeWidthDp = Math.max(6, Math.min(26, prefs.getInt("floating.edge.width", 12)));
        // A slim visible tab, but a 32dp touch target so inward swipes work even at 6dp.
        int touchWidthDp = Math.max(32, edgeWidthDp);
        int height = dp(70);
        int touchWidth = dp(touchWidthDp);

        edgeHandle = new FrameLayout(this);
        edgeHandle.setContentDescription(leftSide
                ? "Swipe right to reveal SR Smart Toolbox" : "Swipe left to reveal SR Smart Toolbox");
        edgeHandle.setClickable(true);

        TextView strip = new TextView(this);
        strip.setText(edgeWidthDp <= 10 ? "" : (leftSide ? "›" : "‹"));
        strip.setTextColor(Color.WHITE);
        strip.setTextSize(Math.max(10f, Math.min(18f, edgeWidthDp)));
        strip.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        strip.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(255, 166, 35));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Color.WHITE);
        strip.setBackground(bg);
        int opacity = Math.max(30, Math.min(100, prefs.getInt("floating.opacity", 100)));
        strip.setAlpha(Math.max(0.65f, opacity / 100f));
        FrameLayout.LayoutParams stripLayout = new FrameLayout.LayoutParams(
                dp(edgeWidthDp), FrameLayout.LayoutParams.MATCH_PARENT,
                leftSide ? Gravity.START : Gravity.END);
        edgeHandle.addView(strip, stripLayout);

        edgeParams = new WindowManager.LayoutParams(
                touchWidth, height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        edgeParams.gravity = Gravity.TOP | Gravity.START;
        edgeParams.x = leftSide ? 0 : Math.max(0, metrics.widthPixels - touchWidth);
        edgeParams.y = Math.max(dp(8), Math.min(metrics.heightPixels - height - dp(8),
                centerY - height / 2));

        edgeHandle.setOnTouchListener((view, event) -> handleEdgeGesture(event, leftSide));
        try {
            windowManager.addView(edgeHandle, edgeParams);
        } catch (Exception e) {
            edgeHandle = null;
            edgeParams = null;
            stopSelf();
        }
    }

    // Either an inward swipe or an edge-tab tap opens the full quick-control panel.
    private boolean handleEdgeGesture(MotionEvent event, boolean leftSide) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                edgeTouchStartX = event.getRawX();
                edgeTouchStartY = event.getRawY();
                edgeSwipeHandled = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!edgeSwipeHandled) {
                    float dx = event.getRawX() - edgeTouchStartX;
                    float dy = event.getRawY() - edgeTouchStartY;
                    boolean inward = EdgeSwipeLogic.isInwardSwipe(leftSide, dx, dy, dp(22));
                    if (inward) {
                        edgeSwipeHandled = true;
                        restoreBubbleFromEdge(true);
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (!edgeSwipeHandled) {
                    float dx = event.getRawX() - edgeTouchStartX;
                    float dy = event.getRawY() - edgeTouchStartY;
                    if (Math.abs(dx) < dp(22) && Math.abs(dy) < dp(22)) {
                        restoreBubbleFromEdge(true);
                    }
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                return true;
            default:
                return true;
        }
    }

    private void restoreBubbleFromEdge(boolean openPanel) {
        cancelAutoHide();
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean leftSide = prefs.getBoolean("floating.edge.left", false);
        int edgeCenterY = prefs.getInt("floating.edge.y", getResources().getDisplayMetrics().heightPixels / 3);
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int sizePx = dp(Math.max(24, Math.min(76, prefs.getInt("floating.size", 54))));
        int bubbleX = EdgeSwipeLogic.bubbleXForSide(
                leftSide, metrics.widthPixels, sizePx, dp(5));
        int bubbleY = Math.max(0, Math.min(metrics.heightPixels - sizePx, edgeCenterY - sizePx / 2));
        prefs.edit().putBoolean("floating.auto_hidden", false)
                .putInt("floating.x", bubbleX).putInt("floating.y", bubbleY).apply();
        removeEdgeHandle();
        autoHidden = false;
        ensureBubble();
        if (openPanel && getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.panel.enabled", true)) {
            showPanel();
        }
    }

    private void removeEdgeHandle() {
        if (edgeHandle != null) {
            try { windowManager.removeView(edgeHandle); } catch (Exception ignored) {}
            edgeHandle = null;
            edgeParams = null;
        }
    }

    private void showPanel() {
        cancelAutoHide();
        removePanel();
        if (bubble == null || bubbleParams == null) return;

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(20, 26, 34));
        background.setCornerRadius(dp(18));
        background.setStroke(dp(1), Color.rgb(76, 88, 104));

        panel = new ScrollView(this) {
            @Override public boolean dispatchTouchEvent(MotionEvent event) {
                if (event.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                    dismissPanelFromOutsideTouch();
                    return true;
                }
                return super.dispatchTouchEvent(event);
            }

            @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int screenHeight = getResources().getDisplayMetrics().heightPixels;
                int maxHeight = Math.max(dp(240), Math.min(dp(580), screenHeight - dp(32)));
                int limitedHeightSpec = View.MeasureSpec.makeMeasureSpec(
                        maxHeight, View.MeasureSpec.AT_MOST);
                super.onMeasure(widthMeasureSpec, limitedHeightSpec);
            }
        };
        panel.setFillViewport(false);
        panel.setVerticalScrollBarEnabled(true);
        panel.setBackground(background);
        panel.setElevation(dp(12));
        panel.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                cancelPanelAutoClose();
            } else if (event.getAction() == MotionEvent.ACTION_UP
                    || event.getAction() == MotionEvent.ACTION_CANCEL) {
                schedulePanelAutoClose();
            }
            return false;
        });
        panelContent = new LinearLayout(this);
        panelContent.setOrientation(LinearLayout.VERTICAL);
        panelContent.setPadding(dp(12), dp(12), dp(12), dp(12));
        panel.addView(panelContent, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        // Fallback close control remains in the header; normally quick controls dismiss automatically.
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("SMART TOOLBOX");
        title.setTextColor(Color.rgb(255, 194, 71));
        title.setTextSize(14);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        TextView close = new TextView(this);
        close.setText("×");
        close.setTextColor(Color.WHITE);
        close.setTextSize(24);
        close.setGravity(Gravity.CENTER);
        close.setContentDescription("Close quick controls");
        close.setBackground(makePanelActionBackground());
        LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(dp(36), dp(34));
        titleRow.addView(close, closeParams);
        close.setOnClickListener(v -> {
            removePanel();
            scheduleAutoHide();
        });
        panelContent.addView(titleRow);

        TextView hint = new TextView(this);
        hint.setText("প্রতিটি ফিচারের সব কন্ট্রোল তার নিজের অংশে");
        hint.setTextColor(Color.LTGRAY);
        hint.setTextSize(11);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(3);
        panelContent.addView(hint, hintParams);

        android.content.SharedPreferences toolPrefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean night = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        boolean thermal = toolPrefs.getBoolean("thermal.active", false);
        boolean masterOn = toolPrefs.getBoolean("audio.master.enabled",
                toolPrefs.getBoolean("audio.active", false));
        boolean scanner = toolPrefs.getBoolean("scanner.active", false);

        // 1) Night Screen: toggle and both adjustable levels stay in this single card.
        LinearLayout nightCard = createFeatureCard();
        addPanelFeatureHeaderTo(nightCard, "🌙  Night Screen", night, this::toggleNight);

        int nightLevel = Math.max(0, Math.min(95,
                getSharedPreferences("night", MODE_PRIVATE).getInt("level", 60)));
        addPanelSliderTo(
                nightCard,
                "Darkness",
                nightLevel,
                95,
                value -> value + "%  ·  " + (value >= 85 ? "Extra dark" : (value == 0 ? "Bright" : "Dim")),
                new PanelSliderListener() {
                    @Override public void onChange(int value) { scheduleNightLevelUpdate(value); }
                    @Override public void onRelease(int value) { flushNightLevelUpdate(value); }
                });

        addFeatureCardToPanel(nightCard);

        // 2) Thermal Monitor: ON/OFF and the live temperature appear together in one card.
        LinearLayout thermalCard = createFeatureCard();
        addPanelFeatureHeaderTo(thermalCard, "🌡️  Thermal Monitor", thermal, this::toggleThermal);

        thermalReadout = new TextView(this);
        thermalReadout.setTextColor(Color.rgb(210, 220, 232));
        thermalReadout.setTextSize(12);
        thermalReadout.setPadding(dp(2), dp(8), dp(2), dp(2));
        thermalCard.addView(thermalReadout, new LinearLayout.LayoutParams(-1, -2));
        updateThermalReadout();
        addFeatureCardToPanel(thermalCard);

        // 3) Master Volume: ON/OFF and gain adjustment appear together in one card.
        LinearLayout masterCard = createFeatureCard();
        addPanelFeatureHeaderTo(masterCard, "🔊  Master Volume Boost", masterOn, this::toggleAudio);

        int audioGain = Math.max(0, Math.min(1000,
                toolPrefs.getInt("audio.gain", 400)));
        addPanelSliderTo(
                masterCard,
                "Boost level",
                audioGain,
                1000,
                value -> String.format(java.util.Locale.getDefault(), "+%.1f dB", value / 100f),
                new PanelSliderListener() {
                    @Override public void onChange(int value) { scheduleAudioGainUpdate(value); }
                    @Override public void onRelease(int value) { flushAudioGainUpdate(value); }
                });
        addNativeMediaVolumeControls(masterCard);
        addFeatureCardToPanel(masterCard);

        // 4) QR / Barcode Scanner remains the fourth feature card.
        LinearLayout scannerCard = createFeatureCard();
        addPanelActionTo(scannerCard,
                "▦  QR / Barcode Scanner  ·  " + (scanner ? "CLOSE" : "OPEN"),
                this::toggleScanner);
        addFeatureCardToPanel(scannerCard);

        // Video Player is an on-demand activity; it does not need a persistent toggle state.
        LinearLayout videoCard = createFeatureCard();
        addPanelActionTo(videoCard, "🎬  SR Video Player  ·  OPEN", this::openVideoPlayer);
        addFeatureCardToPanel(videoCard);

        // No separate bottom settings / hide / cancel actions are rendered.
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int panelWidth = Math.min(dp(292), Math.max(dp(240), metrics.widthPixels - dp(12)));
        int maxPanelHeight = Math.min(dp(580), metrics.heightPixels - dp(32));
        panelParams = new WindowManager.LayoutParams(
                panelWidth, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        int maxY = Math.max(dp(8), metrics.heightPixels - maxPanelHeight - dp(8));
        panelParams.x = Math.max(dp(6), Math.min(metrics.widthPixels - panelWidth - dp(6),
                bubbleParams.x - panelWidth + bubbleParams.width));
        panelParams.y = Math.max(dp(8), Math.min(maxY, bubbleParams.y));
        try {
            windowManager.addView(panel, panelParams);
            scheduleThermalReadout();
            schedulePanelAutoClose();
        } catch (Exception e) {
            panel = null;
            panelContent = null;
            panelParams = null;
            thermalReadout = null;
        }
    }

    private LinearLayout createFeatureCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable cardBackground = new GradientDrawable();
        cardBackground.setColor(Color.rgb(27, 35, 46));
        cardBackground.setCornerRadius(dp(13));
        cardBackground.setStroke(dp(1), Color.rgb(58, 70, 85));
        card.setBackground(cardBackground);
        return card;
    }

    private void addFeatureCardToPanel(LinearLayout card) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(9);
        panelContent.addView(card, params);
    }

    private GradientDrawable makePanelActionBackground() {
        GradientDrawable itemBg = new GradientDrawable();
        itemBg.setColor(Color.rgb(39, 48, 60));
        itemBg.setCornerRadius(dp(10));
        return itemBg;
    }

    private GradientDrawable makeToggleBackground(boolean enabled) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(enabled ? Color.rgb(35, 112, 82) : Color.rgb(57, 68, 82));
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), enabled ? Color.rgb(74, 178, 128) : Color.rgb(91, 105, 122));
        return bg;
    }

    private void addPanelFeatureHeaderTo(LinearLayout target, String label,
                                         boolean enabled, Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = new TextView(this);
        name.setText(label);
        name.setTextColor(Color.WHITE);
        name.setTextSize(14);
        name.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        name.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(0, dp(42), 1);
        row.addView(name, nameParams);

        TextView toggle = new TextView(this);
        toggle.setText(enabled ? "ON" : "OFF");
        toggle.setTextColor(Color.WHITE);
        toggle.setTextSize(12);
        toggle.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        toggle.setGravity(Gravity.CENTER);
        toggle.setMinWidth(dp(58));
        toggle.setPadding(dp(12), dp(7), dp(12), dp(7));
        toggle.setBackground(makeToggleBackground(enabled));
        toggle.setContentDescription(label + " ON/OFF");
        row.addView(toggle, new LinearLayout.LayoutParams(-2, dp(36)));
        toggle.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) cancelPanelAutoClose();
            return false;
        });
        toggle.setOnClickListener(v -> {
            action.run();
            schedulePanelAutoClose();
        });

        target.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addPanelActionTo(LinearLayout target, String label, Runnable action) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextColor(Color.rgb(235, 220, 170));
        item.setTextSize(11);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(2), dp(7), dp(2), dp(2));
        item.setBackground(makePanelActionBackground());
        item.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) cancelPanelAutoClose();
            return false;
        });
        item.setOnClickListener(v -> {
            action.run();
            schedulePanelAutoClose();
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(5);
        target.addView(item, params);
    }

    private void addPanelSliderTo(LinearLayout target, String title, int initialValue, int maxValue,
                                  PanelSliderFormatter formatter, PanelSliderListener listener) {
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.VERTICAL);
        group.setPadding(dp(2), dp(5), dp(2), dp(2));

        TextView label = new TextView(this);
        label.setText(title + "  ·  " + formatter.format(initialValue));
        label.setTextColor(Color.WHITE);
        label.setTextSize(12);
        label.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        group.addView(label, new LinearLayout.LayoutParams(-1, -2));

        SeekBar seek = new SeekBar(this);
        seek.setMax(maxValue);
        seek.setProgress(Math.max(0, Math.min(maxValue, initialValue)));
        seek.setContentDescription(title);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(-1, -2);
        seekParams.topMargin = dp(1);
        group.addView(seek, seekParams);

        LinearLayout.LayoutParams groupParams = new LinearLayout.LayoutParams(-1, -2);
        groupParams.topMargin = dp(3);
        target.addView(group, groupParams);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                label.setText(title + "  ·  " + formatter.format(progress));
                if (fromUser) listener.onChange(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                cancelPanelAutoClose();
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                listener.onRelease(seekBar.getProgress());
                schedulePanelAutoClose();
            }
        });
    }

    // The quick-panel slider uses these local callback contracts.
    // They must remain declared because addPanelSliderTo() and all three
    // anonymous slider listeners reference them by name.
    private void addNativeMediaVolumeControls(LinearLayout card) {
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
        rowParams.topMargin = dp(7);

        TextView level = new TextView(this);
        level.setTextColor(Color.LTGRAY);
        level.setTextSize(12);
        level.setText(getNativeVolumeText(audio));
        row.addView(level, new LinearLayout.LayoutParams(0, dp(44), 1));
        level.setGravity(Gravity.CENTER_VERTICAL);

        TextView minus = makeNativeVolumeButton("−", "Decrease phone media volume");
        TextView plus = makeNativeVolumeButton("+", "Increase phone media volume");
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(dp(46), dp(40));
        buttonParams.rightMargin = dp(6);
        row.addView(minus, buttonParams);
        row.addView(plus, new LinearLayout.LayoutParams(dp(46), dp(40)));
        minus.setOnClickListener(v -> adjustNativeMediaVolume(audio, AudioManager.ADJUST_LOWER, level));
        plus.setOnClickListener(v -> adjustNativeMediaVolume(audio, AudioManager.ADJUST_RAISE, level));
        card.addView(row, rowParams);
    }

    private TextView makeNativeVolumeButton(String symbol, String description) {
        TextView button = new TextView(this);
        button.setText(symbol);
        button.setTextSize(22);
        button.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setBackground(makePanelActionBackground());
        button.setContentDescription(description);
        button.setOnTouchListener((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) cancelPanelAutoClose();
            return false;
        });
        return button;
    }

    private String getNativeVolumeText(AudioManager audio) {
        if (audio == null) return "Phone media volume unavailable";
        return "Phone media " + audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                + "/" + audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
    }

    private void adjustNativeMediaVolume(AudioManager audio, int direction, TextView level) {
        if (audio == null) {
            level.setText("Phone media volume unavailable");
        } else if (audio.isVolumeFixed()) {
            level.setText("This phone has fixed media volume");
        } else {
            try {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0);
                level.setText(getNativeVolumeText(audio));
            } catch (SecurityException | IllegalArgumentException error) {
                level.setText("Media volume cannot be changed here");
            }
        }
        schedulePanelAutoClose();
    }

    private interface PanelSliderFormatter {
        String format(int value);
    }

    private interface PanelSliderListener {
        void onChange(int value);
        void onRelease(int value);
    }

    private void scheduleNightLevelUpdate(int level) {
        getSharedPreferences("night", MODE_PRIVATE).edit().putInt("level", level).apply();
        if (!getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false)) return;
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        pendingNightUpdate = () -> {
            pendingNightUpdate = null;
            applyNightLevel(level);
        };
        sliderHandler.postDelayed(pendingNightUpdate, 120);
    }

    private void flushNightLevelUpdate(int level) {
        getSharedPreferences("night", MODE_PRIVATE).edit().putInt("level", level).apply();
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        pendingNightUpdate = null;
        if (getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false)) {
            applyNightLevel(level);
        }
    }

    private void applyNightLevel(int level) {
        android.content.SharedPreferences prefs = getSharedPreferences("night", MODE_PRIVATE);
        Intent update = new Intent(this, DimOverlayService.class);
        update.putExtra("level", Math.max(0, Math.min(95, level)));
        update.putExtra("warm", prefs.getBoolean("warm", false));
        ContextCompat.startForegroundService(this, update);
    }

    private void scheduleAudioGainUpdate(int gain) {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putInt("audio.gain", gain).apply();
        if (!getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.master.enabled", false)) return;
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        pendingAudioUpdate = () -> {
            pendingAudioUpdate = null;
            applyAudioGain(gain);
        };
        sliderHandler.postDelayed(pendingAudioUpdate, 120);
    }

    private void flushAudioGainUpdate(int gain) {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putInt("audio.gain", gain).apply();
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        pendingAudioUpdate = null;
        if (getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.master.enabled", false)) {
            applyAudioGain(gain);
        }
    }

    private void applyAudioGain(int gain) {
        Intent update = new Intent(this, SystemAudioBoostService.class);
        update.setAction(SystemAudioBoostService.ACTION_UPDATE);
        update.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB, Math.max(0, Math.min(1000, gain)));
        ContextCompat.startForegroundService(this, update);
    }

    private void updateThermalReadout() {
        if (thermalReadout == null) return;
        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.getBoolean("thermal.active", false)) {
            thermalReadout.setText("Temperature: Monitoring is OFF · Turn on Thermal Monitor to view it here.");
        } else {
            String battery = prefs.getString("thermal.battery", "Battery temperature unavailable");
            String status = prefs.getString("thermal.status", "Thermal status unavailable");
            thermalReadout.setText("LIVE TEMPERATURE  ·  " + battery + "  ·  " + status);
        }
    }

    private void scheduleThermalReadout() {
        if (thermalReadoutRunnable != null) {
            sliderHandler.removeCallbacks(thermalReadoutRunnable);
        }
        thermalReadoutRunnable = () -> {
            if (thermalReadout == null || panel == null) return;
            updateThermalReadout();
            sliderHandler.postDelayed(thermalReadoutRunnable, 1500L);
        };
        sliderHandler.postDelayed(thermalReadoutRunnable, 1500L);
    }

    private void toggleNight() {
        android.content.SharedPreferences prefs = getSharedPreferences("night", MODE_PRIVATE);
        boolean active = prefs.getBoolean("active", false);
        Intent intent = new Intent(this, DimOverlayService.class);
        if (active) {
            intent.setAction(DimOverlayService.ACTION_STOP);
            startService(intent);
            prefs.edit().putBoolean("active", false).apply();
        } else {
            int level = prefs.getInt("level", 60);
            boolean warm = prefs.getBoolean("warm", false);
            intent.putExtra("level", level);
            intent.putExtra("warm", warm);
            prefs.edit().putBoolean("active", true).apply();
            ContextCompat.startForegroundService(this, intent);
            FloatingControlService.start(this);
        }
        showPanel();
    }

    private void toggleThermal() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("thermal.active", false);
        Intent intent = new Intent(this, ThermalMonitorService.class);
        if (active) {
            intent.setAction(ThermalMonitorService.ACTION_STOP);
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("thermal.active", false).apply();
            startService(intent);
        } else {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("thermal.active", true).apply();
            ContextCompat.startForegroundService(this, intent);
        }
        showPanel();
    }

    private void toggleAudio() {
        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean masterOn = prefs.getBoolean("audio.master.enabled",
                prefs.getBoolean("audio.active", false));
        Intent control = new Intent(this, SystemAudioBoostService.class);
        if (masterOn) {
            prefs.edit().putBoolean("audio.master.enabled", false).apply();
            control.setAction(SystemAudioBoostService.ACTION_MASTER_OFF);
            startService(control);
        } else {
            prefs.edit().putBoolean("audio.master.enabled", true).apply();
            control.setAction(SystemAudioBoostService.ACTION_MASTER_ON);
            control.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB,
                    prefs.getInt("audio.gain", 400));
            ContextCompat.startForegroundService(this, control);
        }
        showPanel();
    }

    private void toggleScanner() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("scanner.active", false);
        if (active) {
            Intent close = new Intent(this, MainActivity.class);
            close.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(close);
        } else {
            Intent open = new Intent(this, BarcodeScannerActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(open);
        }
        removePanel();
        scheduleAutoHide();
    }

    private void openVideoPlayer() {
        removePanel();
        scheduleAutoHide();
        Intent open = new Intent(this, VideoLibraryActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(open);
    }

    private void openFloatingSettings() {
        removePanel();
        scheduleAutoHide();
        Intent open = new Intent(this, FloatingIconSettingsActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(open);
    }

    private void hideBubble() {
        cancelAutoHide();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.hidden", true)
                .putBoolean("floating.enabled", false)
                .putBoolean("floating.auto_hidden", false).apply();
        removePanelAndBubble();
        stopForeground(true);
        stopSelf();
    }

    private void removePanel() {
        cancelPanelAutoClose();
        if (thermalReadoutRunnable != null) {
            sliderHandler.removeCallbacks(thermalReadoutRunnable);
            thermalReadoutRunnable = null;
        }
        thermalReadout = null;
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
            panelContent = null;
            panelParams = null;
        }
    }

    private void removePanelAndBubble() {
        cancelAutoHide();
        removePanel();
        removeEdgeHandle();
        autoHidden = false;
        if (bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
            bubbleParams = null;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Floating controls", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the user-enabled SR Smart Toolbox floating sidebar available, even when no tool is active.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("SR Smart Toolbox floating control")
                .setContentText("Tap the edge tab or ST bubble for quick controls.")
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        if (thermalReadoutRunnable != null) sliderHandler.removeCallbacks(thermalReadoutRunnable);
        cancelAutoHide();
        cancelPanelAutoClose();
        removePanelAndBubble();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
