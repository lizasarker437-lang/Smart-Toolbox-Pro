package com.smarttoolbox.pro;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Phone video library. MediaStore indexes local, shared-storage videos with user consent. */
public class VideoLibraryActivity extends Activity {
    private static final int REQUEST_VIDEO_ACCESS = 5071;
    private final ExecutorService loader = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<VideoRow> allVideos = new ArrayList<>();
    private final List<VideoRow> visibleVideos = new ArrayList<>();
    private final ArrayList<String> folders = new ArrayList<>();
    private VideoAdapter adapter;
    private TextView status;
    private EditText search;
    private Spinner folderSpinner;
    private Spinner sortSpinner;
    private int loadNumber;
    private boolean firstResume = true;
    private boolean destroyed;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        buildUi();
        if (hasVideoPermission()) reloadVideos();
        else askForVideoAccess();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(dp(14), dp(8), dp(14), dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = label("‹", 34, Ui.TEXT, true);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(44), dp(52)));
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(label("SR VIDEO LIBRARY", 21, Ui.ACCENT, true));
        heading.addView(label("Your phone's videos • Resume where you stopped", 12, Ui.MUTED, false));
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.Button refresh = Ui.button(this, "↻ Refresh", this::reloadOrRequest);
        actions.addView(refresh, new LinearLayout.LayoutParams(0, dp(46), 1));
        android.widget.Button permissions = Ui.button(this, "Video Access", this::askForVideoAccess);
        LinearLayout.LayoutParams permParams = new LinearLayout.LayoutParams(0, dp(46), 1);
        permParams.leftMargin = dp(8);
        actions.addView(permissions, permParams);
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(-1, -2);
        actionParams.topMargin = dp(10);
        root.addView(actions, actionParams);

        android.widget.Button manual = Ui.button(this, "📂 Select files manually", () -> {
            Intent intent = new Intent(this, VideoPlayerActivity.class);
            intent.putExtra(VideoPlayerActivity.EXTRA_OPEN_PICKER, true);
            startActivity(intent);
        });
        LinearLayout.LayoutParams manualParams = new LinearLayout.LayoutParams(-1, dp(44));
        manualParams.topMargin = dp(8);
        root.addView(manual, manualParams);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(Ui.TEXT);
        search.setHintTextColor(Ui.MUTED);
        search.setHint("🔍 Search videos by name or folder");
        search.setPadding(dp(14), dp(8), dp(14), dp(8));
        search.setBackground(background(Ui.CARD));
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(50));
        searchParams.topMargin = dp(12);
        root.addView(search, searchParams);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) { applyFilters(); }
            @Override public void afterTextChanged(Editable value) {}
        });

        LinearLayout selectors = new LinearLayout(this);
        selectors.setOrientation(LinearLayout.HORIZONTAL);
        folderSpinner = new Spinner(this);
        sortSpinner = new Spinner(this);
        folders.add("All folders");
        updateFolders();
        sortSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Newest", "Name A–Z", "Longest"}));
        selectors.addView(folderSpinner, new LinearLayout.LayoutParams(0, dp(48), 1.25f));
        selectors.addView(sortSpinner, new LinearLayout.LayoutParams(0, dp(48), 0.9f));
        LinearLayout.LayoutParams selectorsParams = new LinearLayout.LayoutParams(-1, -2);
        selectorsParams.topMargin = dp(8);
        root.addView(selectors, selectorsParams);
        AdapterView.OnItemSelectedListener selection = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { applyFilters(); }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        };
        folderSpinner.setOnItemSelectedListener(selection);
        sortSpinner.setOnItemSelectedListener(selection);

        status = label("Checking video access…", 13, Ui.MUTED, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(9);
        root.addView(status, statusParams);

        ListView list = new ListView(this);
        list.setDividerHeight(dp(8));
        list.setDivider(null);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setBackgroundColor(Color.TRANSPARENT);
        list.setVerticalScrollBarEnabled(true);
        adapter = new VideoAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> openVideo(visibleVideos.get(position), false));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            VideoRow video = visibleVideos.get(position);
            new AlertDialog.Builder(this)
                    .setTitle(video.title)
                    .setItems(new String[]{"Continue playback", "Start from beginning"},
                            (dialog, which) -> openVideo(video, which == 1))
                    .show();
            return true;
        });
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(-1, 0, 1);
        listParams.topMargin = dp(8);
        root.addView(list, listParams);

        TextView foot = label("Tap: continue  •  Long press: restart from beginning", 12, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        root.addView(foot, new LinearLayout.LayoutParams(-1, dp(32)));
        setContentView(root);
    }

    private void openVideo(VideoRow video, boolean restart) {
        Intent intent = new Intent(this, VideoPlayerActivity.class);
        intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_URI, video.uri.toString());
        intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_TITLE, video.title);
        intent.putExtra(VideoPlayerActivity.EXTRA_RESTART_VIDEO, restart);
        startActivity(intent);
    }

    private void reloadOrRequest() {
        if (hasVideoPermission()) reloadVideos();
        else askForVideoAccess();
    }

    private boolean hasFullAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasPartialAccess() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
                        == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasVideoPermission() { return hasFullAccess() || hasPartialAccess(); }

    private void askForVideoAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}, REQUEST_VIDEO_ACCESS);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO}, REQUEST_VIDEO_ACCESS);
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_VIDEO_ACCESS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode != REQUEST_VIDEO_ACCESS) return;
        if (hasVideoPermission()) reloadVideos();
        else {
            allVideos.clear();
            visibleVideos.clear();
            adapter.notifyDataSetChanged();
            status.setText("To show your phone's videos, allow video access. You can still use the system file picker.");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // Only requery after returning from another screen, not immediately after onCreate.
        if (firstResume) {
            firstResume = false;
            return;
        }
        if (hasVideoPermission()) reloadVideos();
        else if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void reloadVideos() {
        if (!hasVideoPermission()) return;
        final int generation = ++loadNumber;
        status.setText("Scanning videos on your phone…");
        loader.execute(() -> {
            List<VideoRow> found = new ArrayList<>();
            String error = null;
            try {
                Uri collection = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                        : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                String folderColumn = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        ? MediaStore.MediaColumns.RELATIVE_PATH : MediaStore.Video.Media.DATA;
                String[] columns = {MediaStore.Video.Media._ID,
                        MediaStore.Video.Media.DISPLAY_NAME,
                        MediaStore.Video.Media.DURATION,
                        MediaStore.Video.Media.DATE_ADDED,
                        folderColumn};
                try (Cursor cursor = getContentResolver().query(collection, columns, null, null,
                        MediaStore.Video.Media.DATE_ADDED + " DESC")) {
                    if (cursor != null) {
                        int idIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
                        int nameIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
                        int durationIndex = cursor.getColumnIndex(MediaStore.Video.Media.DURATION);
                        int dateIndex = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED);
                        int folderIndex = cursor.getColumnIndex(folderColumn);
                        while (cursor.moveToNext()) {
                            long id = cursor.getLong(idIndex);
                            String title = cursor.getString(nameIndex);
                            long duration = durationIndex < 0 ? 0L : cursor.getLong(durationIndex);
                            long dateAdded = dateIndex < 0 ? 0L : cursor.getLong(dateIndex);
                            String path = folderIndex < 0 ? null : cursor.getString(folderIndex);
                            String folder = path == null || path.trim().isEmpty() ? "Other videos" : path;
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                int slash = folder.lastIndexOf('/');
                                folder = slash > 0 ? folder.substring(0, slash) : "Other videos";
                            }
                            found.add(new VideoRow(ContentUris.withAppendedId(collection, id),
                                    title == null || title.trim().isEmpty() ? "Untitled video" : title,
                                    folder, Math.max(0L, duration), dateAdded));
                        }
                    }
                }
            } catch (SecurityException permission) {
                error = "Video permission changed. Tap Video Access to allow it again.";
            } catch (RuntimeException readError) {
                error = "Could not read the phone's video index. Try Refresh or select files manually.";
            }
            final String message = error;
            main.post(() -> {
                if (destroyed || generation != loadNumber) return;
                allVideos.clear();
                allVideos.addAll(found);
                updateFolders();
                applyFilters();
                if (message != null) status.setText(message);
            });
        });
    }

    private void updateFolders() {
        if (folderSpinner == null) return;
        String selected = folderSpinner.getSelectedItem() == null ? "All folders" : folderSpinner.getSelectedItem().toString();
        TreeSet<String> paths = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (VideoRow row : allVideos) paths.add(row.folder);
        folders.clear();
        folders.add("All folders");
        folders.addAll(paths);
        folderSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, new ArrayList<>(folders)));
        int index = folders.indexOf(selected);
        folderSpinner.setSelection(Math.max(0, index));
    }

    private void applyFilters() {
        if (adapter == null || folderSpinner == null || sortSpinner == null || status == null) return;
        String keyword = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        String folder = folderSpinner.getSelectedItem() == null ? "All folders" : folderSpinner.getSelectedItem().toString();
        visibleVideos.clear();
        for (VideoRow row : allVideos) {
            if (!folder.equals("All folders") && !folder.equals(row.folder)) continue;
            if (!keyword.isEmpty() && !row.title.toLowerCase(Locale.ROOT).contains(keyword)
                    && !row.folder.toLowerCase(Locale.ROOT).contains(keyword)) continue;
            visibleVideos.add(row);
        }
        int sorting = sortSpinner.getSelectedItemPosition();
        if (sorting == 1) Collections.sort(visibleVideos, Comparator.comparing(row -> row.title.toLowerCase(Locale.ROOT)));
        else if (sorting == 2) Collections.sort(visibleVideos, (a, b) -> Long.compare(b.duration, a.duration));
        else Collections.sort(visibleVideos, (a, b) -> Long.compare(b.dateAdded, a.dateAdded));
        adapter.notifyDataSetChanged();
        String restriction = hasFullAccess() ? "" : hasPartialAccess() ? " • Selected videos only (grant full access to see all)" : " • Permission needed";
        status.setText(visibleVideos.size() + " videos shown • " + allVideos.size() + " indexed" + restriction);
    }

    private TextView label(String text, int textSize, int color, boolean bold) {
        return Ui.text(this, text, textSize, color, bold);
    }
    private int dp(float v) { return Ui.dp(this, v); }
    private GradientDrawable background(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(14));
        return bg;
    }
    private String time(long ms) {
        long seconds = Math.max(0, ms) / 1000;
        long hours = seconds / 3600, minutes = (seconds % 3600) / 60;
        return hours > 0 ? String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds % 60)
                : String.format(Locale.US, "%02d:%02d", minutes, seconds % 60);
    }

    private final class VideoAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleVideos.size(); }
        @Override public VideoRow getItem(int position) { return visibleVideos.get(position); }
        @Override public long getItemId(int position) { return getItem(position).uri.hashCode(); }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            RowHolder holder;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(VideoLibraryActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                row.setBackground(background(Ui.CARD));
                TextView icon = label("▶", 23, Ui.ACCENT, true);
                icon.setGravity(Gravity.CENTER);
                row.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(70)));
                LinearLayout details = new LinearLayout(VideoLibraryActivity.this);
                details.setOrientation(LinearLayout.VERTICAL);
                TextView title = label("", 15, Ui.TEXT, true);
                title.setMaxLines(2);
                TextView detail = label("", 12, Ui.MUTED, false);
                TextView resume = label("", 12, Ui.ACCENT, true);
                details.addView(title);
                details.addView(detail);
                details.addView(resume);
                LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, -2, 1);
                textParams.leftMargin = dp(7);
                row.addView(details, textParams);
                holder = new RowHolder(title, detail, resume);
                row.setTag(holder);
                convertView = row;
            } else holder = (RowHolder) convertView.getTag();
            VideoRow video = getItem(position);
            holder.title.setText(video.title);
            holder.detail.setText(video.folder + "  •  " + time(video.duration));
            long saved = VideoResumeStore.get(VideoLibraryActivity.this, video.uri.toString());
            holder.resume.setText(VideoResumeLogic.shouldResume(saved, video.duration)
                    ? "▶ Continue from " + time(saved) : "▶ Play video");
            return convertView;
        }
    }

    private static final class RowHolder {
        final TextView title, detail, resume;
        RowHolder(TextView title, TextView detail, TextView resume) {
            this.title = title; this.detail = detail; this.resume = resume;
        }
    }

    private static final class VideoRow {
        final Uri uri;
        final String title, folder;
        final long duration, dateAdded;
        VideoRow(Uri uri, String title, String folder, long duration, long dateAdded) {
            this.uri = uri; this.title = title; this.folder = folder;
            this.duration = duration; this.dateAdded = dateAdded;
        }
    }

    @Override protected void onDestroy() {
        destroyed = true;
        ++loadNumber;
        loader.shutdownNow();
        super.onDestroy();
    }
}
