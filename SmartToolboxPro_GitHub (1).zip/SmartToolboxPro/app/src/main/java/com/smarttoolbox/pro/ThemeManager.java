package com.smarttoolbox.pro;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.view.View;

/** Saved, application-wide Ui palette. Standard screens use these colors on recreation. */
final class ThemeManager {
    private static final String PREFS = "sr_theme_preferences";
    private static final String KEY = "chosen_theme";
    private ThemeManager() {}
    static int current(Context context) {
        return ThemePalette.safeIndex(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, 0));
    }
    static void initialize(Context context) { Ui.applyColors(ThemePalette.colors(current(context))); }
    static void save(Context context, int index) {
        int valid = ThemePalette.safeIndex(index);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY, valid).apply();
        Ui.applyColors(ThemePalette.colors(valid));
    }
    static void applyToActivity(Activity activity) {
        initialize(activity);
        activity.setTheme(ThemePalette.isLight(current(activity))
                ? R.style.AppThemeLight : R.style.AppTheme);
        // Light theme needs dark status-bar icons; dark themes use white icons.
        int flags = activity.getWindow().getDecorView().getSystemUiVisibility();
        flags = ThemePalette.isLight(current(activity))
                ? flags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                : flags & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        activity.getWindow().getDecorView().setSystemUiVisibility(flags);
    }
}
