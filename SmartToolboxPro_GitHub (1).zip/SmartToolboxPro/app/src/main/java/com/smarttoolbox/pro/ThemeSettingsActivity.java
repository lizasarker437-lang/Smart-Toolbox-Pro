package com.smarttoolbox.pro;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Five persistent presets; current app activities use this palette when recreated. */
public final class ThemeSettingsActivity extends Activity {
    private static final String[] DESCRIPTIONS = {
            "Original SR black & gold", "Cool navy with sky-blue highlights",
            "Forest green with mint accents", "Deep violet and lavender",
            "White background with ocean-blue buttons"
    };

    @Override public void onCreate(Bundle state) {
        ThemeManager.applyToActivity(this);
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        LinearLayout page = Ui.page(this, "🎨 Theme Settings");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body, "Choose your SR style", 21, Ui.TEXT, true, 4);
        Ui.addText(this, body,
                "Select a color theme. It is saved automatically and applied to the app screens. "
                        + "The video player's full-screen cinema background stays black for comfortable viewing.",
                13, Ui.MUTED, false, 7);
        int current = ThemeManager.current(this);
        for (int i = 0; i < ThemePalette.NAMES.length; i++) {
            final int selection = i;
            int[] colors = ThemePalette.colors(i);
            LinearLayout card = Ui.card(this);
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);

            TextView sample = Ui.text(this, "SR", 17, colors[3], true);
            sample.setGravity(Gravity.CENTER);
            GradientDrawable sampleBg = new GradientDrawable();
            sampleBg.setColor(colors[0]);
            sampleBg.setCornerRadius(Ui.dp(this, 13));
            sampleBg.setStroke(Ui.dp(this, 2), colors[5]);
            sample.setBackground(sampleBg);
            top.addView(sample, new LinearLayout.LayoutParams(Ui.dp(this, 58), Ui.dp(this, 58)));

            LinearLayout textStack = new LinearLayout(this);
            textStack.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, -2, 1);
            infoParams.leftMargin = Ui.dp(this, 12);
            top.addView(textStack, infoParams);
            textStack.addView(Ui.text(this, ThemePalette.name(i), 17, Ui.TEXT, true));
            TextView subtitle = Ui.text(this, DESCRIPTIONS[i], 12, Ui.MUTED, false);
            textStack.addView(subtitle);

            TextView chosen = Ui.text(this, i == current ? "✓ Selected" : "Choose", 12,
                    i == current ? Ui.GREEN : Ui.ACCENT, true);
            chosen.setGravity(Gravity.CENTER);
            top.addView(chosen, new LinearLayout.LayoutParams(-2, -2));
            card.addView(top);
            LinearLayout swatches = new LinearLayout(this);
            swatches.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams swatchGroup = new LinearLayout.LayoutParams(-1, Ui.dp(this, 13));
            swatchGroup.topMargin = Ui.dp(this, 10);
            card.addView(swatches, swatchGroup);
            for (int color : new int[]{colors[0], colors[1], colors[3], colors[5]}) {
                View box = new View(this);
                box.setBackgroundColor(color);
                LinearLayout.LayoutParams boxParams = new LinearLayout.LayoutParams(0, Ui.dp(this, 13), 1);
                boxParams.rightMargin = Ui.dp(this, 5);
                swatches.addView(box, boxParams);
            }
            card.setOnClickListener(v -> {
                if (ThemeManager.current(this) == selection) return;
                ThemeManager.save(this, selection);
                recreate();
            });
            Ui.addCard(this, body, card, 13);
        }
        Ui.addText(this, body, "Changes are saved on this device. You can switch themes at any time from ⋮.",
                12, Ui.MUTED, false, 18);
        setContentView(page);
    }
}
