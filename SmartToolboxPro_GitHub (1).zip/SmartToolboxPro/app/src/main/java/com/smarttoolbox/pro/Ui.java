package com.smarttoolbox.pro;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class Ui {
    static int BG = Color.rgb(9, 13, 18);
    static int CARD = Color.rgb(23, 29, 37);
    static int CARD_2 = Color.rgb(31, 38, 48);
    static int TEXT = Color.rgb(245, 247, 250);
    static int MUTED = Color.rgb(157, 168, 181);
    static int ACCENT = Color.rgb(255, 194, 71);
    static int GREEN = Color.rgb(90, 210, 145);

    private Ui() {}

    static void applyColors(int[] colors) {
        BG = colors[0]; CARD = colors[1]; CARD_2 = colors[2];
        TEXT = colors[3]; MUTED = colors[4]; ACCENT = colors[5]; GREEN = colors[6];
    }


    static int dp(Activity a, float value) {
        return (int) (value * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    static LinearLayout page(Activity a, String title) {
        LinearLayout outer = new LinearLayout(a);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(BG);
        outer.setPadding(dp(a, 18), dp(a, 14), dp(a, 18), dp(a, 22));

        LinearLayout header = new LinearLayout(a);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text(a, "‹", 34, TEXT, false);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> a.finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 52)));
        TextView heading = text(a, title, 22, TEXT, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, -2, 1);
        hp.leftMargin = dp(a, 8);
        header.addView(heading, hp);
        outer.addView(header);

        ScrollView scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(a);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(a, 12), 0, dp(a, 12));
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        outer.setTag(content);
        return outer;
    }

    static LinearLayout content(LinearLayout page) {
        return (LinearLayout) page.getTag();
    }

    static TextView text(Activity a, String value, int size, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setIncludeFontPadding(true);
        return t;
    }

    static TextView addText(Activity a, LinearLayout parent, String value, int size, int color, boolean bold, int top) {
        TextView t = text(a, value, size, color, bold);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(a, top);
        parent.addView(t, p);
        return t;
    }

    static Button button(Activity a, String label, Runnable action) {
        Button b = new Button(a);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(ThemePalette.isLight(ThemeManager.current(a)) ? Color.WHITE : Color.rgb(18, 23, 30));
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ACCENT);
        bg.setCornerRadius(dp(a, 16));
        b.setBackground(bg);
        b.setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    static LinearLayout card(Activity a) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 16), dp(a, 16), dp(a, 16), dp(a, 16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(a, 20));
        bg.setStroke(dp(a, 1), CARD_2);
        box.setBackground(bg);
        return box;
    }

    static void addCard(Activity a, LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(a, top);
        parent.addView(child, p);
    }
}
