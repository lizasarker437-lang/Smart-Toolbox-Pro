package com.smarttoolbox.pro;

/** Pure Java color presets so theme selection is easy to verify without Android SDK. */
final class ThemePalette {
    static final String[] NAMES = {"Midnight Gold", "Ocean Blue", "Emerald Green", "Royal Purple", "Light Day"};
    static final int[][] COLORS = {
        {0xFF090D12, 0xFF171D25, 0xFF1F2630, 0xFFF5F7FA, 0xFF9DA8B5, 0xFFFFC247, 0xFF5AD291},
        {0xFF071827, 0xFF13283C, 0xFF1B354D, 0xFFF3FAFF, 0xFFA6BDCF, 0xFF48B8FF, 0xFF51D5BF},
        {0xFF071811, 0xFF11271E, 0xFF1B352A, 0xFFF2FFF8, 0xFFA0BFAE, 0xFF65E2A2, 0xFF65E2A2},
        {0xFF140C26, 0xFF241A37, 0xFF34284C, 0xFFF9F5FF, 0xFFB7A7D1, 0xFFC19BFF, 0xFF84E0D0},
        {0xFFF7FAFE, 0xFFFFFFFF, 0xFFEAF1FA, 0xFF202B3A, 0xFF657489, 0xFF1769D2, 0xFF117D66}
    };
    private ThemePalette() {}
    static int safeIndex(int id) { return id >= 0 && id < NAMES.length ? id : 0; }
    static String name(int id) { return NAMES[safeIndex(id)]; }
    static int[] colors(int id) { return COLORS[safeIndex(id)].clone(); }
    static boolean isLight(int id) { return safeIndex(id) == 4; }
}
