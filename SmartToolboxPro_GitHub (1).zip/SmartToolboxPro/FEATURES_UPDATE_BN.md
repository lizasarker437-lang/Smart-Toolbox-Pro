# SR Smart Toolbox Pro — Feature Summary 1.4.2-alpha17

## Brand
- App name: SR Smart Toolbox Pro
- Created by Shahriar Rahman
- YouTube: @SRCreation-farm
- Facebook: fb.com/srcreation.farm
- Application ID remains `com.smarttoolbox.pro`.

## 1) Floating Sidebar
- Floating ST sidebar can stay ON even when all tools are OFF.
- Side tab can be opened by inward swipe or tap.
- Quick Control Panel closes after 3 seconds of inactivity or on a supported outside tap.
- Icon auto-hide delay and size/opacity/side width remain separately configurable.

## 2) Night Screen
- Extra-dark black overlay and warm filter.
- Floating panel controls Night Screen ON/OFF and darkness level.
- Does not change the phone's native brightness slider.

## 3) Extra Volume & Equalizer
- Master output gain request, five-band equalizer, Bass Boost and Virtualizer where supported.
- Native phone media-volume +/- buttons are separate.
- Global audio effects may be restricted by Android or the phone manufacturer; unsupported effects are reported.

## 4) Thermal Monitor
- Battery temperature and Android thermal status where available.
- Foreground monitoring service and floating quick control.

## 5) QR / Barcode Scanner
- Google Code Scanner scans QR and common barcode formats.
- Results can be copied, shared or opened as a web link after user action.
- No app CAMERA permission is required for the Google scanner UI.

## 6) SR Video Player — New
- Local video picker uses Storage Access Framework without broad permission; the newly added full MediaStore video library separately requests video read permission.
- Media3 ExoPlayer 1.11.1 with MP4, Matroska/MKV, WebM, AVI, MPEG-TS/PS, FLV, Ogg, WAV, FLAC and other extractors.
- HLS, DASH, SmoothStreaming and RTSP modules; network input accepts HTTPS and RTSP (plain HTTP is intentionally rejected).
- Play/pause, seek bar, previous/next, queue, shuffle and repeat.
- Double-tap ±10-second seek; speed 0.5x–3x.
- Embedded audio/subtitle track selection and external SRT, VTT, ASS/SSA, TTML subtitles.
- Fit/Fill/Zoom, immersive fullscreen, orientation, player-window brightness and media-volume sliders.
- Picture-in-Picture on supported devices.
- Background playback through MediaSessionService with Android media notification and wake mode.
- Service-managed sleep timer, screen-control lock, favorites, playback history and resume point.
- Unsupported/corrupt files show a playback error rather than claiming universal format support.

### Codec limitation
A container being recognized does not mean every codec/profile inside it can play. Actual decoding depends on the Android device's MediaCodec/software decoder capabilities, resolution, bit depth, DRM and file integrity. No app can guarantee every format on every phone.

## Build / verification
- JDK 17, AGP 8.10.0, Gradle 8.11.1, compileSdk 36, targetSdk 35.
- GitHub Actions workflow: `Build SR Smart Toolbox Pro APK`.
- Local source checks and API-shaped compile probes passed. Full Gradle APK compilation and physical-device playback tests still need to run in GitHub Actions / on a phone.
\n## 8) Video Player UI Redesign\n- Full-screen landscape black canvas with translucent top / bottom control panels.\n- Tap-to-show / 3.2-second auto-hide controls; seek, transport, lock, PiP and aspect-ratio actions.\n- Double-tap seek, vertical brightness / volume gestures and horizontal seek gesture.\n
## Video Library and individual Resume
- Indexed phone videos, folders, search and sorting.
- Independent resume bookmarks per video; long-press to restart.
