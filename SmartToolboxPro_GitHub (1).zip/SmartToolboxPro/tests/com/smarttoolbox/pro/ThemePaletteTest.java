package com.smarttoolbox.pro;

public final class ThemePaletteTest {
    private static void check(boolean test, String msg) { if (!test) throw new AssertionError(msg); }
    public static void main(String[] args) {
        check(ThemePalette.NAMES.length == 5, "Five themes required");
        check(ThemePalette.COLORS.length == 5, "Five color palettes required");
        for (int i = 0; i < 5; i++) {
            check(ThemePalette.colors(i).length == 7, "Seven theme tokens required");
            check(!ThemePalette.name(i).isEmpty(), "Nonempty theme label required");
            check(ThemePalette.safeIndex(i) == i, "Valid index changed");
            for (int color: ThemePalette.colors(i)) check((color >>> 24) == 255, "All colors must be opaque");
        }
        check(ThemePalette.safeIndex(-99) == 0, "Invalid negative index fallback");
        check(ThemePalette.safeIndex(42) == 0, "Invalid high index fallback");
        check(ThemePalette.isLight(4) && !ThemePalette.isLight(0), "Light-only fifth theme");
        int[] edited = ThemePalette.colors(0);
        edited[0] = 0;
        check(ThemePalette.colors(0)[0] != 0, "Color array must be defensive copy");
        System.out.println("ThemePaletteTest: 5 palettes, 7 colors each, validation and safety PASS");
    }
}
