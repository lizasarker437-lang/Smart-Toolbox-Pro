# Smart Toolbox Pro 1.2.3-alpha6 — Master Audio & Equalizer

## Changes
- Kept the existing Master Volume Control / global output gain slider.
- Added a five-band equalizer with Bass, Low Mid, Mid, High Mid and Treble sliders.
- Added app-defined sound profiles: Balanced, Bass Boost, Vocal, Rock, Classical, Treble and Podcast.
- Added separate Bass Boost strength control.
- Added separate Virtualizer / Spatial Effect control.
- Settings are saved and restored across app restarts.
- EQ changes are sent to the running audio service while processing is active.
- The audio service now manages LoudnessEnhancer, Equalizer, BassBoost and Virtualizer independently.
- One unsupported effect no longer automatically disables the other supported effects.
- The status text reports which global effects are available on the current phone.
- Updated main-screen description and CI source checks.

## Android compatibility
All effects request the global output mix using audio session 0. Android or the phone manufacturer may deny or restrict global effects. The app reports unsupported controls rather than claiming that they are active. This cannot exceed the physical speaker's hardware capability; excessive gain can distort sound and risk hearing damage.

## Validation status
Static Java delimiter, XML, manifest and workflow checks are performed on the source package. A full Android APK build still needs to run in GitHub Actions because this workspace does not include an Android SDK / Gradle installation.
