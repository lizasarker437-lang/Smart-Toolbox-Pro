# SR Smart Toolbox Pro — 1.5.7-alpha33

## Auto Scheduler Notepad
- Scheduler-এর ⋮ মেনু → **Scheduler Notepad** অথবা মেসেজ ফর্মের নিচে **📝 Notepad থেকে মেসেজ নিন**।
- **+ New** দিয়ে নোটের শিরোনাম ও মূল লেখা লিখে Save করুন।
- সেভ করা নোট Search, Edit, Delete করা যাবে। **Use in message** চাপলে Scheduler-এর মেসেজ ফর্মে লেখা চলে আসবে।
- আগে লেখা মেসেজ থাকলে Replace/Append/Cancel পছন্দ করতে পারবেন; আগের লেখা অনুমতি ছাড়া মোছা হবে না।
- নোট App Private SharedPreferences-এ থাকে; কোনো Network/Contacts/SMS Permission আলাদা করে প্রয়োজন নেই। সর্বোচ্চ ২০০ নোট; প্রতিটি ১২,০০০ অক্ষর পর্যন্ত, শিরোনাম ৮০ অক্ষর।
- Theme Studio-এর নির্বাচিত অ্যাপ Theme Notepad-এও প্রযোজ্য।

## Portrait Video Floating Edge
- **Floating Icon Settings → Portrait video-তে floating icon কিনারায় রাখুন** অন থাকলে নিজের SR Video Player-এ ভিডিও Portrait অবস্থায় চলতে শুরু করলে Floating Icon বাম/ডান কিনারার Swipeable Edge Tab হয়ে যাবে।
- Tab-এ Tap বা কিনারা থেকে Swipe করে Floating Toolbox বের করা যাবে।
- Player Pause/Stop, Landscape/PiP, বা Player থেকে বের হলে Floating Icon-এর পূর্বের অবস্থান ফিরিয়ে দেওয়ার চেষ্টা হয়; ব্যবহারকারী নিজে নতুন অবস্থানে সরিয়ে থাকলে তা পরিবর্তন করা হয় না।
- আগে থেকেই Edge-এ Hidden থাকলে আগের Hidden অবস্থা অক্ষত থাকে। Floating Icon OFF থাকলে এই ফিচার সেটি নিজে থেকে ON করে না।
- সীমাবদ্ধতা: এটি **SR Video Player-এর চলমান ভিডিও** শনাক্ত করে; অন্য অ্যাপের ভিডিও (YouTube, MX Player ইত্যাদি) শনাক্ত করার দাবি করে না। Android-এর Overlay Permission ও ব্যাটারি/সার্ভিসের বিধিনিষেধ প্রযোজ্য।

## Build / QA
- Source ZIP: `SmartToolboxPro_GitHub.zip`; Workflow: `build-apk.yml` (`.github/workflows/build-apk.yml`-এ আপলোড করুন)।
- Java Source AST Syntax এবং Pure Java Test-এর ফল `QA_REPORT_BN.txt`-এ দেওয়া হয়েছে।
- **Android SDK/Gradle এই পরিবেশে পাওয়া যায়নি**, তাই পূর্ণ Android APK Build বা বাস্তব ফোনের Playback/Overlay Test করা যায়নি। GitHub Actions Build সফল ও ফোনে পরীক্ষার পর রিলিজ করবেন।
