package android.provider;

import android.content.ContentResolver;
import android.content.Context;

public final class Settings {
    private Settings() {}
    public static final class System {
        public static final String SCREEN_BRIGHTNESS = "brightness";
        public static final String SCREEN_BRIGHTNESS_MODE = "mode";
        public static final int SCREEN_BRIGHTNESS_MODE_MANUAL = 0;
        public static final int SCREEN_BRIGHTNESS_MODE_AUTOMATIC = 1;
        public static boolean canWrite(Context c) { return c.writeSettingsPermission; }
        public static int getInt(ContentResolver cr, String name) {
            return name.equals(SCREEN_BRIGHTNESS) ? cr.brightness : cr.mode;
        }
        public static int getInt(ContentResolver cr, String name, int fallback) {
            return getInt(cr, name);
        }
        public static boolean putInt(ContentResolver cr, String name, int value) {
            if (name.equals(SCREEN_BRIGHTNESS)) {
                if (cr.failBrightnessWrite) return false;
                cr.brightness = value;
            } else if (name.equals(SCREEN_BRIGHTNESS_MODE)) {
                if (cr.failModeWrite) return false;
                cr.mode = value;
            }
            return true;
        }
    }
}
