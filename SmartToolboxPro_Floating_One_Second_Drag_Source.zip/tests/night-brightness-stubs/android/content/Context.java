package android.content;

import java.util.HashMap;
import java.util.Map;

public final class Context {
    public static final int MODE_PRIVATE = 0;
    public boolean writeSettingsPermission = true;
    private final ContentResolver resolver = new ContentResolver();
    private final Map<String,SharedPreferences> prefs = new HashMap<>();
    public ContentResolver getContentResolver() { return resolver; }
    public SharedPreferences getSharedPreferences(String name, int mode) {
        return prefs.computeIfAbsent(name, n -> new SharedPreferences());
    }
}
