package android.content;

public final class ContentResolver {
    public int brightness = 140;
    public int mode = 1;
    public boolean failBrightnessWrite;
    public boolean failModeWrite;
}
