package com.smarttoolbox.pro;
public final class SchedulerTemplateLogicTest {
    private static int checks;
    private static void verify(boolean ok, String message) { checks++; if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        verify(SchedulerTemplateLogic.isValid("Greeting", "Hello"), "valid template");
        verify(!SchedulerTemplateLogic.isValid("", "Hello"), "title required");
        verify(!SchedulerTemplateLogic.isValid("Title", "  "), "message required");
        verify(!SchedulerTemplateLogic.isValid("x".repeat(49), "Hello"), "title limit");
        verify(!SchedulerTemplateLogic.isValid("Title", "x".repeat(2001)), "message limit");
        verify(SchedulerTemplateLogic.cleanTitle("  Hello  ").equals("Hello"), "trim title");
        verify(SchedulerTemplateLogic.cleanMessage(null).isEmpty(), "null message safe");
        System.out.println(checks + " template validation tests passed");
    }
}
