package com.smarttoolbox.pro;

/** Regression coverage for overlays in Home, other apps, left/right portrait edges. */
public final class FloatingBarGestureLogicTest {
    private static int checks;
    private static void require(boolean valid, String label) {
        checks++;
        if (!valid) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        // Edge tab: swipes in any direction open, even when vertical.
        require(FloatingBarGestureLogic.edgeSwipe(30f, 0f, 18), "left inward");
        require(FloatingBarGestureLogic.edgeSwipe(-30f, 0f, 18), "right inward");
        require(FloatingBarGestureLogic.edgeSwipe(0f, 40f, 18), "vertical down");
        require(FloatingBarGestureLogic.edgeSwipe(0f, -40f, 18), "vertical up");
        require(FloatingBarGestureLogic.edgeSwipe(32f, 35f, 18), "diagonal");
        require(!FloatingBarGestureLogic.edgeSwipe(9f, 9f, 18), "jitter not swipe");
        require(!FloatingBarGestureLogic.edgeSwipe(0f, 0f, 18), "tap not swipe");
        require(FloatingBarGestureLogic.shouldOpenEdgeOnRelease(true, true), "release opens");
        require(!FloatingBarGestureLogic.shouldOpenEdgeOnRelease(true, false), "disabled panel stays off");
        require(!FloatingBarGestureLogic.shouldOpenEdgeOnRelease(false, true), "not touched");
        // Bubble: opening should not be mistaken for fast dragging.
        require(FloatingBarGestureLogic.bubbleSwipe(true, 43, 1, 140, 18), "left bubble inward");
        require(FloatingBarGestureLogic.bubbleSwipe(false, -43, 1, 140, 18), "right bubble inward");
        require(FloatingBarGestureLogic.bubbleSwipe(true, 0, 47, 170, 18), "bubble vertical down");
        require(FloatingBarGestureLogic.bubbleSwipe(false, 0, -47, 170, 18), "bubble vertical up");
        require(FloatingBarGestureLogic.bubbleSwipe(true, 25, 26, 200, 18), "diagonal inward");
        require(!FloatingBarGestureLogic.bubbleSwipe(true, -40, 0, 120, 18), "outward movement can drag");
        require(!FloatingBarGestureLogic.bubbleSwipe(false, 40, 0, 120, 18), "right outward can drag");
        require(!FloatingBarGestureLogic.bubbleSwipe(true, 8, 0, 120, 18), "bubble minor movement");
        require(!FloatingBarGestureLogic.bubbleSwipe(true, 40, 0, 800, 18), "slow drag not swipe");
        require(!FloatingBarGestureLogic.bubbleSwipe(true, 40, 0, -1, 18), "bad time safe");
        require(!FloatingBarGestureLogic.canDrag(400), "short hold not drag");
        require(!FloatingBarGestureLogic.canDrag(450), "450ms must not drag");
        require(!FloatingBarGestureLogic.canDrag(999), "999ms must not drag");
        require(FloatingBarGestureLogic.canDrag(1000), "1-second hold enables move");
        require(FloatingBarGestureLogic.canDrag(3000), "long hold remains drag");
        require(FloatingBarGestureLogic.bubbleSwipe(true, 36, 0, 700, 18), "end swipe time inclusive");
        require(!FloatingBarGestureLogic.bubbleSwipe(true, 36, 0, 701, 18), "end swipe time exclusive");
        System.out.println(checks + " floating bar gesture checks passed");
    }
}
