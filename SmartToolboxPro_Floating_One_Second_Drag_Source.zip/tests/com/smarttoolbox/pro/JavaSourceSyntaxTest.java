package com.smarttoolbox.pro;

import com.sun.source.tree.ClassTree;
import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;
import com.sun.source.util.JavacTask;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/** Parses real app Java files using the JDK compiler AST without Android SDK jars. */
public final class JavaSourceSyntaxTest {
    private static void require(boolean pass, String text) {
        if (!pass) throw new AssertionError(text);
    }

    public static void main(String[] args) throws IOException {
        require(args.length == 1, "Usage: JavaSourceSyntaxTest <java-source-root>");
        List<Path> paths = new ArrayList<>();
        try (java.util.stream.Stream<Path> files = Files.walk(Path.of(args[0]))) {
            files.filter(p -> p.toString().endsWith(".java")).forEach(paths::add);
        }
        require(!paths.isEmpty(), "No Java source files were found");
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        require(compiler != null, "JDK compiler required");
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager fm = compiler.getStandardFileManager(diagnostics, null, null)) {
            Iterable<? extends JavaFileObject> sources = fm.getJavaFileObjectsFromPaths(paths);
            JavacTask task = (JavacTask) compiler.getTask(null, fm, diagnostics,
                    List.of("-proc:none"), null, sources);
            int count = 0;
            for (CompilationUnitTree compilationUnit : task.parse()) {
                count++;
                for (Tree declaration : compilationUnit.getTypeDecls()) {
                    if (!(declaration instanceof ClassTree)) continue;
                    ClassTree clazz = (ClassTree) declaration;
                    Set<String> fields = new HashSet<>();
                    for (Tree member : clazz.getMembers()) {
                        if (!(member instanceof VariableTree)) continue;
                        String name = ((VariableTree) member).getName().toString();
                        require(fields.add(name), "Duplicate field '" + name + "' in "
                                + compilationUnit.getSourceFile().getName());
                    }
                }
            }
            require(count == paths.size(), "Not all Java source files were parsed");
            for (Diagnostic<? extends JavaFileObject> diagnostic : diagnostics.getDiagnostics()) {
                require(diagnostic.getKind() != Diagnostic.Kind.ERROR,
                        diagnostic.getSource() + ":" + diagnostic.getLineNumber() + ": "
                                + diagnostic.getMessage(null));
            }
        }
        System.out.println("Java compiler AST syntax and duplicate-field checks passed ("
                + paths.size() + " files)");
    }
}
