package com.smarttoolbox.pro;

public final class NightBrightnessPolicyTest {
    private static int tests;
    private static void verify(boolean yes, String reason) {
        tests++; if (!yes) throw new AssertionError(reason);
    }
    public static void main(String[] args) {
        verify(NightBrightnessPolicy.MIN_BRIGHTNESS == 1, "minimum is a visible nonzero backlight");
        verify(NightBrightnessPolicy.safeBrightness(0) == 1, "zero is clamped");
        verify(NightBrightnessPolicy.safeBrightness(-3) == 1, "negative brightness");
        verify(NightBrightnessPolicy.safeBrightness(50) == 50, "normal brightness");
        verify(NightBrightnessPolicy.safeBrightness(256) == 255, "maximum cap");
        verify(NightBrightnessPolicy.safeMode(1) == 1, "automatic preserved");
        verify(NightBrightnessPolicy.safeMode(0) == 0, "manual preserved");
        verify(NightBrightnessPolicy.safeMode(100) == 0, "invalid mode safe");
        verify(NightBrightnessPolicy.canLower(true, true), "only permitted and opted in");
        verify(!NightBrightnessPolicy.canLower(false, true), "missing permission");
        verify(!NightBrightnessPolicy.canLower(true, false), "opted out");
        verify(!NightBrightnessPolicy.canLower(false, false), "both disabled");
        verify(NightBrightnessPolicy.shouldRestore(true, true, 1, 0), "restore active minimum");
        verify(!NightBrightnessPolicy.shouldRestore(false, true, 1, 0), "no backup");
        verify(!NightBrightnessPolicy.shouldRestore(true, false, 1, 0), "revoked permission");
        verify(!NightBrightnessPolicy.shouldRestore(true, true, 60, 0), "user brightness changed");
        verify(!NightBrightnessPolicy.shouldRestore(true, true, 1, 1), "user changed to adaptive mode");
        verify(NightBrightnessPolicy.safeDimLevel(-1) == 0, "overlay min");
        verify(NightBrightnessPolicy.safeDimLevel(96) == 95, "overlay max");
        verify(NightBrightnessPolicy.overlayViewAlpha(95) == .95f, "visual max");
        verify(NightBrightnessPolicy.SAFE_OVERLAY_WINDOW_ALPHA <= .8f, "pass-through opacity");
        System.out.println(tests + " Night Screen brightness and safety tests passed");
    }
}
