package com.smarttoolbox.pro;

public final class ThemePaletteTest {
    private static void check(boolean test, String msg) { if (!test) throw new AssertionError(msg); }
    public static void main(String[] args) {
        check(ThemePalette.NAMES.length == 9, "Nine themes required");
        check(ThemePalette.count() == 9, "Nine color palettes required");
        for (int i = 0; i < ThemePalette.count(); i++) {
            check(ThemePalette.colors(i).length == 7, "Seven theme tokens required");
            check(!ThemePalette.name(i).isEmpty(), "Nonempty theme label required");
            check(ThemePalette.safeIndex(i) == i, "Valid index changed");
            for (int color: ThemePalette.colors(i)) check((color >>> 24) == 255, "All colors must be opaque");
        }
        check(ThemePalette.safeIndex(-99) == 0, "Invalid negative index fallback");
        check(ThemePalette.safeIndex(42) == 0, "Invalid high index fallback");
        check(ThemePalette.isLight(4) && !ThemePalette.isLight(0), "Light-only fifth theme");
        int[] edited = ThemePalette.colors(0);
        edited[0] = 0;
        check(ThemePalette.colors(0)[0] != 0, "Color array must be defensive copy");
        for (int i = 0; i < ThemePalette.count(); i++) {
            int[] dark = ThemePalette.colors(i, false);
            int[] light = ThemePalette.colors(i, true);
            check(dark.length == 7 && light.length == 7, "Dark/light token count");
            check(dark[0] != light[0], "Light and dark surfaces differ");
            check(dark[5] == light[5], "Accent stays stable across appearance modes");
        }
        System.out.println("ThemePaletteTest: 9 palettes, system/light/dark surface variants PASS");
    }
}
