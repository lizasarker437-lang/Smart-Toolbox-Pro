package com.smarttoolbox.pro;

public final class EdgeSwipeLogicTest {
    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        require(EdgeSwipeLogic.isInwardSwipe(true, 50, 4, 22), "Left: swipe right should open");
        require(EdgeSwipeLogic.isInwardSwipe(false, -50, 2, 22), "Right: swipe left should open");
        require(!EdgeSwipeLogic.isInwardSwipe(true, -50, 1, 22), "Left: swipe outward should not open");
        require(!EdgeSwipeLogic.isInwardSwipe(false, 50, 1, 22), "Right: swipe outward should not open");
        require(!EdgeSwipeLogic.isInwardSwipe(true, 7, 0, 22), "Tiny movement should not open");
        require(!EdgeSwipeLogic.isInwardSwipe(true, 35, 60, 22), "Vertical swipe should not open");
        require(EdgeSwipeLogic.bubbleXForSide(true, 400, 60, 5) == 5, "Left restore should remain left");
        require(EdgeSwipeLogic.bubbleXForSide(false, 400, 60, 5) == 335, "Right restore should remain right");
        require(EdgeSwipeLogic.bubbleXForSide(false, 25, 60, 5) == 0, "Small widths should clamp");
        System.out.println("9 edge swipe and same-side restoration checks passed");
    }
}
