package com.smarttoolbox.pro;

public final class UpdateKitLogicTest {
    private static int count;
    private static void verify(boolean result, String description) {
        count++;
        if (!result) throw new AssertionError(description);
    }
    public static void main(String[] args) {
        verify("Meeting reminder".equals(SchedulerNoteLogic.title("  Meeting   reminder  ")),
                "normalize title spaces");
        verify(SchedulerNoteLogic.title(null).isEmpty(), "null title");
        verify(SchedulerNoteLogic.title("x".repeat(100)).length() == 80, "title cap");
        verify(!SchedulerNoteLogic.valid("   "), "blank note rejected");
        verify(SchedulerNoteLogic.valid("Please call"), "valid note");
        verify(SchedulerNoteLogic.body(null).isEmpty(), "null body");
        verify(SchedulerNoteLogic.body("x".repeat(13000)).length() == 12000, "body cap");
        verify(SchedulerNoteLogic.preview("A\n B").equals("A B"), "preview whitespace");
        verify(SchedulerNoteLogic.preview("x".repeat(100)).endsWith("…"), "preview crop");
        verify(SchedulerNoteLogic.matches("Hello", "my body", " HEL "), "title search");
        verify(SchedulerNoteLogic.matches("Hello", "my body", "BODY"), "body search");
        verify(!SchedulerNoteLogic.matches("Hello", "my body", "absent"), "search miss");
        verify(PortraitVideoEdgeLogic.shouldPin(true, true, true, false), "portrait video pins");
        verify(!PortraitVideoEdgeLogic.shouldPin(false, true, true, false), "not playing");
        verify(!PortraitVideoEdgeLogic.shouldPin(true, false, true, false), "landscape not pinned");
        verify(!PortraitVideoEdgeLogic.shouldPin(true, true, false, false), "disabled icon");
        verify(!PortraitVideoEdgeLogic.shouldPin(true, true, true, true), "panel open");
        verify(PortraitVideoEdgeLogic.left(2, 50, 1000), "nearest left");
        verify(!PortraitVideoEdgeLogic.left(900, 50, 1000), "nearest right");
        verify(PortraitVideoEdgeLogic.edgeX(1080, 54, false, 0) == 1026, "right edge");
        verify(PortraitVideoEdgeLogic.edgeX(1080, 54, true, 0) == 0, "left edge");
        verify(PortraitVideoEdgeLogic.clampY(-20, 1000, 54, 8) == 8, "top safe edge");
        verify(PortraitVideoEdgeLogic.clampY(9999, 1000, 54, 8) == 938, "bottom safe edge");
        System.out.println(count + " local scheduler notepad / portrait video edge logic tests PASS");
    }
}
