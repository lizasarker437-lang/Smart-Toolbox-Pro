package com.smarttoolbox.pro;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.List;

public final class MessageScheduleLogicTest {
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static long time(int year, int month, int day, int hour, int minute) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month - 1, day, hour, minute, 0);
        return c.getTimeInMillis();
    }

    public static void main(String[] args) {
        TimeZone original = TimeZone.getDefault();
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

            require("8801712345678".equals(
                    MessageScheduleLogic.normalizePhone("880", "01712345678")),
                    "Bangladesh local number should normalize with country code");
            require("12025550123".equals(
                    MessageScheduleLogic.normalizePhone("880", "+1 202-555-0123")),
                    "Explicit international number must not receive the default country code");
            require("8801712345678".equals(
                    MessageScheduleLogic.normalizePhone("880", "008801712345678")),
                    "00 international prefix should be normalized");

            List<String> numbers = MessageScheduleLogic.normalizePhones(
                    "880", "01712345678, +1 2025550123; 01712345678");
            require(numbers.size() == 2, "Phone list must remove duplicate numbers");
            require(MessageScheduleLogic.isValidPhone("8801712345678"), "Valid E.164-like number rejected");
            require(!MessageScheduleLogic.isValidPhone("123"), "Short number accepted");
            require(MessageScheduleLogic.isValidMessage(" Hello "), "Non-empty message rejected");
            require(!MessageScheduleLogic.isValidMessage("  "), "Blank message accepted");
            require(MessageScheduleLogic.isValidFutureTime(2001L, 1000L),
                    "Future schedule should validate");
            require(!MessageScheduleLogic.isValidFutureTime(1000L, 1000L),
                    "Current-time schedule should be rejected");

            String url = MessageScheduleLogic.buildWhatsAppUrl("8801712345678", "Hello Shahriar & team");
            require(url.startsWith("https://wa.me/8801712345678?text="), "WhatsApp URL format invalid");
            require(url.contains("Hello%20Shahriar%20%26%20team"),
                    "WhatsApp text should be UTF-8 URL encoded");
            boolean invalidRejected = false;
            try {
                MessageScheduleLogic.buildWhatsAppUrl("123", "Hello");
            } catch (IllegalArgumentException expected) {
                invalidRejected = true;
            }
            require(invalidRejected, "Invalid phone must not produce a WhatsApp URL");

            long previous = time(2026, 11, 14, 9, 30);
            long now = time(2026, 11, 14, 10, 0);
            Calendar daily = Calendar.getInstance();
            daily.setTimeInMillis(MessageScheduleLogic.nextOccurrence(previous, "daily", now));
            require(daily.get(Calendar.DAY_OF_MONTH) == 15
                            && daily.get(Calendar.HOUR_OF_DAY) == 9
                            && daily.get(Calendar.MINUTE) == 30,
                    "Daily repeat should preserve local clock time");
            Calendar weekly = Calendar.getInstance();
            weekly.setTimeInMillis(MessageScheduleLogic.nextOccurrence(previous, "weekly", now));
            require(weekly.get(Calendar.DAY_OF_MONTH) == 21
                            && weekly.get(Calendar.HOUR_OF_DAY) == 9
                            && weekly.get(Calendar.MINUTE) == 30,
                    "Weekly repeat should preserve weekday and clock time");
            require(MessageScheduleLogic.nextOccurrence(previous, "once", now) == -1L,
                    "One-time schedule must not repeat");
            require(MessageScheduleLogic.stableAlarmId("schedule-1") > 0,
                    "Alarm request code must be positive");
            require("প্রতি সপ্তাহে".equals(MessageScheduleLogic.repeatLabel("weekly")),
                    "Weekly label mismatch");
            require(MessageScheduleLogic.messagePreview("one two three four", 9).length() <= 9,
                    "Message preview should respect maximum length");

            System.out.println("MessageScheduleLogicTest: all 15 checks passed");
        } finally {
            TimeZone.setDefault(original);
        }
    }
}
