package com.smarttoolbox.pro;

public final class GroupScheduleLogicTest {
    private static int checks;
    private static void verify(boolean ok, String msg) {
        checks++; if (!ok) throw new AssertionError(msg);
    }
    public static void main(String[] args) {
        long base = 1_700_000_000_000L;
        verify(!GroupScheduleLogic.validCount(1), "single not group");
        verify(GroupScheduleLogic.validCount(2), "two accepted");
        verify(GroupScheduleLogic.validCount(20), "max accepted");
        verify(!GroupScheduleLogic.validCount(21), "max enforced");
        verify(GroupScheduleLogic.scheduledAt(base, 0) == base, "first same due time");
        verify(GroupScheduleLogic.scheduledAt(base, 1) == base, "second same due time");
        verify(GroupScheduleLogic.scheduledAt(base, 4) == base, "fifth same due time");
        verify(GroupScheduleLogic.scheduledAt(base, 19) == base, "twentieth same due time");
        verify(GroupScheduleLogic.scheduledAt(base, -1) == base, "negative index safe");
        verify(GroupScheduleLogic.scheduledAt(Long.MAX_VALUE, 19) == Long.MAX_VALUE,
                "no stagger overflow");
        verify(GroupScheduleLogic.allTimesFuture(base, 5, base - 10_000), "future valid");
        verify(!GroupScheduleLogic.allTimesFuture(base, 5, base + 240_000), "past invalid");
        verify(!GroupScheduleLogic.allTimesFuture(base, 5, base - 500), "lead time required");
        verify(GroupScheduleLogic.recipientPosition(2, 5).contains("2/5"), "position label");
        verify(GroupScheduleLogic.recipientPosition(99, 5).contains("5/5"), "index clamped");
        verify("Family Team".equals(GroupScheduleLogic.cleanGroupName("  Family  Team  ")),
                "spaces normalized");
        verify(GroupScheduleLogic.cleanGroupName(null).isEmpty(), "null group name");
        verify(GroupScheduleLogic.cleanGroupName("x".repeat(100)).length() == 50,
                "name capped");
        verify("Broadcast group".equals(GroupScheduleLogic.displayName(" ")),
                "empty group label fallback");
        System.out.println(checks + " same-due-time group scheduling tests passed");
    }
}
