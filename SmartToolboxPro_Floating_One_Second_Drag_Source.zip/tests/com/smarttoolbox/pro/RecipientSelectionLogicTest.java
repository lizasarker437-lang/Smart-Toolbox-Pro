package com.smarttoolbox.pro;

import java.util.List;

public final class RecipientSelectionLogicTest {
    private static int checks;
    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        List<String> once = RecipientSelectionLogic.appendUnique("", "8801712345678");
        check(once.size() == 1, "Adds a recent recipient");
        check(once.get(0).equals("8801712345678"), "Preserves normalized international phone");
        List<String> twice = RecipientSelectionLogic.appendUnique("+8801712345678", "8801712345678");
        check(twice.size() == 1, "Does not duplicate an existing recipient");
        List<String> many = RecipientSelectionLogic.appendUnique("+8801712345678", "8801912345678");
        check(many.size() == 2, "Can add a second phone");
        check(RecipientSelectionLogic.asCommaSeparatedNumbers(many)
                        .equals("+8801712345678, +8801912345678"), "Displays usable phone field");
        check(RecipientSelectionLogic.appendUnique("", "123").isEmpty(),
                "Rejects invalid recipient");
        check(RecipientSelectionLogic.appendUnique("+8801712345678", null).size() == 1,
                "Null entry must not clear current recipient");
        check(RecipientSelectionLogic.asCommaSeparatedNumbers(List.of()).isEmpty(),
                "Empty recipient list safe");
        System.out.println(checks + " recipient selection checks passed");
    }
}
