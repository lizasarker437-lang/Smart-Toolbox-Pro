package com.smarttoolbox.pro;

public final class SchedulerForegroundLogicTest {
    private static int checks;
    private static void check(boolean result, String reason) {
        checks++;
        if (!result) throw new AssertionError(reason);
    }

    public static void main(String[] args) {
        String mine = "com.smarttoolbox.pro";
        String home = "com.miui.home";
        check(SchedulerForegroundLogic.isHome(home, home), "Recognize default Home");
        check(SchedulerForegroundLogic.isHome("com.niagara.app", "com.niagara.app"),
                "Recognize third-party default Home even without 'launcher'");
        check(SchedulerForegroundLogic.isHome("com.android.launcher3", ""), "Generic launcher");
        check(!SchedulerForegroundLogic.isHome("com.android.chrome", home), "Chrome is not Home");
        check("".equals(SchedulerForegroundLogic.captureTarget(home, "com.android.chrome", mine, home)),
                "Home overrides stale previously active Chrome");
        check("com.android.chrome".equals(SchedulerForegroundLogic.captureTarget(
                "com.android.chrome", home, mine, home)), "Return to currently foreground Chrome");
        check("com.whatsapp".equals(SchedulerForegroundLogic.captureTarget(
                "com.whatsapp", "com.android.chrome", mine, home)), "WhatsApp can itself be prior app");
        check("".equals(SchedulerForegroundLogic.captureTarget("", home, mine, home)),
                "When no root is available, last observed Home stays Home");
        check(mine.equals(SchedulerForegroundLogic.captureTarget(
                mine, "com.android.chrome", mine, home)), "Own app visible is also a return destination");
        check("".equals(SchedulerForegroundLogic.captureTarget("android", "", mine, home)),
                "Unknown / Android System UI falls back to Home");
        check(SchedulerForegroundLogic.displaySeconds(43000L, 40000L) == 3, "Shows 3");
        check(SchedulerForegroundLogic.displaySeconds(43000L, 40001L) == 3, "3 still visible");
        check(SchedulerForegroundLogic.displaySeconds(43000L, 41000L) == 2, "Shows 2");
        check(SchedulerForegroundLogic.displaySeconds(43000L, 42000L) == 1, "Shows 1");
        check(SchedulerForegroundLogic.displaySeconds(43000L, 42999L) == 1, "No zero before time");
        check(SchedulerForegroundLogic.displaySeconds(43000L, 43000L) == 0, "Then send");
        check(SchedulerForegroundLogic.remainingMillis(43000L, 42001L) == 999L, "Remaining ms");
        check(SchedulerForegroundLogic.remainingMillis(43000L, 44000L) == 0L, "No negative ms");
        check(SchedulerForegroundLogic.allowAutomaticSendAfterCountdown(true, true, true, false),
                "Allowed after a visible countdown");
        check(!SchedulerForegroundLogic.allowAutomaticSendAfterCountdown(false, true, true, false),
                "Do not send before showing countdown");
        check(!SchedulerForegroundLogic.allowAutomaticSendAfterCountdown(true, false, true, false),
                "Do not send if screen turned off during countdown");
        check(!SchedulerForegroundLogic.allowAutomaticSendAfterCountdown(true, true, false, false),
                "Do not send if phone locked during countdown");
        check(!SchedulerForegroundLogic.allowAutomaticSendAfterCountdown(true, true, true, true),
                "Cancel always prevents auto send");
        System.out.println(checks + " foreground return and 3-2-1 countdown tests passed");
    }
}
