package com.smarttoolbox.pro;

public final class PremiumExperienceLogicTest {
    private static int checks;
    private static void ok(boolean test, String label) { checks++; if (!test) throw new AssertionError(label); }
    public static void main(String[] args) {
        ok(PremiumExperienceLogic.style(0)==0,"classic preserved");
        ok(PremiumExperienceLogic.style(1)==1,"premium");
        ok(PremiumExperienceLogic.style(-1)==1,"invalid style fallback");
        ok(PremiumExperienceLogic.style(99)==1,"future style fallback");
        ok(PremiumExperienceLogic.soundPack(-1)==0,"pack invalid low");
        ok(PremiumExperienceLogic.soundPack(4)==0,"pack invalid high");
        ok(PremiumExperienceLogic.soundPack(3)==3,"arcade pack");
        ok(PremiumExperienceLogic.soundEvent(-1)==0,"event invalid low");
        ok(PremiumExperienceLogic.soundEvent(100)==0,"event invalid high");
        ok(PremiumExperienceLogic.soundIndex(0,0)==0,"soft tap index");
        ok(PremiumExperienceLogic.soundIndex(0,3)==3,"soft intro index");
        ok(PremiumExperienceLogic.soundIndex(1,0)==4,"digital tap index");
        ok(PremiumExperienceLogic.soundIndex(2,2)==10,"crystal success index");
        ok(PremiumExperienceLogic.soundIndex(3,3)==15,"arcade intro index");
        ok(!PremiumExperienceLogic.shouldPlay(false,true,false),"muted setting");
        ok(!PremiumExperienceLogic.shouldPlay(true,false,false),"no audio focus");
        ok(!PremiumExperienceLogic.shouldPlay(true,true,true),"device muted");
        ok(PremiumExperienceLogic.shouldPlay(true,true,false),"sound enabled");
        ok(PremiumExperienceLogic.modeKey(4,0,true,0)!=PremiumExperienceLogic.modeKey(4,0,true,1),"switch refresh key");
        ok(PremiumExperienceLogic.modeKey(1,0,true,1)!=PremiumExperienceLogic.modeKey(1,2,true,1),"appearance refresh key");
        ok(PremiumExperienceLogic.modeKey(1,0,true,1)!=PremiumExperienceLogic.modeKey(2,0,true,1),"palette refresh key");
        ok(PremiumExperienceLogic.PACK_NAMES.length==PremiumExperienceLogic.PACKS,"pack names");
        System.out.println(checks+" premium style and sound policy tests passed");
    }
}
