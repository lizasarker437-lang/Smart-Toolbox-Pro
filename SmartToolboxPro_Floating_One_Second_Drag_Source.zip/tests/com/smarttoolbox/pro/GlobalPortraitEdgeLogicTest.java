package com.smarttoolbox.pro;

public final class GlobalPortraitEdgeLogicTest {
    private static int checks;
    private static void test(boolean actual,String description) {
        checks++;
        if (!actual) throw new AssertionError(description);
    }
    public static void main(String[] args) {
        test(GlobalPortraitEdgeLogic.isPortrait(1080,2400,false),"portrait display overrides stale app resources");
        test(!GlobalPortraitEdgeLogic.isPortrait(2400,1080,true),"landscape display overrides app resources");
        test(GlobalPortraitEdgeLogic.isPortrait(0,0,true),"fallback portrait");
        test(!GlobalPortraitEdgeLogic.isPortrait(0,0,false),"fallback landscape");
        test(GlobalPortraitEdgeLogic.isPortrait(1000,1000,true),"square foldable fallback");
        test(!GlobalPortraitEdgeLogic.isPortrait(1000,1000,false),"square foldable fallback landscape");
        test(GlobalPortraitEdgeLogic.shouldDock(true,true,true,true,false,false),"any Portrait app docks");
        test(!GlobalPortraitEdgeLogic.shouldDock(false,true,true,true,false,false),"off option");
        test(!GlobalPortraitEdgeLogic.shouldDock(true,false,true,true,false,false),"landscape not docked");
        test(!GlobalPortraitEdgeLogic.shouldDock(true,true,false,true,false,false),"permission missing");
        test(!GlobalPortraitEdgeLogic.shouldDock(true,true,true,false,false,false),"floating disabled");
        test(!GlobalPortraitEdgeLogic.shouldDock(true,true,true,true,true,false),"user hidden");
        test(!GlobalPortraitEdgeLogic.shouldDock(true,true,true,true,false,true),"quick panel open");
        test(GlobalPortraitEdgeLogic.shouldUndock(true,false,true),"landscape restores");
        test(GlobalPortraitEdgeLogic.shouldUndock(true,true,false),"switch off restores");
        test(!GlobalPortraitEdgeLogic.shouldUndock(false,false,true),"do not restore user-hidden icon");
        test(GlobalPortraitEdgeLogic.edgeX(true,1080,32)==0,"left-edge X");
        test(GlobalPortraitEdgeLogic.edgeX(false,1080,32)==1048,"right-edge X");
        test(GlobalPortraitEdgeLogic.edgeX(false,20,32)==0,"narrow width safe");
        test(GlobalPortraitEdgeLogic.edgeY(100,2400,70,8)==100,"Y unchanged when valid");
        test(GlobalPortraitEdgeLogic.edgeY(2399,2400,70,8)==2322,"Y clamped at bottom");
        test(GlobalPortraitEdgeLogic.edgeY(-20,2400,70,8)==8,"Y clamped at top");
        System.out.println(checks + " global Portrait Edge logic checks passed");
    }
}
