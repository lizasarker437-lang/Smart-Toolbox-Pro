# SR Smart Toolbox Pro 1.3.1-alpha14 — QR / Barcode Scanner

## পরিবর্তন
- আগের Document Scanner, PDF export এবং OCR feature সরিয়ে QR / Barcode Scanner যুক্ত হয়েছে।
- Google Code Scanner API দিয়ে QR, EAN/UPC, Code 128/39/93, Codabar, Data Matrix, ITF, PDF417, Aztec এবং API-supported barcode format scan করা যায়।
- Auto-zoom চালু আছে।
- Scan result-এ code format এবং decoded value দেখা যায়।
- Copy এবং Share action আছে।
- Result HTTP/HTTPS link হলে আলাদা Open Link action দেখায়; নিজে থেকে কোনো link খোলে না।
- অ্যাপ CAMERA permission চায় না। Google Play services scanner UI পরিচালনা করে এবং decoded result অ্যাপে ফেরত দেয়।

## Android / Gradle configuration
- Dependency: `com.google.android.gms:play-services-code-scanner:16.1.0`
- Manifest metadata: `com.google.mlkit.vision.DEPENDENCIES=barcode_ui`
- minSdk 26, তাই API minimum requirement পূরণ করে।
- Google Play services চালু ও updated থাকতে হবে। Scanner module আগে install না থাকলে প্রথম ব্যবহারে download হতে পারে।

## Official API guide
https://developers.google.com/ml-kit/vision/barcode-scanning/code-scanner

## QA সীমাবদ্ধতা
Source-level checks, XML, manifest, workflow YAML এবং ZIP integrity পরীক্ষা করা হয়েছে। এই workspace-এ Android SDK ও Gradle নেই, তাই সম্পূর্ণ APK build এবং physical-device scan test চালানো হয়নি। GitHub Actions-এর `:app:assembleDebug` এবং ফোনে বাস্তব QR/barcode scan হলো পরবর্তী চূড়ান্ত পরীক্ষা।
