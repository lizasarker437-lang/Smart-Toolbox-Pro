# SR Smart Toolbox Pro — Premium UI & Sound Update

**Version: 1.5.13-alpha39 (versionCode 39)**

## নতুন Premium Gold Logo
- ব্যবহারকারীর পছন্দের Gold-and-Navy SR Logo 512×512 PNG Launcher Icon হিসেবে যুক্ত করা হয়েছে।
- Opening Branding Animation-এর Logo নতুন করা হয়েছে; Premium Home Page-এ SR Logo সহ Branding Hero রয়েছে।
- আগের Developer তথ্য অপরিবর্তিত: **Shahriar Rahman**, **SR Creation Farm**, **@SRCreation-farm**, **fb.com/srcreation.farm**।

## Premium বনাম Classic UI — দুই মোড
**Home → ⋮ Menu → Premium / Classic & Sounds → Smart Theme Studio**
- **✨ Premium:** Layered Gradient Background, Accent Border, elevated rounded Cards, refined Typography, ripple Button ও Enter Animation। Home, Auto Scheduler, Notepad, Night Screen, About এবং অন্যান্য `Ui`-ভিত্তিক Screen-এ পরিবর্তন প্রতিফলিত হবে। Floating Toolbox-এ Premium Panel Border/Surface প্রযোজ্য।
- **◻ Classic:** আগের Flat/Solid Color Button, Card ও Page Design; আগের Theme Palette ও Light/Dark Choice অক্ষত থাকে। Logo নতুন থাকবে, কিন্তু পুরোনো Interface Styling ফিরবে।
- প্রথম ইনস্টল/এই আপডেটে **Premium** ডিফল্ট থাকবে। Classic বেছে নিলে সেটি অ্যাপ বন্ধ করার পরও সংরক্ষিত থাকবে।
- পুরোনো Nine Color Palettes + System / Light / Dark বিকল্প অপরিবর্তিত।

## Animation & Sound
- UI Animation: **ON/OFF** — Opening Reveal ও Premium Card-entry Animation নিয়ন্ত্রণ করে।
- Interface Sound: **ON/OFF** — বন্ধ করলে বর্তমানে বাজা ছোট UI Sound-ও থামে।
- Sound Styles: **Soft**, **Digital**, **Crystal**, **Arcade**।
- প্রতিটি Style-এ ৪টি Original Generated Sound: **Tap**, **Menu Open/Navigation**, **Success**, **Opening Intro** (১৬টি WAV)। কোনো পরিচিত গেম/অ্যাপের কপিরাইটযুক্ত Audio কপি করা হয়নি।
- ফোন Silent/Vibrate কিংবা Music Volume 0 হলে Sound বাজবে না; অতিরিক্ত Storage/Microphone Permission লাগে না।
- Sound Effect খুব ছোট এবং কম ভলিউমে রাখা হয়েছে।

## সংরক্ষিত পুরোনো ফিচার
Floating Gesture (Tap/Swipe, 2-second Hold-to-Move), Global Portrait Edge, Night Screen with brightness restore, System Audio, Scheduler with Notepad/History/Group Cards/Contacts, Video Library/Player এবং সমস্ত Branding তথ্য অপরিবর্তিত রাখা হয়েছে।

## পরীক্ষার প্রকৃত অবস্থা
- GitHub Workflow-এর ২৭টি স্থানীয় Source/Logic ধাপ পাস করেছে।
- Pure-Java Premium Experience Logic-এর ২২টি assertion পাস করেছে।
- সমস্ত Java Source AST, XML, Shell Syntax, Sound File ও ZIP Integrity পরীক্ষা করা হয়েছে।
- **Android SDK ও Gradle এখানে নেই, তাই পূর্ণ `:app:assembleDebug` এবং বাস্তব ফোনে UI/Sound যাচাই করা হয়নি।** GitHub Actions ও ফোনে পরীক্ষা প্রয়োজন।
