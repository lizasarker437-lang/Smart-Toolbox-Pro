# SR Smart Toolbox Pro 1.4.8-alpha23 — Video Immersive & Audio Exit

## ১. ভিডিও চললে Notification Bar লুকাবে
- AndroidX `WindowInsetsControllerCompat`-এর Immersive Mode ব্যবহার করা হয়েছে।
- Status/Notification Bar ও Navigation Bar ভিডিওর সময়ে লুকানো থাকবে।
- ভিডিও চলার সময় ওপর থেকে Swipe করলে Android সাময়িকভাবে Notification Shade/System Bar দেখাতে পারবে।
- System Bar ফিরে লুকানো Android OS ও ফোন নির্মাতার নিয়ন্ত্রণে থাকে; অ্যাপ নোটিফিকেশন বন্ধ করে না।

## ২. সাধারণ Back করলে ভিডিও ও অডিও বন্ধ
- Player-এর Back Button, Android Back Gesture এবং Hardware Back-এ `exitPlayerAndStop()` চলে।
- আগে Resume Position সেভ হয়। এরপর MediaController এবং MediaSessionService-এর Playback বন্ধ ও Playlist পরিষ্কার হয়।
- আগের Resume Playback, ভিডিও ফোল্ডার, Library ও Thumbnail অপরিবর্তিত।

## ৩. 🎵 Background Audio বাটন
- Player-এর উপর দিকের Quick Action Row-তে 🎵 বাটন চাপলে Player স্ক্রিন বন্ধ হয়, কিন্তু Audio MediaSessionService-এ চলতে থাকে।
- ভিডিও Pause থাকলে Audio শুরু হয়। ভিডিও না খোলা থাকলে বাটন অ্যাপ বন্ধ করে না; আগে ভিডিও নির্বাচন করতে বলে।
- Media Notification থেকে Pause/Resume (ডিভাইস ও Android অনুমতি অনুযায়ী) করা যাবে। আবার Player খুলে Stop করা যাবে।
- আলাদা Audio-only Display Toggle (Player-এর ভিতরে থাকা অবস্থায় ভিডিও Surface লুকানো) Overflow Menu-তে থাকবে।

## ৪. PiP
- Picture-in-Picture আলাদা অপশন হিসেবে কাজ করবে। স্বাভাবিক Back/🎵 Audio Exit যেন PiP শুরু না করে সেই সুরক্ষা দেওয়া হয়েছে।

## পরীক্ষা ও সীমাবদ্ধতা
- ছয়টি Exit Policy Test এবং আগের সোর্স/ইউনিট টেস্টগুলো লোকালি চালানো হয়েছে।
- এই পরিবেশে Android SDK/Gradle নেই; সম্পূর্ণ APK Build বা বাস্তব Android ফোনে ইমার্সিভ বার পরীক্ষা করা হয়নি।
- কিছু ফোনে Status Bar/System Gesture-এর সাময়িক আচরণ নির্মাতার কারণে ভিন্ন হতে পারে।
