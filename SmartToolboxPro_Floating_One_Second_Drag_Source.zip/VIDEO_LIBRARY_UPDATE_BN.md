# SR Video Library — 1.4.3-alpha18

## ভিডিও লাইব্রেরি
অ্যাপের SR Video Player চাপলে ফোনের Video Library খুলবে। ফোনে Android MediaStore-এ ইনডেক্স করা ভিডিওগুলো নাম, ফোল্ডার, সময়সহ দেখা যাবে। Search, Folder Filter, Newest/Name A–Z/Longest Sort থাকবে।

## ভিডিওর Resume
একটি ভিডিও চালিয়ে মাঝপথে বের হলে তার Playback Position ফোনের ভেতরে সংরক্ষিত থাকবে। আবার ভিডিওটিতে Tap করলে সেই জায়গা থেকে চালু হবে। আলাদা ভিডিওর Bookmark আলাদাভাবে সংরক্ষিত হয়। Long Press → Start from beginning করলে শুরু থেকে চলবে। শেষের খুব কাছে থাকা বা শেষ হওয়া ভিডিও আর Resume হবে না।

## Storage Permission
Android 13+ এ READ_MEDIA_VIDEO, Android 14+ এ READ_MEDIA_VISUAL_USER_SELECTED (ঐচ্ছিক Selected Video Access), Android 12L বা নিচে READ_EXTERNAL_STORAGE। পুরো ভিডিও দেখার জন্য Android-এর Full Video Access প্রয়োজন। অনুমতি না থাকলেও লাইব্রেরির “Select files manually” বাটন দিয়ে System File Picker থেকে নির্বাচিত ভিডিও খোলা যায়। কিছু MediaStore-এ ইনডেক্সবিহীন বা অন্য অ্যাপের private video list-এ থাকবে না।

## আগের ফিচার অক্ষত
MX-style full screen video UI, speed, subtitles, double tap seek, picture-in-picture, background audio, playlist, Night Screen, Extra Volume, Thermal Monitor, QR Scanner, Floating Panel এবং SR Branding রাখা হয়েছে।

## QA
Pure Java per-video Resume পরীক্ষার ১২টি Check PASS। Java Source/Android XML ও Workflow-এর স্থানীয় পরীক্ষা চলেছে। সম্পূর্ণ APK Build ও বাস্তব ফোনে Library/Resume পরীক্ষা এখানে সম্ভব হয়নি, GitHub Actions ও ফোনে করতে হবে।
