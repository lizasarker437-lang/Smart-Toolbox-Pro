# Smart Toolbox Pro 1.2.1-alpha4

Floating quick panel update:
- Added a Night Screen darkness slider to the floating panel (0–95%).
- Added an Extra Volume gain slider to the floating panel (0–10 dB).
- Both sliders save the chosen values even if their feature is currently off.
- When Night Screen is active, its overlay level updates while dragging the slider.
- When System-Wide Extra Volume is active and supported, gain updates while dragging.
- Slider updates are debounced while dragging and flushed on release.
- Floating panel is scrollable so controls remain reachable on smaller screens.
- Existing feature ON/OFF controls remain available.

Safety / compatibility:
- The Extra Volume slider controls the app-requested audio-effect gain, not Android's master volume slider.
- Global output-mix audio effects remain device/Android-version dependent.
- Night Screen adjusts the black overlay darkness, not the phone's hardware brightness setting.
