# Floating Sidebar — 1.2.8-alpha11

বাম প্রান্তের ট্যাব থেকে ডানে সোয়াইপ করে Floating Bubble বের করতে পারবেন।
ডান প্রান্তের ট্যাব থেকে বাঁয়ে সোয়াইপ করে Floating Bubble বের করতে পারবেন।
ট্যাবে ট্যাপ করলে সরাসরি Quick Panel খুলবে।
Auto-hide ON থাকলে প্যানেলে কাজ শেষে নির্ধারিত সময় পর Bubble আগের পাশেই সরে যাবে।
Tab-এর দৃশ্যমান প্রস্থ ৬–২৬ dp, কিন্তু সোয়াইপ ধরার Touch Area ৩২ dp; Android System Back Gesture নির্দিষ্ট ফোনে অগ্রাধিকার পেতে পারে।
