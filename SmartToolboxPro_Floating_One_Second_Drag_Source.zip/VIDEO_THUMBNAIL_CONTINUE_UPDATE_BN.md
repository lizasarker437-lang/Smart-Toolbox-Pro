# SR Smart Toolbox Pro — Video Folder List & Continue Watching (1.4.6-alpha21)

## ফোল্ডারের ভিতরে নতুন Video List
- Thumbnail: MediaStore থেকে 16:9 Video Thumbnail (ব্যাকগ্রাউন্ডে লোড হয়) এবং fallback placeholder।
- প্রতিটি Video Row-তে নাম, Video Duration Badge এবং ডান পাশে ⋮ Options।
- ⋮ Options: Continue playback / Start from beginning / Video details।
- আগের Playback Position থাকলে `Continue from mm:ss` দেখাবে।
- একই রঙ/Theme এবং Folders → Video List → Player প্রবাহ বজায় থাকবে।

## বড় ▶ Continue Watching Button
- ফোল্ডার ও ভিডিওর তালিকার নিচের ডানদিকে থাকে, তবে কোনো ভিডিও এখনো চালানো না হলে বাটন দেখাবে না।
- সর্বশেষ দেখা ভিডিওটির URI ও Playback Position আগের `sr_video_player` Preferences থেকে পড়বে।
- ▶ চাপলে File Picker ছাড়াই VideoPlayerActivity খুলে সর্বশেষ ভিডিওটি সংরক্ষিত জায়গা থেকে Play করবে।
- ভিডিওর একদম শেষে পৌঁছে থাকলে নতুন করে শুরু হবে।
- Permission হারানো / deleted video হলে Player-এর Error Handling কাজ করবে।

## Performance
- Thumbnail loading background thread pool (maximum 2 threads) + 8MB LRU cache।
- ListView Row Recycling-এ ভুল/পুরোনো Thumbnail বসবে না।
- Destroy হলে worker বন্ধ করা হয়।
- Android 10+ ContentResolver.loadThumbnail; Android 8–9 legacy MediaStore thumbnail fallback।

## আগের ফিচার
- Floating Swipe Animation, Video Resume, MX-style Player, Folder Search, 5 Themes, Night Screen,
  Extra Volume & Equalizer, Thermal Monitor, QR Scanner, Notification Settings, Three-dot Menu, SR Branding অক্ষত।

## Build Status
- GitHub-ready Source, versionCode 21 / 1.4.6-alpha21।
- Java syntax/AST, Source Assertions, Pure Java Resume Tests, XML, Workflow ও ZIP Integrity locally verified।
- Full Android APK Build এবং বাস্তব ফোনের Thumbnail / Resume / MediaStore পরীক্ষা বাকি; এই পরিবেশে Android SDK ও Gradle নেই।
