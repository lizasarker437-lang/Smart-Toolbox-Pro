# SR Smart Toolbox Pro 1.5.4-alpha30 — Smart Scheduler & Theme Studio

## Quick Message Templates
- The ⋮ menu contains Manage / Add Quick Templates.
- Add new template with a title (1–48 chars) and message (1–2000 chars).
- Edit or delete built-in and custom templates.
- Quick row displays the first three saved templates; More opens the complete picker.
- Applying a template supports Replace / Append / Cancel.
- Up to 50 templates are stored locally.

## Single and Group / Broadcast Messages
- Single mode accepts exactly one normalized WhatsApp number.
- Group / Broadcast mode accepts 2–20 unique numbers.
- Select many opens the phone contacts multi-choice picker; READ_CONTACTS is requested only after the user taps the button.
- Manually entered numbers can be separated by comma, semicolon, or new line.
- The same message is scheduled separately for each recipient as a one-to-one WhatsApp chat.
- Recipients have one shared due time. Accessibility handles individual WhatsApp chats through a bounded queue and cannot click Send simultaneously in multiple chats.
- This does not create a WhatsApp group chat. The user confirms the batch before it is saved.
- Each group member is shown under a saved group name; message history can be copied to a new schedule for editing while preserving the original record.
- Existing schedule records remain compatible; new optional batch metadata defaults safely for older records.

## Smart Theme Studio
- Nine palettes: Midnight Gold, Ocean Blue, Emerald Green, Royal Purple, Light Day, Sunset Coral, Graphite Cyan, Rose Quartz, Arctic Mint.
- Appearance mode is independent: System, Light, Dark.
- System mode follows Android's current night configuration.
- Theme selection is saved locally and re-applied across activities; Main and Scheduler recreate when the effective theme changes. Floating Toolbox and compact ON/OFF bars also refresh to the selected palette.
- Video playback keeps its dedicated black cinema canvas.

## Validation
- ThemePaletteTest, SchedulerDisplayLogicTest, RecipientSelectionLogicTest, SchedulerTemplateLogicTest, GroupScheduleLogicTest passed locally.
- Java AST/source syntax scan and Manifest / Workflow parsing passed.
- Full Android Gradle build and physical-device tests remain required in GitHub Actions / on-device.
