# Extra Volume & Equalizer — ব্যবহার নির্দেশিকা

1. Smart Toolbox Pro খুলুন।
2. `System-Wide Extra Volume` / Extra Volume Control সেকশনে প্রবেশ করুন।
3. `Master Volume Control` থেকে অতিরিক্ত global output gain নির্বাচন করুন।
4. `Sound Profile` থেকে Balanced, Bass Boost, Vocal, Rock, Classical, Treble বা Podcast বেছে নিতে পারেন।
5. নিজে সেট করতে পাঁচটি EQ slider ব্যবহার করুন:
   - Bass
   - Low Mid
   - Mid
   - High Mid
   - Treble
6. আলাদাভাবে Bass Boost এবং Virtualizer / Spatial Effect নিয়ন্ত্রণ করুন।
7. `Turn on Master Volume & Equalizer` চাপলে সেভ করা সব সেটিংস প্রয়োগের চেষ্টা হবে।
8. চালু থাকা অবস্থায় slider পরিবর্তন করলে সেটিংস live update হবে।
9. সব audio effect বন্ধ করতে `Turn off all audio processing` চাপুন।

গুরুত্বপূর্ণ:
- Android-এর global output-mix audio session 0 effects deprecated/restricted হতে পারে।
- তাই ফোনভেদে Master Gain, Equalizer, Bass Boost অথবা Virtualizer-এর কিছু নিয়ন্ত্রণ unavailable দেখাতে পারে।
- Unavailable দেখালে সেটি অ্যাপের slider সমস্যা নয়; Android/ফোনের audio effect implementation global control দেয়নি।
- বেশি gain দিলে শব্দ বিকৃত হতে পারে এবং শ্রবণক্ষতি হতে পারে। কম gain থেকে শুরু করুন।
