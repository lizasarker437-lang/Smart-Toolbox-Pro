# SR Smart Toolbox Pro — v1.5.8-alpha34

## All Apps Portrait Edge — YouTube, Gallery, যেকোনো ভিডিও প্লেয়ার

**Floating Icon Settings → Portrait Edge — ALL apps (YouTube, Gallery, other players)**

সুইচটি **ON** (ডিফল্ট) থাকলে Floating Service চলমান অবস্থায় স্ক্রিন Portrait হলেই আইকনটি ডান বা বাম **কিনারার ছোট Swipeable Tab** হয়ে যাবে। এতে ফোনের Gallery, YouTube, MX Player, VLC, Browser, Home Screen বা অন্য অ্যাপ খোলা থাকলেও একই আচরণ হবে। কোনো নির্দিষ্ট ভিডিও অ্যাপ শনাক্ত/মনিটর করার অনুমতি লাগে না।

**সীমা:** Android অন্য সব অ্যাপের ভিতরে ভিডিও সত্যিই Play হচ্ছে কি না নির্ভরযোগ্যভাবে জানায় না। তাই এই নতুন Mode শুধু Portrait Orientation অনুযায়ী কাজ করে—Portrait Home Screen-এও আইকন কিনারায় থাকবে। এটি কেবল ভিডিও চললে সক্রিয় হবে, এমন দাবি করা হচ্ছে না।

- আইকনটি আগে থেকে Hidden / OFF থাকলে নিজে থেকে ON করবে না। **Display over other apps** Permission ও Floating Service চালু থাকতে হবে।
- Portrait-এ Normal Bubble থেকে Edge Tab-এ যাওয়ার সময় আগের X/Y Position সংরক্ষণ হয়। Landscape-এ ফেরা বা All Apps mode OFF করা হলে আগের অবস্থানে ফেরার চেষ্টা হয়।
- আগে থেকেই Auto-hidden Edge Tab থাকলে পূর্বের Hidden অবস্থান অপরিবর্তিত থাকবে।
- Edge Tab-এ **Tap** বা **Inward Swipe** দিলে Toolbox খুলবে; কন্ট্রোলের কাজ শেষে আবার Edge-এ ফিরবে।
- Floating Icon Settings-এ পুরোনো **Built-in video edge** toggle এখন fallback: All Apps mode OFF থাকলে কেবল নিজের SR Video Player-এর Play/Pause Signal অনুযায়ী কাজ করবে।
- Android-এর Full Screen/DRM/Secure Window ও Overlay Policy এবং OEM Navigation Gesture-এর কারণে কোনো কোনো অ্যাপে Overlay আংশিক লুকানো বা Edge Swipe বাধাগ্রস্ত হতে পারে।

## টেকনিক্যাল পরিবর্তন
- `FloatingControlService`: `DisplayManager.DisplayListener`, `Service.onConfigurationChanged` এবং কম-ফ্রিকোয়েন্সির Orientation Fallback Monitor যুক্ত। অন্য অ্যাপেও Display Size/Orientation পরিবর্তন শনাক্ত করা যায়।
- `GlobalPortraitEdgeLogic`: Orientation, Permission, Floating Icon State, Panel Open/Close অনুযায়ী pure Java docking/undocking নিয়ম।
- Edge Tab-এর X/Y Rotation অনুযায়ী Clamp করা হয়। Forced docking-এর আগের Bubble Position আলাদাভাবে সংরক্ষিত; Service Restart-এর পর প্রয়োজন হলে Restore করা যায়।
- `FloatingIconSettingsActivity`: All Apps mode আলাদাভাবে ON/OFF। পুরোনো নিজস্ব Video Player integration রাখা হয়েছে।
- Scheduler Notepad, Schedule Inbox, WhatsApp Scheduler, Theme, Night Screen, Extra Volume, Video Player ও QR Scanner অপরিবর্তিত।

## Build ও QA সীমা
- ২২টি Global Portrait Edge Logic Assertions PASS।
- ২২টি GitHub Actions Pure Java/Source Verification Steps PASS।
- Java AST Syntax, XML, YAML, Shell Script Syntax যাচাই করা হয়েছে।
- Android SDK ও Gradle এখানে নেই; **সম্পূর্ণ APK Build এবং বাস্তব ডিভাইসে YouTube/Video Player Overlay আচরণ পরীক্ষা হয়নি**। GitHub Actions-এ `:app:assembleDebug` সফল হলে ফোনে অনুমতি দিয়ে পরীক্ষা করুন।
