# Java Compile Fix — Historical Note
আগের v1.2.7-alpha10-এ PanelSliderFormatter এবং PanelSliderListener Interface ফিরিয়ে আনা হয়েছে। এই দুটি Interface নতুন v1.2.8-alpha11-এও রাখা হয়েছে।
নতুন সংস্করণে Swipe Gesture, native Media Volume +/- এবং Brightness Removal-এর সংশোধনও রয়েছে।
সম্পূর্ণ Android SDK Gradle Compile এখনো GitHub Actions-এ যাচাই করতে হবে।
