# Floating Icon feedback ও মেনু আপডেট

- ২ সেকেন্ড ধরে রেখে drag শুরু হলে একবার vibration/sound/none feedback।
- Floating Icon Settings > Visibility-তে ON/OFF এবং feedback selector।
- থ্রি-ডট মেনুতে ৫টি মূল আইটেম।
- আগের Scheduler এবং Video Player পরিবর্তন সংরক্ষিত।

## যাচাই
- AndroidManifest XML parse সফল।
- সোর্স ফাইলের মৌলিক কাঠামো ও ZIP যাচাই সফল।
- Android SDK/Gradle রানটাইম অনুপস্থিত; APK compile ও ফোনে আচরণ পরীক্ষা করা সম্ভব হয়নি।
