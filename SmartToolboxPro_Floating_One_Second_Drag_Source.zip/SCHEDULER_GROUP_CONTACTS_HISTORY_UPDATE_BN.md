# SR Smart Toolbox Pro — 1.5.5-alpha31

## Contacts থেকে নম্বর যোগ
- Scheduler-এর **👤 From Contacts** বাটন: একটি নম্বর বাছুন।
- **👥 Select many Contacts**: Android `READ_CONTACTS` অনুমতি দিলে একাধিক নম্বর বেছে Group/Broadcast-এ যোগ হবে (সর্বোচ্চ ২০)।
- নম্বরগুলো ডুপ্লিকেট ছাড়া সংরক্ষিত হবে এবং Recent Recipients হিস্টোরি আগের মতো থাকবে।

## Group Name ও একসঙ্গে শিডিউল
- Group/Broadcast mode নির্বাচন করলে **Group name** আলাদা ঘরে লিখতে পারবেন, যেমন Family বা Office Team।
- ২–২০ জন প্রাপক যোগ করুন, মেসেজ ও একটি সময় নির্ধারণ করুন।
- **সব প্রাপকের `scheduledAtMillis` এক হবে।** আগের ইচ্ছাকৃত ৬০ সেকেন্ড ব্যবধান নেই।
- এই Group Name হল অ্যাপের **Broadcast Batch Label**। এটি নতুন WhatsApp Group Chat বানায় না।
- WhatsApp-এর প্রতিটি ব্যক্তিগত চ্যাট আলাদাভাবে খুলতে হয়। একই মুহূর্তে একসঙ্গে ২০টি Send ক্লিক সম্ভব নয়। স্বয়ংক্রিয় ব্যবস্থা চালু ও উপলভ্য থাকলে একটি Queue দিয়ে একটির পর আরেকটি Send চেষ্টা হবে, কোন বাধ্যতামূলক ৬০ সেকেন্ড বিরতি ছাড়াই।
- Accessibility Service অনুপলব্ধ থাকলে বা Automation ব্যর্থ হলে সংশ্লিষ্ট প্রাপকের জন্য Manual Reminder দেখাবে।
- Android-এর Exact Alarm/Doze সীমাবদ্ধতায় নির্ধারিত সময় একটু এদিক-সেদিক হতে পারে।

## Sent/Attempted History এডিট করে আবার ব্যবহার
- Scheduler Screen-এর **Scheduled messages & History** তালিকায় আগে Send Attempt বা Mark Sent করা রেকর্ড থাকবে।
- **✏ Edit message & schedule again** বাটন রেকর্ডের নম্বর, মেসেজ ও (থাকলে) Group Name এবং Group-এর নম্বরগুলো নতুন ফর্মে কপি করবে।
- ইচ্ছেমতো এডিট করে **নতুন** Schedule সেভ করতে পারবেন। পুরোনো History এবং Send Attempt Status অপরিবর্তিত থাকবে—পূর্বে পাঠানো মেসেজকে পরে পরিবর্তিত বলে দেখাবে না।
- Send Button-এ Accessibility Click করা মানেই WhatsApp ডেলিভারি নিশ্চিত নয়।

## পরীক্ষা ও সীমাবদ্ধতা
- Pure Java Group Time ও Queue Test, Java AST Syntax, XML এবং Workflow যাচাই হয়েছে।
- পূর্ণ Android APK Build ও ফোনে WhatsApp UI Automation পরীক্ষার জন্য Android SDK / GitHub Actions ও আসল ডিভাইস প্রয়োজন।
