package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;

/** Experimental automation is OFF by default and always requires explicit opt-in. */
final class AutoSendPreferences {
    private static final String FILE = "sr_wa_automation_v1";
    private static final String ENABLED = "auto.enabled";
    private static final String LOCKED = "unlock.experiment.enabled";
    private static final String RELOCK = "relock.after.locked";

    private AutoSendPreferences() { }
    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }
    static boolean enabled(Context c) { return prefs(c).getBoolean(ENABLED, false); }
    static void setEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean(ENABLED, enabled).apply();
    }
    static boolean experimentalUnlock(Context c) { return prefs(c).getBoolean(LOCKED, false); }
    static void setExperimentalUnlock(Context c, boolean value) {
        prefs(c).edit().putBoolean(LOCKED, value).apply();
    }
    static boolean relock(Context c) { return prefs(c).getBoolean(RELOCK, true); }
    static void setRelock(Context c, boolean value) {
        prefs(c).edit().putBoolean(RELOCK, value).apply();
    }
}
