package com.smarttoolbox.pro;

/** Android-free interpolation for the reveal animation; covered by local javac tests. */
final class BubbleSlideLogic {
    private BubbleSlideLogic() { }

    static int revealStartX(boolean leftSide, int screenWidth, int bubbleSize) {
        return leftSide ? -bubbleSize / 2 : Math.max(0, screenWidth - bubbleSize / 2);
    }

    static int interpolate(int from, int to, float fraction) {
        float t = Math.max(0f, Math.min(1f, fraction));
        return Math.round(from + (to - from) * t);
    }

    static float alpha(float initial, float target, float fraction) {
        float t = Math.max(0f, Math.min(1f, fraction));
        return initial + (target - initial) * t;
    }
}
