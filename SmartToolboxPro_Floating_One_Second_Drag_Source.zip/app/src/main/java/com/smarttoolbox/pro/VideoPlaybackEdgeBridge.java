package com.smarttoolbox.pro;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;

/** Call from the app's video player when playback actually starts/stops. */
public final class VideoPlaybackEdgeBridge {
    public static final String ACTION_VIDEO_START = "com.smarttoolbox.pro.FLOAT_PORTRAIT_VIDEO_START";
    public static final String ACTION_VIDEO_STOP = "com.smarttoolbox.pro.FLOAT_PORTRAIT_VIDEO_STOP";
    private VideoPlaybackEdgeBridge() { }

    public static void onPlaying(Context context) {
        if (context.getResources().getConfiguration().orientation
                != Configuration.ORIENTATION_PORTRAIT) return;
        emit(context, ACTION_VIDEO_START);
    }

    public static void onStopped(Context context) {
        emit(context, ACTION_VIDEO_STOP);
    }

    private static void emit(Context context, String action) {
        android.content.SharedPreferences state = context.getSharedPreferences("tool_state", Context.MODE_PRIVATE);
        if (!state.getBoolean("floating.enabled", true)
                || state.getBoolean("floating.hidden", false)) return;
        if (!FloatingControlService.hasOverlayPermission(context)) return;
        Intent service = new Intent(context, FloatingControlService.class).setAction(action);
        try {
            // Only called by the app's foreground video player Activity.
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        } catch (Exception ignored) { /* Android may disallow a background start. */ }
    }
}
