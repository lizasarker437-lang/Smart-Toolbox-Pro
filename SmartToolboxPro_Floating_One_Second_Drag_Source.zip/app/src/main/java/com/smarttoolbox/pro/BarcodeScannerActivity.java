package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

/**
 * QR and barcode scanner powered by Google Code Scanner.
 * The camera UI is provided by Google Play services, so this activity does not
 * need to request the CAMERA permission or handle camera frames itself.
 */
public class BarcodeScannerActivity extends Activity {
    private TextView statusLabel;
    private TextView formatLabel;
    private TextView valueLabel;
    private Button scanButton;
    private Button copyButton;
    private Button shareButton;
    private Button openLinkButton;
    private String lastScannedValue;

    @Override public void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyToActivity(this);
        super.onCreate(savedInstanceState);

        LinearLayout page = Ui.page(this, "QR & Barcode Scanner");
        LinearLayout body = Ui.content(page);

        LinearLayout intro = Ui.card(this);
        Ui.addText(this, intro, "Scan QR codes and barcodes", 19, Ui.TEXT, true, 0);
        Ui.addText(this, intro,
                "Use your camera to scan QR, EAN, UPC, Code 128, Code 39, PDF417, Aztec and other supported barcode formats.",
                13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, intro, 16);

        scanButton = Ui.button(this, "▦  Scan QR / Barcode", this::startScan);
        Ui.addCard(this, body, scanButton, 12);

        LinearLayout resultCard = Ui.card(this);
        Ui.addText(this, resultCard, "Scan result", 18, Ui.ACCENT, true, 0);
        statusLabel = Ui.addText(this, resultCard,
                "Ready to scan. Tap the button above to open the scanner.",
                13, Ui.MUTED, false, 8);
        formatLabel = Ui.addText(this, resultCard, "Format: —", 13, Ui.TEXT, true, 10);
        valueLabel = Ui.addText(this, resultCard, "No code scanned yet.", 14, Ui.TEXT, false, 8);
        valueLabel.setTextIsSelectable(true);
        valueLabel.setBackgroundColor(Color.TRANSPARENT);
        Ui.addCard(this, body, resultCard, 14);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        copyButton = Ui.button(this, "Copy result", this::copyResult);
        shareButton = Ui.button(this, "Share result", this::shareResult);
        openLinkButton = Ui.button(this, "Open link", this::openScannedLink);
        copyButton.setVisibility(View.GONE);
        shareButton.setVisibility(View.GONE);
        openLinkButton.setVisibility(View.GONE);
        actions.addView(copyButton, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(-1, -2);
        shareParams.topMargin = Ui.dp(this, 8);
        actions.addView(shareButton, shareParams);
        LinearLayout.LayoutParams linkParams = new LinearLayout.LayoutParams(-1, -2);
        linkParams.topMargin = Ui.dp(this, 8);
        actions.addView(openLinkButton, linkParams);
        Ui.addCard(this, body, actions, 10);

        LinearLayout privacy = Ui.card(this);
        Ui.addText(this, privacy, "Private on-device scanning", 15, Ui.ACCENT, true, 0);
        Ui.addText(this, privacy,
                "The scanner runs on the device through Google Play services. SR Smart Toolbox receives the decoded text only; it does not save a photo of the scanned code.",
                13, Ui.MUTED, false, 8);
        Ui.addCard(this, body, privacy, 18);

        setContentView(page);
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("scanner.active", true).apply();
        if (FloatingControlService.hasOverlayPermission(this)) {
            FloatingControlService.start(this);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("scanner.active", false)
                && FloatingControlService.hasOverlayPermission(this)) {
            FloatingControlService.refresh(this);
        }
    }

    @Override protected void onDestroy() {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("scanner.active", false).apply();
        super.onDestroy();
        FloatingControlService.refresh(this);
    }

    private void startScan() {
        statusLabel.setText("Opening secure scanner…");
        scanButton.setEnabled(false);
        try {
            // Google Code Scanner supports all barcode formats by default.
            GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                    .enableAutoZoom()
                    .build();
            GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
            scanner.startScan()
                    .addOnSuccessListener(barcode -> {
                        scanButton.setEnabled(true);
                        showScanResult(barcode);
                    })
                    .addOnCanceledListener(() -> {
                        scanButton.setEnabled(true);
                        statusLabel.setText("Scan cancelled. Tap Scan to try again.");
                    })
                    .addOnFailureListener(error -> {
                        scanButton.setEnabled(true);
                        String detail = error.getLocalizedMessage();
                        statusLabel.setText("Scanner could not start. Check that Google Play services is enabled and updated."
                                + ((detail == null || detail.trim().isEmpty()) ? "" : "\n" + detail));
                        Toast.makeText(this, "Could not start QR / barcode scanner.", Toast.LENGTH_LONG).show();
                    });
        } catch (Exception error) {
            scanButton.setEnabled(true);
            statusLabel.setText("Scanner could not start. Please check Google Play services and try again.");
            Toast.makeText(this, "Could not start QR / barcode scanner.", Toast.LENGTH_LONG).show();
        }
    }

    private void showScanResult(Barcode barcode) {
        if (barcode == null) {
            statusLabel.setText("No code was returned. Please scan again.");
            return;
        }
        String raw = barcode.getRawValue();
        if (raw == null || raw.trim().isEmpty()) raw = barcode.getDisplayValue();
        if (raw == null || raw.trim().isEmpty()) {
            statusLabel.setText("A code was detected, but it did not contain readable text.");
            return;
        }

        lastScannedValue = raw;
        statusLabel.setText("Scan successful.");
        formatLabel.setText("Format: " + formatName(barcode.getFormat()));
        valueLabel.setText(raw);
        copyButton.setVisibility(View.VISIBLE);
        shareButton.setVisibility(View.VISIBLE);
        openLinkButton.setVisibility(isHttpLink(raw) ? View.VISIBLE : View.GONE);
    }

    private String formatName(int format) {
        switch (format) {
            case Barcode.FORMAT_QR_CODE: return "QR Code";
            case Barcode.FORMAT_AZTEC: return "Aztec";
            case Barcode.FORMAT_CODE_128: return "Code 128";
            case Barcode.FORMAT_CODE_39: return "Code 39";
            case Barcode.FORMAT_CODE_93: return "Code 93";
            case Barcode.FORMAT_CODABAR: return "Codabar";
            case Barcode.FORMAT_DATA_MATRIX: return "Data Matrix";
            case Barcode.FORMAT_EAN_13: return "EAN-13";
            case Barcode.FORMAT_EAN_8: return "EAN-8";
            case Barcode.FORMAT_ITF: return "ITF";
            case Barcode.FORMAT_PDF417: return "PDF417";
            case Barcode.FORMAT_UPC_A: return "UPC-A";
            case Barcode.FORMAT_UPC_E: return "UPC-E";
            default: return "Other barcode";
        }
    }

    private boolean isHttpLink(String value) {
        try {
            Uri uri = Uri.parse(value.trim());
            String scheme = uri.getScheme();
            return scheme != null && ("http".equalsIgnoreCase(scheme)
                    || "https".equalsIgnoreCase(scheme)) && uri.getHost() != null;
        } catch (Exception ignored) {
            return false;
        }
    }

    private void copyResult() {
        if (lastScannedValue == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("Scanned code", lastScannedValue));
            Toast.makeText(this, "Result copied.", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareResult() {
        if (lastScannedValue == null) return;
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, lastScannedValue);
        startActivity(Intent.createChooser(share, "Share scanned code"));
    }

    private void openScannedLink() {
        if (lastScannedValue == null || !isHttpLink(lastScannedValue)) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(lastScannedValue.trim())));
        } catch (Exception error) {
            Toast.makeText(this, "No browser is available to open this link.", Toast.LENGTH_LONG).show();
        }
    }
}
