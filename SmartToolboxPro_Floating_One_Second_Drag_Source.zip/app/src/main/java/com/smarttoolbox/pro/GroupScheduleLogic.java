package com.smarttoolbox.pro;

/** A named broadcast batch has ONE due time; WhatsApp chats are opened in sequence. */
final class GroupScheduleLogic {
    static final int MIN_RECIPIENTS = 2;
    static final int MAX_RECIPIENTS = 20;
    private GroupScheduleLogic() {}
    static boolean validCount(int count) { return count >= MIN_RECIPIENTS && count <= MAX_RECIPIENTS; }
    static long scheduledAt(long baseMillis, int zeroBasedIndex) {
        // All recipient reminders are due together; Android alarms can still be delayed.
        return baseMillis;
    }
    static boolean allTimesFuture(long baseMillis, int count, long nowMillis) {
        return validCount(count) && baseMillis > nowMillis && baseMillis - nowMillis > 1000L;
    }
    static String cleanGroupName(String name) {
        if (name == null) return "";
        String clean = name.trim().replaceAll("\\s+", " ");
        return clean.length() > 50 ? clean.substring(0, 50).trim() : clean;
    }
    static String displayName(String name) {
        String clean = cleanGroupName(name);
        return clean.isEmpty() ? "Broadcast group" : clean;
    }
    static String recipientPosition(int oneBasedIndex, int total) {
        int safeTotal = Math.max(1, total);
        int safeIndex = Math.max(1, Math.min(oneBasedIndex, safeTotal));
        return "👥 Broadcast · " + safeIndex + "/" + safeTotal;
    }
}
