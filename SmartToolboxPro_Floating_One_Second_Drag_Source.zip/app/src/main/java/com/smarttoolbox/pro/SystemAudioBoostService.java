package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.media.audiofx.Virtualizer;
import android.os.Build;
import android.os.IBinder;

public class SystemAudioBoostService extends Service {
    public static final String ACTION_START = "com.smarttoolbox.pro.SYSTEM_AUDIO_START";
    public static final String ACTION_UPDATE = "com.smarttoolbox.pro.SYSTEM_AUDIO_UPDATE";
    public static final String ACTION_UPDATE_EQ = "com.smarttoolbox.pro.SYSTEM_AUDIO_UPDATE_EQ";
    public static final String ACTION_MASTER_ON = "com.smarttoolbox.pro.SYSTEM_AUDIO_MASTER_ON";
    public static final String ACTION_MASTER_OFF = "com.smarttoolbox.pro.SYSTEM_AUDIO_MASTER_OFF";
    public static final String ACTION_STOP = "com.smarttoolbox.pro.SYSTEM_AUDIO_STOP";
    public static final String EXTRA_GAIN_MB = "system_gain_millibels";

    private static final String CHANNEL_ID = "system_audio_boost";
    private static final int NOTIFICATION_ID = 2404;
    private static final int MAX_GAIN_MB = 1000;
    private static final int BAND_COUNT = 5;

    private LoudnessEnhancer loudnessEnhancer;
    private Equalizer equalizer;
    private BassBoost bassBoost;
    private Virtualizer virtualizer;

    private boolean masterSupported;
    private boolean equalizerSupported;
    private boolean bassSupported;
    private boolean virtualizerSupported;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopAudioProcessing(startId);
            return START_NOT_STICKY;
        }

        int savedGain = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getInt("audio.gain", 400);
        int gainMb = intent == null ? savedGain
                : Math.max(0, Math.min(MAX_GAIN_MB,
                        intent.getIntExtra(EXTRA_GAIN_MB, savedGain)));

        startAsForeground("Applying system audio enhancements…");

        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);

        if (ACTION_START.equals(action)) {
            prefs.edit().putInt("audio.gain", gainMb)
                    .putBoolean("audio.master.enabled", true).apply();
            applyMasterGain(gainMb);
            applyEqualizerSettings();
        } else if (action == null) {
            // START_STICKY recreation must restore the user's previous Master ON/OFF state.
            if (prefs.getBoolean("audio.master.enabled", true)) {
                applyMasterGain(savedGain);
            } else {
                releaseMasterEffect();
                masterSupported = false;
            }
            applyEqualizerSettings();
        } else if (ACTION_MASTER_ON.equals(action)) {
            prefs.edit().putBoolean("audio.master.enabled", true).apply();
            applyMasterGain(savedGain);
            applyEqualizerSettings();
        } else if (ACTION_MASTER_OFF.equals(action)) {
            prefs.edit().putBoolean("audio.master.enabled", false).apply();
            releaseMasterEffect();
            masterSupported = false;
            applyEqualizerSettings();
        } else if (ACTION_UPDATE.equals(action)) {
            prefs.edit().putInt("audio.gain", gainMb).apply();
            if (prefs.getBoolean("audio.master.enabled", true)) {
                applyMasterGain(gainMb);
            } else {
                releaseMasterEffect();
                masterSupported = false;
            }
            // If Android recreated the service and delivered an update action,
            // restore the saved EQ controls as well as the master gain.
            applyEqualizerSettings();
        } else if (ACTION_UPDATE_EQ.equals(action)) {
            // Re-apply the saved master gain too if Android recreated the service.
            if (prefs.getBoolean("audio.master.enabled", true)) {
                applyMasterGain(savedGain);
            } else {
                releaseMasterEffect();
                masterSupported = false;
            }
            applyEqualizerSettings();
        } else {
            if (prefs.getBoolean("audio.master.enabled", true)) {
                applyMasterGain(gainMb);
            } else {
                releaseMasterEffect();
                masterSupported = false;
            }
            applyEqualizerSettings();
        }

        boolean anySupported = masterSupported || equalizerSupported
                || bassSupported || virtualizerSupported;

        String status = buildStatusMessage();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("audio.active", anySupported)
                .putBoolean("audio.unsupported", !anySupported)
                .putBoolean("audio.master.supported", masterSupported)
                .putBoolean("audio.eq.supported", equalizerSupported)
                .putBoolean("audio.bass.supported", bassSupported)
                .putBoolean("audio.virtualizer.supported", virtualizerSupported)
                .putString("audio.status", status)
                .apply();

        if (anySupported) {
            String level = String.format(java.util.Locale.getDefault(),
                    "Master +%.1f dB · EQ / effects", gainMb / 100f);
            updateNotification(level);
            if (FloatingControlService.hasOverlayPermission(this)) {
                FloatingControlService.start(this);
            }
            return START_STICKY;
        }

        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("audio.master.enabled", false)
                .putBoolean("audio.master.supported", false)
                .putString("audio.status", "No global audio effects are supported on this device.")
                .apply();
        updateNotification("Global audio effects are not supported on this device.");
        stopForeground(true);
        stopSelf(startId);
        FloatingControlService.refresh(this);
        return START_NOT_STICKY;
    }

    private void applyMasterGain(int gainMb) {
        masterSupported = false;
        try {
            if (loudnessEnhancer == null) {
                // Session 0 requests processing of the global output mix.
                // Android or the device manufacturer may deny this on some phones.
                loudnessEnhancer = new LoudnessEnhancer(0);
            }
            if (!loudnessEnhancer.hasControl()) {
                throw new IllegalStateException("No control of the global output gain effect.");
            }
            loudnessEnhancer.setTargetGain(Math.max(0, Math.min(MAX_GAIN_MB, gainMb)));
            loudnessEnhancer.setEnabled(true);
            masterSupported = true;
        } catch (Exception error) {
            releaseMasterEffect();
        }
    }

    private void applyEqualizerSettings() {
        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);

        applyFiveBandEqualizer(prefs);
        applyBassBoost(prefs.getInt("audio.bass", 0));
        applyVirtualizer(prefs.getInt("audio.virtualizer", 0));
    }

    private void applyFiveBandEqualizer(android.content.SharedPreferences prefs) {
        equalizerSupported = false;
        try {
            if (equalizer == null) {
                equalizer = new Equalizer(0, 0);
            }
            if (!equalizer.hasControl()) {
                throw new IllegalStateException("No control of the global equalizer.");
            }

            short bandCount = equalizer.getNumberOfBands();
            short[] range = equalizer.getBandLevelRange();
            if (bandCount <= 0 || range == null || range.length < 2) {
                throw new IllegalStateException("The device did not expose equalizer bands.");
            }

            int minimum = range[0];
            int maximum = range[1];

            // The app exposes five familiar bands. Their values are interpolated
            // across however many hardware EQ bands this phone actually provides.
            for (int hardwareBand = 0; hardwareBand < bandCount; hardwareBand++) {
                float virtualPosition = bandCount == 1
                        ? 2f : hardwareBand * (BAND_COUNT - 1f) / (bandCount - 1f);
                int lower = Math.max(0, Math.min(BAND_COUNT - 1, (int) Math.floor(virtualPosition)));
                int upper = Math.max(0, Math.min(BAND_COUNT - 1, (int) Math.ceil(virtualPosition)));
                float fraction = virtualPosition - lower;

                int lowDb = prefs.getInt("audio.eq.band." + lower, 0);
                int highDb = prefs.getInt("audio.eq.band." + upper, 0);
                float db = lowDb + (highDb - lowDb) * fraction;
                int millibels = Math.round(db * 100f);
                millibels = Math.max(minimum, Math.min(maximum, millibels));

                equalizer.setBandLevel((short) hardwareBand, (short) millibels);
            }
            equalizer.setEnabled(true);
            equalizerSupported = true;
        } catch (Exception error) {
            releaseEqualizer();
        }
    }

    private void applyBassBoost(int strength) {
        bassSupported = false;
        try {
            if (bassBoost == null) {
                bassBoost = new BassBoost(0, 0);
            }
            if (!bassBoost.hasControl() || !bassBoost.getStrengthSupported()) {
                throw new IllegalStateException("Bass Boost is not supported by this device.");
            }
            short safeStrength = (short) Math.max(0, Math.min(1000, strength));
            bassBoost.setStrength(safeStrength);
            bassBoost.setEnabled(safeStrength > 0);
            bassSupported = true;
        } catch (Exception error) {
            releaseBassBoost();
        }
    }

    private void applyVirtualizer(int strength) {
        virtualizerSupported = false;
        try {
            if (virtualizer == null) {
                virtualizer = new Virtualizer(0, 0);
            }
            if (!virtualizer.hasControl() || !virtualizer.getStrengthSupported()) {
                throw new IllegalStateException("Virtualizer is not supported by this device.");
            }
            short safeStrength = (short) Math.max(0, Math.min(1000, strength));
            virtualizer.setStrength(safeStrength);
            virtualizer.setEnabled(safeStrength > 0);
            virtualizerSupported = true;
        } catch (Exception error) {
            releaseVirtualizer();
        }
    }

    private String buildStatusMessage() {
        StringBuilder message = new StringBuilder();
        boolean masterRequested = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.master.enabled", true);
        if (!masterRequested) {
            if (message.length() > 0) message.append(" · ");
            message.append("Master output boost off");
        } else {
            appendStatus(message, masterSupported, "Master output boost");
        }
        appendStatus(message, equalizerSupported, "5-band equalizer");
        appendStatus(message, bassSupported, "Bass Boost");
        appendStatus(message, virtualizerSupported, "Virtualizer");
        return message.length() == 0
                ? "This phone does not expose supported global audio effects."
                : message.toString();
    }

    private void appendStatus(StringBuilder builder, boolean supported, String name) {
        if (builder.length() > 0) builder.append(" · ");
        builder.append(name).append(supported ? " active" : " unavailable");
    }

    private void stopAudioProcessing(int startId) {
        releaseAllEffects();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("audio.active", false)
                .putBoolean("audio.master.supported", false)
                .putBoolean("audio.eq.supported", false)
                .putBoolean("audio.bass.supported", false)
                .putBoolean("audio.virtualizer.supported", false)
                .putBoolean("audio.unsupported", false)
                .putBoolean("audio.master.enabled", false)
                .putString("audio.status", "All audio processing is off.")
                .apply();
        stopForeground(true);
        stopSelf(startId);
        FloatingControlService.refresh(this);
    }

    private void releaseMasterEffect() {
        if (loudnessEnhancer != null) {
            try { loudnessEnhancer.setEnabled(false); } catch (Exception ignored) {}
            try { loudnessEnhancer.release(); } catch (Exception ignored) {}
            loudnessEnhancer = null;
        }
    }

    private void releaseEqualizer() {
        if (equalizer != null) {
            try { equalizer.setEnabled(false); } catch (Exception ignored) {}
            try { equalizer.release(); } catch (Exception ignored) {}
            equalizer = null;
        }
    }

    private void releaseBassBoost() {
        if (bassBoost != null) {
            try { bassBoost.setEnabled(false); } catch (Exception ignored) {}
            try { bassBoost.release(); } catch (Exception ignored) {}
            bassBoost = null;
        }
    }

    private void releaseVirtualizer() {
        if (virtualizer != null) {
            try { virtualizer.setEnabled(false); } catch (Exception ignored) {}
            try { virtualizer.release(); } catch (Exception ignored) {}
            virtualizer = null;
        }
    }

    private void releaseAllEffects() {
        releaseMasterEffect();
        releaseEqualizer();
        releaseBassBoost();
        releaseVirtualizer();
        masterSupported = false;
        equalizerSupported = false;
        bassSupported = false;
        virtualizerSupported = false;
    }

    private void startAsForeground(String message) {
        Notification notification = buildNotification(message);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "System audio controls", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shown while user-enabled global audio enhancements are active.");
            NotificationManager manager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String message) {
        Intent stopIntent = new Intent(this, SystemAudioBoostService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 2404, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Extra Volume & Equalizer")
                .setContentText(message)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Turn off", stopPending)
                .build();
    }

    private void updateNotification(String message) {
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(message));
    }

    @Override public void onDestroy() {
        releaseAllEffects();
        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        if (prefs.getBoolean("audio.active", false)) {
            prefs.edit().putBoolean("audio.active", false)
                    .putString("audio.status",
                            "Global audio processing stopped by Android or the system.")
                    .apply();
        }
        super.onDestroy();
        FloatingControlService.refresh(this);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
