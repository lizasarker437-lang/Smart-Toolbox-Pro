package com.smarttoolbox.pro;

/** Pure validation rules for user-created quick message templates. */
final class SchedulerTemplateLogic {
    private SchedulerTemplateLogic() {}
    static boolean isValid(String title, String message) {
        return title != null && !title.trim().isEmpty() && title.trim().length() <= 48
                && message != null && !message.trim().isEmpty() && message.trim().length() <= 2000;
    }
    static String cleanTitle(String title) { return title == null ? "" : title.trim(); }
    static String cleanMessage(String message) { return message == null ? "" : message.trim(); }
}
