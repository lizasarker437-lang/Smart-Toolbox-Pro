package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

public class ThermalMonitorService extends Service {
    public static final String ACTION_STOP = "com.smarttoolbox.pro.STOP_THERMAL";
    private static final String CHANNEL_ID = "thermal_monitor";
    private static final int NOTIFICATION_ID = 2402;

    private PowerManager powerManager;
    private boolean receiverRegistered;
    private int batteryTemperatureTenths = -1;
    private int thermalStatus = -1;

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            batteryTemperatureTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            saveThermalSnapshot();
            updateNotification();
        }
    };

    private final PowerManager.OnThermalStatusChangedListener thermalListener =
            status -> {
                thermalStatus = status;
                saveThermalSnapshot();
                updateNotification();
            };

    @Override public void onCreate() {
        super.onCreate();
        powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("thermal.active", false).apply();
            stopMonitoring();
            stopForeground(true);
            stopSelf(startId);
            FloatingControlService.refresh(this);
            return START_NOT_STICKY;
        }

        startAsForeground();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("thermal.active", true).apply();

        if (!receiverRegistered) {
            Intent sticky = registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            receiverRegistered = true;
            if (sticky != null) {
                batteryTemperatureTenths = sticky.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            }
            saveThermalSnapshot();
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null && thermalStatus < 0) {
            thermalStatus = powerManager.getCurrentThermalStatus();
            powerManager.addThermalStatusListener(thermalListener);
            saveThermalSnapshot();
        }

        updateNotification();
        FloatingControlService.start(this);
        return START_STICKY;
    }

    private void startAsForeground() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void stopMonitoring() {
        if (receiverRegistered) {
            try { unregisterReceiver(batteryReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
            try { powerManager.removeThermalStatusListener(thermalListener); } catch (Exception ignored) {}
        }
    }

    private String thermalLabel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || thermalStatus < 0) return "Thermal status unavailable";
        switch (thermalStatus) {
            case PowerManager.THERMAL_STATUS_NONE: return "Normal";
            case PowerManager.THERMAL_STATUS_LIGHT: return "Light";
            case PowerManager.THERMAL_STATUS_MODERATE: return "Moderate";
            case PowerManager.THERMAL_STATUS_SEVERE: return "Severe";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "Critical";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "Emergency";
            default: return "Shutdown threshold";
        }
    }

    private String batteryLabel() {
        if (batteryTemperatureTenths < 0) return "Battery temperature unavailable";
        return String.format(java.util.Locale.getDefault(), "Battery %.1f °C", batteryTemperatureTenths / 10f);
    }

    private void saveThermalSnapshot() {
        String battery = batteryLabel();
        String status = thermalLabel();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putString("thermal.battery", battery)
                .putString("thermal.status", status)
                .apply();
    }

    private void updateNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Thermal monitor", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Ongoing device thermal monitoring.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, ThermalMonitorService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 2402, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("Thermal Monitor is active")
                .setContentText(batteryLabel() + " · " + thermalLabel())
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending)
                .build();
    }

    @Override public void onDestroy() {
        stopMonitoring();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("thermal.active", false).apply();
        super.onDestroy();
        FloatingControlService.refresh(this);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
