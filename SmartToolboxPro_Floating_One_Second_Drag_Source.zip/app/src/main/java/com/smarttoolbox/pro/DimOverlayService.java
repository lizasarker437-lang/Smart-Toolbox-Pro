package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

public class DimOverlayService extends Service {
    public static final String ACTION_STOP = "com.smarttoolbox.pro.STOP_DIM";
    private static final String CHANNEL = "night_overlay";
    private static final int NOTIFICATION_ID = 2101;
    private WindowManager windowManager;
    private FrameLayout overlay;
    private View dimView;
    private View warmView;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            removeOverlay();
            NightBrightnessController.restore(this);
            getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", false).apply();
            stopForeground(true);
            stopSelf();
            FloatingControlService.refresh(this);
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification());
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            NightBrightnessController.restore(this);
            getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", false).apply();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        int savedLevel = getSharedPreferences("night", MODE_PRIVATE).getInt("level", 60);
        int level = intent == null ? savedLevel : intent.getIntExtra("level", savedLevel);
        boolean savedWarm = getSharedPreferences("night", MODE_PRIVATE).getBoolean("warm", false);
        boolean warm = intent == null ? savedWarm : intent.getBooleanExtra("warm", savedWarm);
        if (!showOverlay(level, warm)) {
            NightBrightnessController.restore(this);
            getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", false).apply();
            stopForeground(true);
            stopSelf(startId);
            FloatingControlService.refresh(this);
            return START_NOT_STICKY;
        }
        if (getSharedPreferences("night", MODE_PRIVATE)
                .getBoolean("min_system_brightness", true)) {
            // This is optional. Without user-granted WRITE_SETTINGS the overlay still works.
            NightBrightnessController.applyMinimum(this);
        } else {
            NightBrightnessController.restore(this);
        }
        getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", true).apply();
        return START_STICKY;
    }

    private boolean showOverlay(int level, boolean warm) {
        if (overlay == null) {
            overlay = new FrameLayout(this);
            dimView = new View(this);
            warmView = new View(this);
            overlay.addView(dimView, new FrameLayout.LayoutParams(-1, -1));
            overlay.addView(warmView, new FrameLayout.LayoutParams(-1, -1));
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            // Android 12+ may drop touches under nearly-opaque untrusted overlays.
            // Keep the WINDOW alpha below its 0.8 pass-through threshold. The
            // physical backlight can be lowered separately with user permission.
            params.alpha = NightBrightnessPolicy.SAFE_OVERLAY_WINDOW_ALPHA;
            try { windowManager.addView(overlay, params); }
            catch (Exception e) {
                overlay = null;
                dimView = null;
                warmView = null;
                return false;
            }
        }
        dimView.setBackgroundColor(Color.BLACK);
        dimView.setAlpha(NightBrightnessPolicy.overlayViewAlpha(level));
        warmView.setBackgroundColor(Color.rgb(255, 164, 70));
        warmView.setAlpha(warm ? 0.10f : 0f);
        return true;
    }

    private void removeOverlay() {
        if (overlay != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) {}
            overlay = null;
            dimView = null;
            warmView = null;
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Night Screen", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the screen dimming overlay active while you use other apps.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Intent stop = new Intent(this, DimOverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, 2101, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, NightScreenActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent openAction = PendingIntent.getActivity(this, 2102, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return b.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Night Screen · Extra dark")
                .setContentText("Tap to adjust. Turn off to restore previous brightness.")
                .setContentIntent(openAction)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel,
                        "Turn off & restore", stopAction)
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        removeOverlay();
        NightBrightnessController.restore(this);
        getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", false).apply();
        super.onDestroy();
        FloatingControlService.refresh(this);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
