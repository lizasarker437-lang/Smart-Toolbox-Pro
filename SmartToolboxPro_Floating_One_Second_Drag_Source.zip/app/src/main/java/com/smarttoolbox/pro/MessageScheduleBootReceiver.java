package com.smarttoolbox.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restores pending message reminders after reboot or app replacement. */
public final class MessageScheduleBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            MessageScheduleStore.rescheduleAll(context.getApplicationContext());
        }
    }
}
