package com.smarttoolbox.pro;

/** Playback intent when leaving the video screen; no Android dependencies. */
final class VideoExitPolicy {
    private VideoExitPolicy() { }

    static boolean shouldStopPlayback(boolean keepAudio) {
        return !keepAudio;
    }

    static boolean canKeepAudio(boolean hasSelectedVideo) {
        return hasSelectedVideo;
    }

    static boolean mayAutoEnterPictureInPicture(boolean deliberatelyExiting) {
        return !deliberatelyExiting;
    }
}
