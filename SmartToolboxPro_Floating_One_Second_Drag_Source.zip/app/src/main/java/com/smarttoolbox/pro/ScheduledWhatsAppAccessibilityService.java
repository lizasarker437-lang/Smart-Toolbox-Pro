package com.smarttoolbox.pro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Explicitly user-enabled experimental UI automation for one saved WhatsApp
 * recipient at a time. Broadcast batches share one due time and enter a guarded
 * queue (no forced 60-second delay); UI clicks cannot happen simultaneously.
 * No arbitrary message interception or PIN logging.
 * It cannot bypass secure keyguard: its one PIN attempt only uses the owner's real
 * credentials on an accessible keypad and can fail on any OEM. Never reports
 * WhatsApp delivery based on an accessibility click alone.
 */
public final class ScheduledWhatsAppAccessibilityService extends AccessibilityService {
    private static volatile ScheduledWhatsAppAccessibilityService connected;
    private static final long RETRY_MS = 550L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MessageScheduleStore.Item active;
    private final ArrayDeque<MessageScheduleStore.Item> queuedBatchItems = new ArrayDeque<>();
    private String batchInProgress = "";
    private String preparedId;
    private boolean preparedWasLocked;
    /** Empty string means the user was on Home; never revive a stale app in this case. */
    private String priorPackage = "";
    private String lastForegroundPackage = "";
    private String resolvedHomePackage = "";
    private String previewId;
    private long previewDeadlineElapsed;
    private TextView previewCountdownText;
    private String waitingCountdownId;
    private Runnable waitingCountdownAction;
    private final Runnable previewTicker = new Runnable() {
        @Override public void run() {
            if (previewOverlay == null || previewCountdownText == null) return;
            int seconds = SchedulerForegroundLogic.displaySeconds(
                    previewDeadlineElapsed, SystemClock.elapsedRealtime());
            if (seconds > 0) {
                previewCountdownText.setText("" + seconds);
                handler.postDelayed(this, 110L);
            } else {
                previewCountdownText.setText("✓");
            }
        }
    };
    private String canceledId;
    /** Cancelling one batch preview cancels automatic send for the entire group. */
    private String canceledBatchId = "";
    private long canceledBatchDueAt;
    private boolean running;
    /** Prevents a new due alarm from starting another session mid-batch handoff. */
    private boolean batchHandoffPending;
    private boolean enteredPin;
    private boolean sendClicked;
    private int keypadCheckCount;
    private long dueAt;
    private long timeoutAt;
    private WindowManager overlayManager;
    private LinearLayout previewOverlay;
    private PowerManager.WakeLock wakeLock;

    static boolean isConnected() { return connected != null; }

    static boolean preview(Context context, MessageScheduleStore.Item item) {
        ScheduledWhatsAppAccessibilityService service = connected;
        if (service == null || !AutoSendPreferences.enabled(context)) return false;
        service.handler.post(() -> service.prepare(item));
        return true;
    }

    static boolean sendWhenDue(Context context, MessageScheduleStore.Item item) {
        ScheduledWhatsAppAccessibilityService service = connected;
        if (service == null || !AutoSendPreferences.enabled(context)) return false;
        service.handler.post(() -> service.begin(item));
        return true;
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        connected = this;
        resolveDefaultHome();
    }

    private void resolveDefaultHome() {
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo result = getPackageManager().resolveActivity(home, 0);
            if (result != null && result.activityInfo != null) {
                resolvedHomePackage = result.activityInfo.packageName;
            }
        } catch (Exception ignored) { }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence source = event.getPackageName();
        String pkg = source == null ? "" : source.toString();
        // Track actual HOME as well as apps. Previous code ignored launchers, so it
        // could reopen a stale app after a message was sent while Home was visible.
        if (!running && waitingCountdownId == null && !pkg.isEmpty()
                && !pkg.equals(getPackageName()) && !isSystemUi(pkg)
                && !isDeviceLocked()) {
            lastForegroundPackage = pkg;
        }
        if (running && !sendClicked && active != null && "com.whatsapp".equals(pkg)) {
            handler.removeCallbacks(sendProbe);
            handler.post(sendProbe);
        }
    }
    @Override public void onInterrupt() { /* A disabled service cancels automation. */ }
    @Override public void onDestroy() {
        if (running && preparedWasLocked && AutoSendPreferences.relock(this)
                && Build.VERSION.SDK_INT >= 28) {
            try { performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN); }
            catch (Exception ignored) { }
        }
        if (connected == this) connected = null;
        handler.removeCallbacksAndMessages(null);
        removePreview();
        releaseWakeLock();
        active = null;
        queuedBatchItems.clear();
        batchInProgress = "";
        batchHandoffPending = false;
        super.onDestroy();
    }

    private boolean isDeviceLocked() {
        KeyguardManager keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        return keyguard != null && keyguard.isDeviceLocked();
    }
    private String captureCurrentReturnTarget() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        String shown = root == null || root.getPackageName() == null
                ? "" : root.getPackageName().toString();
        return SchedulerForegroundLogic.captureTarget(shown, lastForegroundPackage,
                getPackageName(), resolvedHomePackage);
    }

    private boolean isSystemUi(String pkg) {
        if (pkg == null) return false;
        return pkg.contains("systemui") || pkg.contains("keyguard")
                || pkg.equals("android");
    }

    private boolean screenIsInteractive() {
        PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
        return power != null && power.isInteractive();
    }

    private void prepare(MessageScheduleStore.Item item) {
        if (item == null || !AutoSendPreferences.enabled(this)) return;
        if (running || waitingCountdownId != null || batchHandoffPending) return;
        // A repeat on a later date is a different occurrence of the same batch.
        // Keep a cancellation for its current due time, not indefinitely.
        if (item.batchId != null && item.batchId.equals(canceledBatchId)
                && item.scheduledAtMillis != canceledBatchDueAt) {
            canceledBatchId = "";
            canceledBatchDueAt = 0L;
        }
        preparedId = item.id;
        preparedWasLocked = isDeviceLocked();
        priorPackage = captureCurrentReturnTarget();
        canceledId = null;
        if (!preparedWasLocked) {
            showPreview(item);
        } else if (AutoSendPreferences.experimentalUnlock(this) && SecurePinVault.exists(this)) {
            // Begin keypad preparation early, 3 seconds before the due alarm.
            wakeScreenTemporarily();
            swipeToKeypad();
        }
    }
    private void begin(MessageScheduleStore.Item item) {
        if (item == null || !AutoSendPreferences.enabled(this)) return;
        if (item.id.equals(canceledId)
                || (item.batchId != null && !item.batchId.isEmpty()
                        && item.batchId.equals(canceledBatchId))) {
            removePreview();
            MessageScheduleReceiver.showReminder(this, item);
            return;
        }
        if (running || waitingCountdownId != null || batchHandoffPending) {
            // Same broadcast batch: retain all due messages. Never race multiple
            // Accessibility Send clicks or silently discard other recipients.
            boolean alreadyQueued = active != null && item.id.equals(active.id);
            if (!alreadyQueued) {
                for (MessageScheduleStore.Item queued : queuedBatchItems) {
                    if (item.id.equals(queued.id)) { alreadyQueued = true; break; }
                }
            }
            if (GroupQueueLogic.mayQueue(batchInProgress, item.batchId,
                    alreadyQueued, queuedBatchItems.size())) {
                queuedBatchItems.addLast(item);
            } else if (!alreadyQueued) {
                MessageScheduleReceiver.showReminder(this, item);
            }
            return;
        }
        batchInProgress = item.batchId == null ? "" : item.batchId;
        if (!item.id.equals(preparedId)) {
            preparedWasLocked = isDeviceLocked();
        }

        // Screen ON and unlocked: a visible 3 -> 2 -> 1 is mandatory before
        // automatic UI interaction. A late pre-alert gets its missing time here.
        // If overlay permission was not granted, fail safely to manual reminder.
        if (!preparedWasLocked && screenIsInteractive() && !isDeviceLocked()) {
            if (previewOverlay == null || !item.id.equals(previewId)) {
                showPreview(item);
            }
            if (previewOverlay == null) {
                if (!batchInProgress.isEmpty()) canceledBatchId = batchInProgress;
                drainQueuedReminders();
                batchInProgress = "";
                MessageScheduleReceiver.showReminder(this, item);
                return;
            }
            long remaining = SchedulerForegroundLogic.remainingMillis(
                    previewDeadlineElapsed, SystemClock.elapsedRealtime());
            if (remaining > 0L) {
                waitingCountdownId = item.id;
                waitingCountdownAction = () -> {
                    waitingCountdownId = null;
                    waitingCountdownAction = null;
                    if (!SchedulerForegroundLogic.allowAutomaticSendAfterCountdown(
                            previewOverlay != null && item.id.equals(previewId),
                            screenIsInteractive(), !isDeviceLocked(), item.id.equals(canceledId))) {
                        removePreview();
                        if (!batchInProgress.isEmpty()) canceledBatchId = batchInProgress;
                        drainQueuedReminders();
                        batchInProgress = "";
                        MessageScheduleReceiver.showReminder(this, item);
                        return;
                    }
                    startAutomation(item);
                };
                handler.postDelayed(waitingCountdownAction, remaining);
                return;
            }
        }
        startAutomation(item);
    }

    private void startAutomation(MessageScheduleStore.Item item) {
        startAutomation(item, false);
    }

    private void startAutomation(MessageScheduleStore.Item item, boolean continuingBatch) {
        if (item == null || item.id.equals(canceledId) || running) {
            removePreview();
            return;
        }
        // Keep the original foreground for the full batch; returning between
        // recipients would open stale apps / Home and break the current send.
        if (!continuingBatch && !preparedWasLocked) priorPackage = captureCurrentReturnTarget();
        removePreview();
        // Android 8.x cannot re-lock with the Accessibility lock-screen action.
        if (preparedWasLocked && AutoSendPreferences.relock(this)
                && Build.VERSION.SDK_INT < 28) {
            MessageScheduleReceiver.showReminder(this, item);
            return;
        }
        if (!AutomationRules.canAttemptSend(true, true, !isDeviceLocked(),
                AutoSendPreferences.experimentalUnlock(this) && SecurePinVault.exists(this))) {
            MessageScheduleReceiver.showReminder(this, item);
            drainQueuedReminders();
            if (continuingBatch) restoreOriginalForeground();
            else batchInProgress = "";
            return;
        }
        active = item;
        running = true;
        enteredPin = false;
        sendClicked = false;
        keypadCheckCount = 0;
        dueAt = item.lastTriggeredAtMillis > 0 ? item.lastTriggeredAtMillis
                : System.currentTimeMillis();
        timeoutAt = SystemClock.elapsedRealtime() + AutomationRules.SEND_TIMEOUT_MS;
        if (isDeviceLocked()) {
            if (!AutoSendPreferences.experimentalUnlock(this) || !SecurePinVault.exists(this)) {
                failure();
                return;
            }
            wakeScreenTemporarily();
            swipeToKeypad();
            handler.postDelayed(unlockProbe, 650L);
        } else {
            openWhatsApp();
        }
    }

    @SuppressWarnings("deprecation")
    private void wakeScreenTemporarily() {
        try {
            PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
            if (power != null && !power.isInteractive()) {
                wakeLock = power.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                        "SRToolbox:ScheduleUserApprovedWake");
                wakeLock.acquire(9000L);
            }
        } catch (Exception ignored) { }
    }
    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); }
        catch (Exception ignored) { }
        wakeLock = null;
    }
    private void swipeToKeypad() {
        if (Build.VERSION.SDK_INT < 24) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        Path path = new Path();
        path.moveTo(dm.widthPixels * .5f, dm.heightPixels * .82f);
        path.lineTo(dm.widthPixels * .5f, dm.heightPixels * .30f);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 370L)).build();
        try { dispatchGesture(gesture, null, null); }
        catch (Exception ignored) { }
    }

    private final Runnable unlockProbe = new Runnable() {
        @Override public void run() {
            if (!running || active == null) return;
            if (SystemClock.elapsedRealtime() >= timeoutAt) { failure(); return; }
            if (!isDeviceLocked()) { openWhatsApp(); return; }
            if (enteredPin) {
                handler.postDelayed(() -> {
                    if (!running) return;
                    if (!isDeviceLocked()) openWhatsApp(); else failure();
                }, 1250L);
                return;
            }
            // One owner-PIN attempt, only if all ten Android keyguard digits are
            // exposed in Accessibility's secure keypad node tree.
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || root.getPackageName() == null
                    || !isSystemUi(root.getPackageName().toString())) {
                if (++keypadCheckCount < 5) handler.postDelayed(this, 450L);
                else failure();
                return;
            }
            Map<Character, Point> keypad = new HashMap<>();
            collectDigitKeys(root, keypad, 0);
            if (keypad.size() != 10) {
                if (++keypadCheckCount < 5) handler.postDelayed(this, 450L);
                else failure();
                return;
            }
            char[] pin = SecurePinVault.read(ScheduledWhatsAppAccessibilityService.this);
            if (!AutomationRules.validPin(pin)) {
                if (pin != null) Arrays.fill(pin, '\0');
                failure();
                return;
            }
            ArrayList<Point> taps = new ArrayList<>();
            for (char digit : pin) taps.add(keypad.get(digit));
            Arrays.fill(pin, '\0');
            enteredPin = true;
            tapNextDigit(taps, 0);
        }
    };

    private void collectDigitKeys(AccessibilityNodeInfo node, Map<Character, Point> output, int depth) {
        if (node == null || depth > 18 || output.size() == 10) return;
        if (node.isVisibleToUser() && node.isEnabled()) {
            CharSequence t = node.getText();
            CharSequence d = node.getContentDescription();
            String text = t == null ? "" : t.toString().trim();
            String desc = d == null ? "" : d.toString().trim();
            String label = text.length() == 1 ? text : (desc.length() == 1 ? desc : "");
            if (label.length() == 1 && label.charAt(0) >= '0' && label.charAt(0) <= '9') {
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                if (bounds.width() > 20 && bounds.height() > 20) {
                    output.put(label.charAt(0), new Point(bounds.centerX(), bounds.centerY()));
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectDigitKeys(node.getChild(i), output, depth + 1);
        }
    }
    private void tapNextDigit(ArrayList<Point> taps, int index) {
        if (!running || taps == null || index >= taps.size()) {
            handler.postDelayed(unlockProbe, 700L);
            return;
        }
        Point point = taps.get(index);
        Path path = new Path();
        path.moveTo(point.x, point.y);
        GestureDescription action = new GestureDescription.Builder().addStroke(
                new GestureDescription.StrokeDescription(path, 0L, 80L)).build();
        try {
            boolean started = dispatchGesture(action, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription description) {
                    handler.postDelayed(() -> tapNextDigit(taps, index + 1), 130L);
                }
                @Override public void onCancelled(GestureDescription description) { failure(); }
            }, handler);
            if (!started) failure();
        } catch (Exception error) { failure(); }
    }

    private void openWhatsApp() {
        if (!running || active == null) return;
        if (isDeviceLocked()) { failure(); return; }
        try {
            Intent open = new Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse(MessageScheduleLogic.buildWhatsAppUrl(active.phone, active.message)));
            open.setPackage(AutomationRules.packageToAutomate());
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(open);
            handler.removeCallbacks(sendProbe);
            handler.postDelayed(sendProbe, 900L);
        } catch (Exception error) { failure(); }
    }
    private final Runnable sendProbe = new Runnable() {
        @Override public void run() {
            if (!running || sendClicked || active == null) return;
            if (!AutoSendPreferences.enabled(ScheduledWhatsAppAccessibilityService.this)) {
                failure(); return;
            }
            if (SystemClock.elapsedRealtime() >= timeoutAt) { failure(); return; }
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && root.getPackageName() != null
                    && "com.whatsapp".contentEquals(root.getPackageName())) {
                boolean draftMatches = containsExpectedDraft(root, active.message, 0);
                if (draftMatches) {
                    AccessibilityNodeInfo send = findSendButton(root, 0);
                    if (send != null && send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        attempted();
                        return;
                    }
                }
            }
            handler.postDelayed(this, RETRY_MS);
        }
    };
    private boolean containsExpectedDraft(AccessibilityNodeInfo node, String expected, int depth) {
        if (node == null || depth > 30) return false;
        CharSequence cls = node.getClassName();
        CharSequence value = node.getText();
        if (cls != null && cls.toString().contains("EditText") && value != null
                && expected != null && expected.trim().equals(value.toString().trim())) return true;
        for (int i = 0; i < node.getChildCount(); i++) {
            if (containsExpectedDraft(node.getChild(i), expected, depth + 1)) return true;
        }
        return false;
    }
    private AccessibilityNodeInfo findSendButton(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 30) return null;
        String id = node.getViewIdResourceName();
        CharSequence desc = node.getContentDescription();
        String d = desc == null ? "" : desc.toString().trim().toLowerCase(java.util.Locale.ROOT);
        if (node.isVisibleToUser() && node.isEnabled() && node.isClickable()
                && ((id != null && (id.equals("com.whatsapp:id/send") || id.endsWith("/send")))
                || d.equals("send") || d.equals("পাঠান") || d.startsWith("send message"))) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo candidate = findSendButton(node.getChild(i), depth + 1);
            if (candidate != null) return candidate;
        }
        return null;
    }
    private void attempted() {
        // Stop further Send searches immediately: UI events may arrive repeatedly.
        if (sendClicked) return;
        sendClicked = true;
        handler.removeCallbacks(sendProbe);
        // Accessibility click is not proof of WhatsApp delivery/read receipt.
        if (active != null && "once".equals(active.repeatMode)) {
            MessageScheduleStore.Item current = MessageScheduleStore.get(this, active.id);
            if (current != null) {
                current.status = MessageScheduleStore.STATUS_ATTEMPTED;
                MessageScheduleStore.save(this, current);
            }
        }
        handler.postDelayed(this::restoreAfterRun, 1600L);
    }
    private void failure() {
        if (!running) return;
        // Wrong/unresponsive PIN: delete it and disable future attempts rather
        // than repeatedly trying it on subsequent schedules and risking lockout.
        if (enteredPin && isDeviceLocked()) {
            SecurePinVault.clear(this);
        }
        MessageScheduleStore.Item pending = active;
        if (pending != null) MessageScheduleReceiver.showReminder(this, pending);
        restoreAfterRun();
    }
    private void restoreAfterRun() {
        if (!running) return;
        running = false;
        active = null;
        handler.removeCallbacks(sendProbe);
        handler.removeCallbacks(unlockProbe);
        // One WhatsApp chat at a time, but no arbitrary one-minute interval.
        // Keep the phone foreground and originally captured return target until
        // the entire named batch has been attempted.
        if (!queuedBatchItems.isEmpty()) {
            MessageScheduleStore.Item next = queuedBatchItems.removeFirst();
            batchHandoffPending = true;
            handler.postDelayed(() -> {
                batchHandoffPending = false;
                if (!AutoSendPreferences.enabled(this) || isDeviceLocked()) {
                    MessageScheduleReceiver.showReminder(this, next);
                    // Keep processing remaining queued recipients manually.
                    drainQueuedReminders();
                    restoreOriginalForeground();
                    return;
                }
                startAutomation(next, true);
            }, 200L);
            return;
        }
        releaseWakeLock();
        restoreOriginalForeground();
    }

    private void drainQueuedReminders() {
        while (!queuedBatchItems.isEmpty()) {
            MessageScheduleReceiver.showReminder(this, queuedBatchItems.removeFirst());
        }
    }

    private void restoreOriginalForeground() {
        batchHandoffPending = false;
        batchInProgress = "";
        releaseWakeLock();
        if (preparedWasLocked) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            if (AutoSendPreferences.relock(this) && Build.VERSION.SDK_INT >= 28) {
                handler.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN), 850L);
            }
        } else {
            final String target = priorPackage;
            if (target == null || target.isEmpty()) {
                // Home was the original foreground. Do NOT open an old app.
                performGlobalAction(GLOBAL_ACTION_HOME);
            } else {
                performGlobalAction(GLOBAL_ACTION_BACK);
                // Prefer the real task back stack, so the previous activity's
                // screen/state is preserved when Android allows it.
                handler.postDelayed(() -> {
                    if (isDeviceLocked()) return;
                    AccessibilityNodeInfo root = getRootInActiveWindow();
                    String showing = root == null || root.getPackageName() == null ? ""
                            : root.getPackageName().toString();
                    if (target.equals(showing)) return;
                    try {
                        Intent restore = getPackageManager().getLaunchIntentForPackage(target);
                        if (restore != null) {
                            restore.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(restore);
                        } else {
                            // Not all packages expose a launcher Activity.
                            performGlobalAction(GLOBAL_ACTION_HOME);
                        }
                    } catch (Exception ignored) {
                        performGlobalAction(GLOBAL_ACTION_HOME);
                    }
                }, 850L);
            }
        }
        preparedId = null;
        priorPackage = "";
        enteredPin = false;
        sendClicked = false;
    }

    private void showPreview(MessageScheduleStore.Item item) {
        removePreview();
        if (!screenIsInteractive() || isDeviceLocked() || !Settings.canDrawOverlays(this)) return;
        try {
            overlayManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (overlayManager == null) return;
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.HORIZONTAL);
            panel.setGravity(Gravity.CENTER_VERTICAL);
            panel.setPadding(dp(12), dp(9), dp(12), dp(9));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xF01A2029);
            bg.setCornerRadius(dp(18));
            bg.setStroke(dp(1), 0xFFFFC247);
            panel.setBackground(bg);

            TextView digits = new TextView(this);
            digits.setText("3");
            digits.setTextColor(0xFFFFC247);
            digits.setTextSize(32);
            digits.setGravity(Gravity.CENTER);
            digits.setTypeface(null, android.graphics.Typeface.BOLD);
            panel.addView(digits, new LinearLayout.LayoutParams(dp(48), dp(54)));
            TextView label = new TextView(this);
            label.setTextColor(0xFFFFFFFF);
            label.setTextSize(13);
            String recipient = item.contactName.isEmpty() ? item.phone : item.contactName;
            String batch = item.batchId == null || item.batchId.isEmpty()
                    ? recipient : GroupScheduleLogic.displayName(item.groupName)
                    + " · " + item.batchSize + " recipients";
            label.setText("WhatsApp মেসেজ পাঠানো হবে\n" + batch);
            panel.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
            Button cancel = new Button(this);
            cancel.setText("Cancel");
            cancel.setAllCaps(false);
            cancel.setOnClickListener(v -> {
                canceledId = item.id;
                if (item.batchId != null && !item.batchId.isEmpty()) {
                    canceledBatchId = item.batchId;
                    canceledBatchDueAt = item.scheduledAtMillis;
                }
                drainQueuedReminders();
                batchInProgress = "";
                if (waitingCountdownAction != null) {
                    handler.removeCallbacks(waitingCountdownAction);
                    waitingCountdownAction = null;
                    waitingCountdownId = null;
                }
                removePreview();
                // Keep the schedule in history; the user may send manually.
            });
            panel.addView(cancel, new LinearLayout.LayoutParams(dp(84), dp(46)));
            int safeWidth = Math.max(dp(200), Math.min(dp(345),
                    getResources().getDisplayMetrics().widthPixels - dp(16)));
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    safeWidth, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    android.graphics.PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            params.y = dp(54);
            overlayManager.addView(panel, params);
            previewOverlay = panel;
            previewId = item.id;
            previewCountdownText = digits;
            previewDeadlineElapsed = SystemClock.elapsedRealtime()
                    + SchedulerForegroundLogic.COUNTDOWN_MS;
            handler.removeCallbacks(previewTicker);
            handler.post(previewTicker);
            // If Android delivers the due alarm late, do not leave a stale
            // countdown floating on screen indefinitely. The due handler will
            // show a fresh 3→2→1 countdown before trying to send.
            handler.postDelayed(() -> {
                if (previewOverlay == panel && waitingCountdownId == null) removePreview();
            }, 4800L);
        } catch (Exception ignored) { removePreview(); }
    }
    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + .5f);
    }
    private void removePreview() {
        handler.removeCallbacks(previewTicker);
        if (overlayManager != null && previewOverlay != null) {
            try { overlayManager.removeView(previewOverlay); }
            catch (Exception ignored) { }
        }
        previewOverlay = null;
        previewCountdownText = null;
        previewId = null;
        previewDeadlineElapsed = 0L;
    }
}
