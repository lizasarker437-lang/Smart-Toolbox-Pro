package com.smarttoolbox.pro;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Loads video thumbnails off the main thread and avoids showing stale thumbnails in recycled rows. */
final class VideoThumbnailLoader {
    private final ContentResolver resolver;
    private final ExecutorService workers = Executors.newFixedThreadPool(2);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(8 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap bitmap) {
            return bitmap.getByteCount();
        }
    };
    private final Map<String, List<WeakReference<ImageView>>> requests = new HashMap<>();
    private boolean closed;

    VideoThumbnailLoader(ContentResolver resolver) { this.resolver = resolver; }

    void load(ImageView image, Uri uri) {
        if (uri == null || closed) return;
        String key = uri.toString();
        image.setTag(key);
        image.setImageDrawable(null); // Never show a thumbnail from a previously recycled row.
        Bitmap cached = cache.get(key);
        if (cached != null) {
            image.setImageBitmap(cached);
            return;
        }
        List<WeakReference<ImageView>> awaiting = requests.get(key);
        if (awaiting != null) {
            awaiting.add(new WeakReference<>(image));
            return;
        }
        awaiting = new ArrayList<>();
        awaiting.add(new WeakReference<>(image));
        requests.put(key, awaiting);
        workers.execute(() -> {
            Bitmap bitmap = null;
            try {
                // API 29+ supplies a size-aware, correctly rotated thumbnail.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    bitmap = resolver.loadThumbnail(uri, new Size(256, 144), null);
                } else {
                    // API 26-28 compatibility: deprecated but still supported by the platform.
                    long id = ContentUris.parseId(uri);
                    bitmap = MediaStore.Video.Thumbnails.getThumbnail(
                            resolver, id, MediaStore.Video.Thumbnails.MINI_KIND, null);
                }
            } catch (Exception ignored) {
                // Missing access or damaged media: leave the neutral thumbnail placeholder.
            }
            final Bitmap result = bitmap;
            ui.post(() -> {
                List<WeakReference<ImageView>> views = requests.remove(key);
                if (closed || views == null) return;
                if (result != null) cache.put(key, result);
                for (WeakReference<ImageView> ref : views) {
                    ImageView current = ref.get();
                    if (current != null && key.equals(current.getTag()) && result != null) {
                        current.setImageBitmap(result);
                    }
                }
            });
        });
    }

    void clear() { cache.evictAll(); }
    void shutdown() {
        closed = true;
        requests.clear();
        workers.shutdownNow();
        cache.evictAll();
    }
}
