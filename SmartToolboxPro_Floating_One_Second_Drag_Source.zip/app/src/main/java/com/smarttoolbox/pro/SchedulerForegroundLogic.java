package com.smarttoolbox.pro;

import java.util.Locale;

/** Testable foreground restoration and three-second visible countdown rules. */
final class SchedulerForegroundLogic {
    private SchedulerForegroundLogic() { }
    static final long COUNTDOWN_MS = 3000L;

    static boolean isHome(String currentPackage, String defaultHomePackage) {
        if (currentPackage == null || currentPackage.isEmpty()) return false;
        if (defaultHomePackage != null && !defaultHomePackage.isEmpty()
                && currentPackage.equals(defaultHomePackage)) return true;
        String pkg = currentPackage.toLowerCase(Locale.ROOT);
        return pkg.contains("launcher") || pkg.endsWith(".home")
                || pkg.equals("com.miui.home") || pkg.equals("com.huawei.android.launcher")
                || pkg.equals("com.sec.android.app.launcher")
                || pkg.equals("com.google.android.apps.nexuslauncher");
    }

    static String captureTarget(String shownPackage, String lastForegroundPackage,
                                String appPackage, String defaultHomePackage) {
        // Empty target means Home. Never resurrect an old app if Home is visible.
        if (isHome(shownPackage, defaultHomePackage)) return "";
        // The SR Toolbox itself can be the foreground app when a schedule fires.
        // A non-focusable countdown overlay does not normally replace the active
        // Activity root, so do not discard this legitimate return destination.
        if (appPackage != null && appPackage.equals(shownPackage)) return shownPackage;
        if (valid(shownPackage, appPackage)) return shownPackage;
        if (isHome(lastForegroundPackage, defaultHomePackage)) return "";
        if (valid(lastForegroundPackage, appPackage)) return lastForegroundPackage;
        return "";
    }

    private static boolean valid(String pkg, String ownPackage) {
        if (pkg == null || pkg.isEmpty() || pkg.equals(ownPackage)) return false;
        String lower = pkg.toLowerCase(Locale.ROOT);
        return !lower.contains("systemui") && !lower.contains("keyguard")
                && !"android".equals(lower);
    }

    /** 3, 2, 1, then zero when the countdown is complete. Monotonic time only. */
    static int displaySeconds(long deadlineElapsedMs, long elapsedNowMs) {
        long left = deadlineElapsedMs - elapsedNowMs;
        if (left <= 0L) return 0;
        return (int) Math.min(3L, (left - 1L) / 1000L + 1L);
    }

    static long remainingMillis(long deadlineElapsedMs, long elapsedNowMs) {
        return Math.max(0L, deadlineElapsedMs - elapsedNowMs);
    }

    static boolean allowAutomaticSendAfterCountdown(boolean countdownWasShown,
                                                    boolean screenInteractive,
                                                    boolean deviceUnlocked,
                                                    boolean canceled) {
        return countdownWasShown && screenInteractive && deviceUnlocked && !canceled;
    }
}
