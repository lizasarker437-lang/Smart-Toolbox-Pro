package com.smarttoolbox.pro;

/** No Android dependency: pin a playing portrait video overlay to the nearest edge. */
final class PortraitVideoEdgeLogic {
    private PortraitVideoEdgeLogic() { }

    static boolean shouldPin(boolean videoPlaying, boolean portrait,
                             boolean floatingEnabled, boolean panelOpen) {
        return videoPlaying && portrait && floatingEnabled && !panelOpen;
    }

    static boolean left(int iconX, int iconWidth, int displayWidth) {
        return (long) iconX + iconWidth / 2L < displayWidth / 2L;
    }

    static int edgeX(int displayWidth, int iconWidth, boolean left, int edgeInset) {
        int maxX = Math.max(0, displayWidth - Math.max(1, iconWidth));
        int inset = Math.max(0, edgeInset);
        return left ? Math.min(maxX, inset) : Math.max(0, maxX - inset);
    }

    static int clampY(int iconY, int displayHeight, int iconHeight, int verticalInset) {
        int inset = Math.max(0, verticalInset);
        int maxY = Math.max(0, displayHeight - Math.max(iconHeight, 1) - inset);
        return Math.max(Math.min(inset, maxY), Math.min(maxY, iconY));
    }
}
