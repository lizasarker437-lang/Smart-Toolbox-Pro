package com.smarttoolbox.pro;

/** Pure Java movement rules so inward-swipe and same-edge positioning can be unit-tested. */
final class EdgeSwipeLogic {
    private EdgeSwipeLogic() { }

    static boolean isInwardSwipe(boolean fromLeftEdge, float dx, float dy, int thresholdPx) {
        boolean towardCenter = fromLeftEdge ? dx > thresholdPx : dx < -thresholdPx;
        return towardCenter && Math.abs(dx) > Math.abs(dy) * 1.1f;
    }

    static int bubbleXForSide(boolean leftSide, int screenWidth, int bubbleWidth, int margin) {
        int safeMargin = Math.max(0, margin);
        return leftSide ? Math.min(safeMargin, Math.max(0, screenWidth - bubbleWidth))
                : Math.max(0, screenWidth - bubbleWidth - safeMargin);
    }
}
