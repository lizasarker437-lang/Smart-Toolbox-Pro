package com.smarttoolbox.pro;

import android.content.Context;
import android.content.res.Resources;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import java.util.HashSet;
import java.util.Set;

/** Original short audio cues, loaded asynchronously and completely silent when disabled. */
final class UiSound {
    static final int TAP = PremiumExperienceLogic.SOUND_TAP;
    static final int NAVIGATE = PremiumExperienceLogic.SOUND_NAVIGATE;
    static final int SUCCESS = PremiumExperienceLogic.SOUND_SUCCESS;
    static final int INTRO = PremiumExperienceLogic.SOUND_INTRO;
    private static final String[] PREFIX = {"sr_soft_", "sr_digital_", "sr_crystal_", "sr_arcade_"};
    private static final String[] SUFFIX = {"tap", "open", "success", "intro"};
    private static final int[] RECENT_STREAM_IDS = new int[8];
    private static int nextStreamSlot;
    private static SoundPool pool;
    private static final int[] SAMPLES = new int[PremiumExperienceLogic.PACKS * PremiumExperienceLogic.EVENTS];
    private static final Set<Integer> LOADED = new HashSet<>();
    private static boolean initializing;
    private UiSound() { }

    static synchronized void preload(Context context) {
        if (pool != null || initializing || !PremiumExperience.sounds(context)) return;
        initializing = true;
        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).build();
            pool = new SoundPool.Builder().setMaxStreams(3).setAudioAttributes(attrs).build();
            pool.setOnLoadCompleteListener((soundPool, sampleId, status) -> {
                if (status == 0) synchronized (UiSound.class) { LOADED.add(sampleId); }
            });
            Resources resources = context.getResources();
            for (int pack = 0; pack < PremiumExperienceLogic.PACKS; pack++) {
                for (int event = 0; event < PremiumExperienceLogic.EVENTS; event++) {
                    int id = resources.getIdentifier(PREFIX[pack] + SUFFIX[event], "raw", context.getPackageName());
                    if (id != 0) SAMPLES[PremiumExperienceLogic.soundIndex(pack, event)] = pool.load(context, id, 1);
                }
            }
        } catch (RuntimeException ex) {
            if (pool != null) pool.release();
            pool = null;
        } finally {
            initializing = false;
        }
    }
    static void play(Context context, int event) {
        if (context == null || !PremiumExperience.sounds(context)) return;
        AudioManager manager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (manager == null || manager.getRingerMode() != AudioManager.RINGER_MODE_NORMAL) return;
        if (manager.getStreamVolume(AudioManager.STREAM_MUSIC) <= 0) return;
        preload(context.getApplicationContext());
        int sampleId = 0;
        SoundPool soundPool;
        synchronized (UiSound.class) {
            soundPool = pool;
            sampleId = SAMPLES[PremiumExperienceLogic.soundIndex(PremiumExperience.pack(context), event)];
            if (soundPool == null || sampleId == 0 || !LOADED.contains(sampleId)) return;
        }
        try {
            int streamId = soundPool.play(sampleId, 0.35f, 0.35f, 1, 0, 1f);
            if (streamId > 0) synchronized (UiSound.class) {
                RECENT_STREAM_IDS[nextStreamSlot++ % RECENT_STREAM_IDS.length] = streamId;
            }
        } catch (RuntimeException ignored) { }
    }
    static synchronized void silence(Context context) {
        // Stop already-playing short cues immediately, not just future cues.
        if (pool == null) return;
        for (int i = 0; i < RECENT_STREAM_IDS.length; i++) {
            if (RECENT_STREAM_IDS[i] > 0) pool.stop(RECENT_STREAM_IDS[i]);
            RECENT_STREAM_IDS[i] = 0;
        }
    }
}
