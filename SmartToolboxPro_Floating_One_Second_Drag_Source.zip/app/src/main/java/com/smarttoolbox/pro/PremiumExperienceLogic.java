package com.smarttoolbox.pro;

/** Side-effect-free settings validation and sound-event routing rules. */
final class PremiumExperienceLogic {
    static final int CLASSIC = 0;
    static final int PREMIUM = 1;
    static final int SOFT = 0;
    static final int DIGITAL = 1;
    static final int CRYSTAL = 2;
    static final int ARCADE = 3;
    static final int SOUND_TAP = 0;
    static final int SOUND_NAVIGATE = 1;
    static final int SOUND_SUCCESS = 2;
    static final int SOUND_INTRO = 3;
    static final int PACKS = 4;
    static final int EVENTS = 4;
    static final String[] PACK_NAMES = {"Soft", "Digital", "Crystal", "Arcade"};
    private PremiumExperienceLogic() { }
    static int style(int value) { return value == CLASSIC ? CLASSIC : PREMIUM; }
    static int soundPack(int value) { return value >= 0 && value < PACKS ? value : SOFT; }
    static int soundEvent(int value) { return value >= 0 && value < EVENTS ? value : SOUND_TAP; }
    static int soundIndex(int pack, int event) { return soundPack(pack) * EVENTS + soundEvent(event); }
    static boolean shouldPlay(boolean soundEnabled, boolean hasAudioFocus, boolean isMuted) {
        return soundEnabled && hasAudioFocus && !isMuted;
    }
    static int modeKey(int palette, int appearance, boolean light, int style) {
        return palette * 1000 + appearance * 10 + (light ? 2 : 0) + style(style);
    }
}
