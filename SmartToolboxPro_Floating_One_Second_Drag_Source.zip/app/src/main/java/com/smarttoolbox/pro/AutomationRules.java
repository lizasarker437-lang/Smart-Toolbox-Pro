package com.smarttoolbox.pro;

/** Standalone policy/logic to test without Android SDK. */
final class AutomationRules {
    static final long PRE_ALERT_MS = 3000L;
    static final long SEND_TIMEOUT_MS = 23000L;
    static final int MAX_PIN_ATTEMPTS_PER_SCHEDULE = 1;
    private AutomationRules() { }
    static boolean validPin(char[] pin) {
        if (pin == null || pin.length < 4 || pin.length > 12) return false;
        for (char digit : pin) if (digit < '0' || digit > '9') return false;
        return true;
    }
    static long preAlertAt(long due) { return due - PRE_ALERT_MS; }
    static boolean isDue(long due, long now) { return now >= due; }
    static boolean canAttemptSend(boolean optedIn, boolean serviceEnabled,
                                  boolean phoneUnlocked, boolean authorizedLockedMode) {
        return optedIn && serviceEnabled && (phoneUnlocked || authorizedLockedMode);
    }
    static boolean shouldRelock(boolean wasLocked, boolean optedRelock) {
        return wasLocked && optedRelock;
    }
    static boolean shouldRestoreApp(boolean wasLocked) { return !wasLocked; }
    static String packageToAutomate() { return "com.whatsapp"; }
}
