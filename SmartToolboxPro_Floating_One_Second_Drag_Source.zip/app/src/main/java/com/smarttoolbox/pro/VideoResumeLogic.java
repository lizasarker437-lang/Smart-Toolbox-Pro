package com.smarttoolbox.pro;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Pure Java policy and stable keys for separately saving every video's position. */
public final class VideoResumeLogic {
    private VideoResumeLogic() {}

    public static String keyForUri(String uri) {
        if (uri == null || uri.isEmpty()) throw new IllegalArgumentException("Empty video uri");
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(uri.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder("video.position.");
            for (byte b : digest) {
                int n = b & 0xff;
                out.append(Character.forDigit(n >>> 4, 16));
                out.append(Character.forDigit(n & 15, 16));
            }
            return out.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 unavailable", impossible);
        }
    }

    /** Don't resume at the very beginning or after the end credits. */
    public static boolean shouldResume(long positionMs, long durationMs) {
        if (positionMs < 10_000L) return false;
        return durationMs <= 0L || (durationMs > 30_000L && durationMs - positionMs > 15_000L);
    }

    /** Return zero when finished; otherwise preserve the precise useful position. */
    public static long positionToSave(long positionMs, long durationMs, boolean ended) {
        if (ended || positionMs < 0L) return 0L;
        if (durationMs > 0L && durationMs - positionMs <= 10_000L) return 0L;
        return positionMs;
    }
}
