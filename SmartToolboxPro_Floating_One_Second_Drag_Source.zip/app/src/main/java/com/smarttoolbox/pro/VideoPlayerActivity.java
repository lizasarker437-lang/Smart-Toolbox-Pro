package com.smarttoolbox.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Rational;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.PixelCopy;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

@UnstableApi
public class VideoPlayerActivity extends Activity {
    private static final int REQUEST_OPEN_VIDEOS = 4101;
    private static final int REQUEST_OPEN_SUBTITLE = 4102;
    public static final String EXTRA_VIDEO_URI = "sr.player.video_uri";
    public static final String EXTRA_VIDEO_TITLE = "sr.player.video_title";
    public static final String EXTRA_RESTART_VIDEO = "sr.player.restart_video";
    public static final String EXTRA_OPEN_PICKER = "sr.player.open_picker";
    public static final String EXTRA_CONTINUE_LAST = "sr.player.continue_last";
    private static final String PREFS = "sr_video_player";
    private static final long POSITION_SAVE_INTERVAL_MS = 1500L;
    private static final long CONTROL_HIDE_DELAY_MS = 3200L;

    private FrameLayout rootPage;
    private FrameLayout playerTools;
    private FrameLayout emptyState;
    private LinearLayout topPanel;
    private LinearLayout topBar;
    private LinearLayout quickActions;
    private LinearLayout bottomPanel;
    private LinearLayout seekRow;
    private LinearLayout bottomActionRow;
    private LinearLayout centerTransport;
    private LinearLayout rightTools;

    private PlayerView playerView;
    private ScaleGestureDetector pinchDetector;
    private float videoZoom = 1f;
    private boolean holdBoostActive;
    private float speedBeforeHold = 1f;
    private final Runnable activateHoldBoost = this::activateHoldBoostNow;

    private void activateHoldBoostNow() {
        if (controller != null && controller.isPlaying() && !screenLocked) {
            speedBeforeHold = controller.getPlaybackParameters().speed;
            float boost = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat("hold_boost_speed", 3f);
            controller.setPlaybackParameters(new PlaybackParameters(boost));
            holdBoostActive = true;
            showGestureStatus("Hold speed " + boost + "×");
        }
    }

    private TextView statusText;
    private TextView nowPlayingText;
    private TextView currentTimeText;
    private TextView remainingTimeText;
    private TextView playPauseButton;
    private TextView lockButton;
    private TextView speedButton;
    private TextView displayToolsButton;
    private TextView aspectButton;
    private SeekBar positionSeekBar;

    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private List<MediaItem> pendingItems;
    private CountDownTimer sleepTimer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean screenLocked;
    private boolean inPictureInPicture;
    private boolean wasFullScreenBeforePip;
    private boolean activityStarted;
    private boolean landscape;
    private boolean fullScreen;
    private boolean playbackEnded;
    private boolean controlsVisible = true;
    private boolean isSeeking;
    private boolean audioOnly;
    private boolean exitingForBackgroundAudio;
    private boolean explicitPlayerExit;
    private android.window.OnBackInvokedCallback modernBackCallback;
    private int originalSystemUiVisibility;
    private int resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
    private GestureDetector gestureDetector;
    private AudioManager audioManager;
    private int gestureMode;
    private float gestureStartX;
    private float gestureStartY;
    private int gestureStartVolume;
    private float gestureStartBrightness;
    private long gestureStartPosition;
    private long pendingResumePosition = C.TIME_UNSET;
    private boolean forceRestartNextSelection;
    private boolean skipAutoResumeForTransition;
    private final Runnable hideControlsRunnable = this::hideControls;
    private final Runnable progressUpdateRunnable = new Runnable() {
        @Override public void run() {
            updatePlaybackUi();
            handler.postDelayed(this, 500L);
        }
    };

    private final Runnable savePositionRunnable = new Runnable() {
        @Override public void run() {
            saveResumePoint();
            updateNowPlaying();
            handler.postDelayed(this, POSITION_SAVE_INTERVAL_MS);
        }
    };

    private final Player.Listener playerListener = new Player.Listener() {
        @Override public void onMediaItemTransition(MediaItem mediaItem, int reason) {
            playbackEnded = false;
            // Per-video bookmarks survive switching to another video in a playlist.
            // Avoid overriding an explicit Start from beginning selection.
            if (controller != null && mediaItem != null
                    && reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT
                    && !skipAutoResumeForTransition && controller.getCurrentPosition() < 2_000L) {
                Uri uri = getUriFromItem(mediaItem);
                if (uri != null) {
                    long saved = VideoResumeStore.get(VideoPlayerActivity.this, uri.toString());
                    if (VideoResumeLogic.shouldResume(saved, controller.getDuration())) {
                        controller.seekTo(saved);
                    }
                }
            }
            skipAutoResumeForTransition = false;
            updateNowPlaying();
            rememberHistory(mediaItem);
            showControls();
        }

        @Override public void onPlaybackStateChanged(int playbackState) {
            playbackEnded = playbackState == Player.STATE_ENDED;
            updateNowPlaying();
            updatePlaybackUi();
            if (playbackEnded) saveResumePoint();
        }

        @Override public void onIsPlayingChanged(boolean isPlaying) {
            syncPortraitVideoEdge();
            if (playerView != null) playerView.setKeepScreenOn(isPlaying);
            updateNowPlaying();
            updatePlaybackUi();
            if (isPlaying) scheduleControlsAutoHide();
            else showControls();
        }

        @Override public void onPlayerError(PlaybackException error) {
            String message = "এই ভিডিওটি চালানো যায়নি। ফাইলটি নষ্ট, অসমর্থিত Codec অথবা নেটওয়ার্ক সমস্যা হতে পারে।";
            if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
                    || error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
                    || error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED) {
                message = "এই ফোনে ভিডিওটির Codec / Resolution সমর্থিত নয়। অন্য ফরম্যাট বা কম Resolution-এর ভিডিও চেষ্টা করুন।";
            } else if (error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
                    || error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
                    || error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
                    || error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED) {
                message = "ভিডিওর Container / Stream format অসমর্থিত অথবা ফাইলটি নষ্ট। অন্য ভিডিও চেষ্টা করুন।";
            } else if (error.errorCode == PlaybackException.ERROR_CODE_IO_NO_PERMISSION
                    || error.errorCode == PlaybackException.ERROR_CODE_PERMISSION_DENIED) {
                message = "ভিডিও ফাইলটি পড়ার অনুমতি নেই। ফাইলটি আবার নির্বাচন করুন।";
            } else if (error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                    || error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) {
                message = "নেটওয়ার্ক সংযোগ পাওয়া যায়নি। ইন্টারনেট ও ভিডিও লিংক পরীক্ষা করুন।";
            }
            statusText.setText(message);
            showControls();
            Toast.makeText(VideoPlayerActivity.this, message, Toast.LENGTH_LONG).show();
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        originalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildInterface();
        setupGestures();
        // On Android 13+, handle predictive system back the same way as the
        // visible Back button: stop the session unless audio mode was chosen.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerSystemBack();
        }
        // Library entry opens an indexed phone video directly, not the file picker.
        String videoUri = getIntent().getStringExtra(EXTRA_VIDEO_URI);
        if (getIntent().getBooleanExtra(EXTRA_CONTINUE_LAST, false)) {
            resumeLastVideo();
        } else if (videoUri != null && !videoUri.trim().isEmpty()) {
            try {
                Uri uri = Uri.parse(videoUri);
                String title = getIntent().getStringExtra(EXTRA_VIDEO_TITLE);
                forceRestartNextSelection = getIntent().getBooleanExtra(EXTRA_RESTART_VIDEO, false);
                playItems(Collections.singletonList(createMediaItem(uri, title)));
            } catch (RuntimeException error) {
                toast("The selected video cannot be opened. Please select it again.");
            }
        }
        else if (getIntent().getBooleanExtra(EXTRA_OPEN_PICKER, false)) {
            openVideos();
        }
    }

    private void buildInterface() {
        rootPage = new FrameLayout(this);
        rootPage.setBackgroundColor(Color.BLACK);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setControllerAutoShow(false);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setKeepContentOnPlayerReset(true);
        playerView.setResizeMode(resizeMode);
        playerView.setShutterBackgroundColor(Color.BLACK);
        FrameLayout.LayoutParams videoParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        rootPage.addView(playerView, videoParams);

        playerTools = new FrameLayout(this);
        playerTools.setClickable(false);
        rootPage.addView(playerTools, new FrameLayout.LayoutParams(-1, -1));

        // Top gradient and title / track controls.
        topPanel = new LinearLayout(this);
        topPanel.setOrientation(LinearLayout.VERTICAL);
        topPanel.setPadding(dp(10), dp(6), dp(10), dp(10));
        topPanel.setBackground(gradientBackground(true));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(-1, dp(112), Gravity.TOP);
        playerTools.addView(topPanel, topParams);

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topPanel.addView(topBar, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView back = overlayButton("‹", 34, 44, 44);
        addControl(topBar, back, 0, 0);
        back.setContentDescription("Back and stop video/audio");
        back.setOnClickListener(v -> exitPlayerAndStop());

        nowPlayingText = new TextView(this);
        nowPlayingText.setText("SR Video Player");
        nowPlayingText.setTextColor(Color.WHITE);
        nowPlayingText.setTextSize(15);
        nowPlayingText.setSingleLine(true);
        nowPlayingText.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        nowPlayingText.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, -1, 1f);
        titleParams.leftMargin = dp(6);
        titleParams.rightMargin = dp(6);
        topBar.addView(nowPlayingText, titleParams);

        TextView audioTrack = overlayButton("♫", 22, 42, 42);
        addControl(topBar, audioTrack, 2, 2);
        audioTrack.setOnClickListener(v -> { chooseTrack(C.TRACK_TYPE_AUDIO); showControls(); });

        TextView subtitles = overlayButton("CC", 15, 44, 42);
        addControl(topBar, subtitles, 2, 2);
        subtitles.setOnClickListener(v -> { chooseTrack(C.TRACK_TYPE_TEXT); showControls(); });

        TextView hwBadge = overlayButton("HW", 12, 42, 42);
        addControl(topBar, hwBadge, 2, 2);
        hwBadge.setOnClickListener(v -> {
            toast("Media3 ডিভাইসের উপলভ্য Decoder ব্যবহার করে। Codec সাপোর্ট ফোনভেদে আলাদা হতে পারে।");
            showControls();
        });

        TextView menu = overlayButton("⋮", 25, 42, 42);
        addControl(topBar, menu, 0, 0);
        menu.setOnClickListener(v -> { showPlayerMenu(); showControls(); });

        quickActions = new LinearLayout(this);
        quickActions.setOrientation(LinearLayout.HORIZONTAL);
        quickActions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams quickParams = new LinearLayout.LayoutParams(-1, dp(48));
        quickParams.topMargin = dp(4);
        topPanel.addView(quickActions, quickParams);

        speedButton = overlayButton("1×", 16, 48, 42);
        addControl(quickActions, speedButton, 4, 0);
        speedButton.setOnClickListener(v -> { chooseSpeed(); showControls(); });

        TextView screenshot = overlayButton("▣", 22, 48, 42);
        addControl(quickActions, screenshot, 4, 0);
        screenshot.setOnClickListener(v -> { captureVideoFrame(); showControls(); });

        // Deliberate choice: leave the player but keep only its sound playing.
        // Regular Back uses exitPlayerAndStop() and stops both video and audio.
        TextView backgroundAudioButton = overlayButton("🎵", 21, 48, 42);
        backgroundAudioButton.setContentDescription("Background audio - leave player and keep sound playing");
        addControl(quickActions, backgroundAudioButton, 4, 0);
        backgroundAudioButton.setOnClickListener(v -> exitPlayerKeepingAudio());

        TextView rotate = overlayButton("▱", 22, 48, 42);
        addControl(quickActions, rotate, 4, 0);
        rotate.setOnClickListener(v -> { toggleOrientation(); showControls(); });

        TextView quickMore = overlayButton("›", 25, 42, 42);
        addControl(quickActions, quickMore, 4, 0);
        quickMore.setOnClickListener(v -> { showPlayerMenu(); showControls(); });

        statusText = new TextView(this);
        statusText.setText("Select a video to start playback");
        statusText.setTextColor(0xDDFFFFFF);
        statusText.setTextSize(11);
        statusText.setSingleLine(true);
        statusText.setEllipsize(TextUtils.TruncateAt.END);
        statusText.setPadding(dp(14), dp(5), dp(14), dp(5));
        statusText.setBackground(roundBackground(0x55000000, 18));
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(
                -2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        statusParams.topMargin = dp(122);
        playerTools.addView(statusText, statusParams);

        // Left-side display control, similar to the reference player's side tool.
        displayToolsButton = overlayButton("☷", 25, 48, 54);
        FrameLayout.LayoutParams displayParams = new FrameLayout.LayoutParams(
                dp(48), dp(54), Gravity.CENTER_VERTICAL | Gravity.LEFT);
        displayParams.leftMargin = dp(8);
        playerTools.addView(displayToolsButton, displayParams);
        displayToolsButton.setOnClickListener(v -> { showDisplayControlsDialog(); showControls(); });

        // Bottom gradient, time bar, and transport controls.
        bottomPanel = new LinearLayout(this);
        bottomPanel.setOrientation(LinearLayout.VERTICAL);
        bottomPanel.setPadding(dp(12), dp(12), dp(12), dp(8));
        bottomPanel.setBackground(gradientBackground(false));
        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(
                -1, dp(126), Gravity.BOTTOM);
        playerTools.addView(bottomPanel, bottomParams);

        seekRow = new LinearLayout(this);
        seekRow.setOrientation(LinearLayout.HORIZONTAL);
        seekRow.setGravity(Gravity.CENTER_VERTICAL);
        bottomPanel.addView(seekRow, new LinearLayout.LayoutParams(-1, dp(38)));

        currentTimeText = timeLabel("00:00");
        seekRow.addView(currentTimeText, new LinearLayout.LayoutParams(dp(58), -2));

        positionSeekBar = new SeekBar(this);
        positionSeekBar.setMax(1000);
        positionSeekBar.setProgress(0);
        positionSeekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFFC247));
        positionSeekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        positionSeekBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0x66FFFFFF));
        seekRow.addView(positionSeekBar, new LinearLayout.LayoutParams(0, dp(32), 1f));
        positionSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && controller != null && controller.getDuration() > 0) {
                    long target = controller.getDuration() * progress / seekBar.getMax();
                    controller.seekTo(target);
                    currentTimeText.setText(formatTime(target));
                    remainingTimeText.setText("-" + formatTime(Math.max(0L, controller.getDuration() - target)));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                isSeeking = true;
                handler.removeCallbacks(hideControlsRunnable);
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                isSeeking = false;
                scheduleControlsAutoHide();
            }
        });

        remainingTimeText = timeLabel("--:--");
        seekRow.addView(remainingTimeText, new LinearLayout.LayoutParams(dp(66), -2));

        bottomActionRow = new LinearLayout(this);
        bottomActionRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomActionRow.setGravity(Gravity.CENTER_VERTICAL);
        bottomActionRow.setWeightSum(3f);
        bottomPanel.addView(bottomActionRow, new LinearLayout.LayoutParams(-1, dp(66)));

        View leftSpacer = new View(this);
        bottomActionRow.addView(leftSpacer, new LinearLayout.LayoutParams(0, dp(50), 0.6f));

        centerTransport = new LinearLayout(this);
        centerTransport.setOrientation(LinearLayout.HORIZONTAL);
        centerTransport.setGravity(Gravity.CENTER);
        bottomActionRow.addView(centerTransport, new LinearLayout.LayoutParams(0, dp(58), 1.6f));

        TextView previous = overlayButton("|◀", 20, 44, 46);
        centerTransport.addView(previous);
        previous.setOnClickListener(v -> { previousVideo(); showControls(); });

        playPauseButton = overlayButton("▶", 30, 64, 58);
        LinearLayout.LayoutParams playParams = new LinearLayout.LayoutParams(dp(58), dp(56));
        playParams.leftMargin = dp(12);
        playParams.rightMargin = dp(12);
        centerTransport.addView(playPauseButton, playParams);
        playPauseButton.setOnClickListener(v -> { togglePlayPause(); showControls(); });

        TextView next = overlayButton("▶|", 20, 44, 46);
        centerTransport.addView(next);
        next.setOnClickListener(v -> { nextVideo(); showControls(); });

        rightTools = new LinearLayout(this);
        rightTools.setOrientation(LinearLayout.HORIZONTAL);
        rightTools.setGravity(Gravity.CENTER);
        bottomActionRow.addView(rightTools, new LinearLayout.LayoutParams(0, dp(58), 0.8f));

        aspectButton = overlayButton("↔", 20, 40, 42);
        rightTools.addView(aspectButton);
        aspectButton.setOnClickListener(v -> { cycleAspectRatio(); showControls(); });

        TextView pip = overlayButton("▣", 18, 40, 42);
        rightTools.addView(pip);
        pip.setOnClickListener(v -> enterPictureInPicture());

        lockButton = overlayButton("🔓", 21, 52, 52);
        FrameLayout.LayoutParams lockParams = new FrameLayout.LayoutParams(
                dp(52), dp(52), Gravity.BOTTOM | Gravity.LEFT);
        lockParams.leftMargin = dp(14);
        lockParams.bottomMargin = dp(18);
        playerTools.addView(lockButton, lockParams);
        lockButton.setOnClickListener(v -> toggleScreenLock());

        // Initial empty state: simple, unobtrusive, and still part of the player screen.
        emptyState = new FrameLayout(this);
        emptyState.setBackgroundColor(0x66000000);
        FrameLayout.LayoutParams emptyParams = new FrameLayout.LayoutParams(-1, -1);
        playerTools.addView(emptyState, emptyParams);

        LinearLayout emptyContent = new LinearLayout(this);
        emptyContent.setOrientation(LinearLayout.VERTICAL);
        emptyContent.setGravity(Gravity.CENTER);
        emptyContent.setPadding(dp(24), dp(24), dp(24), dp(24));
        FrameLayout.LayoutParams emptyContentParams = new FrameLayout.LayoutParams(
                -1, -2, Gravity.CENTER);
        emptyState.addView(emptyContent, emptyContentParams);

        TextView brand = new TextView(this);
        brand.setText("SR VIDEO PLAYER");
        brand.setTextColor(0xFFFFC247);
        brand.setTextSize(22);
        brand.setGravity(Gravity.CENTER);
        emptyContent.addView(brand, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Choose a video from your phone or open a secure video link");
        hint.setTextColor(0xCCFFFFFF);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(8);
        emptyContent.addView(hint, hintParams);

        TextView openVideo = emptyAction("▤  Browse all phone videos");
        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(-1, dp(48));
        openParams.topMargin = dp(20);
        emptyContent.addView(openVideo, openParams);
        openVideo.setOnClickListener(v -> openPhoneVideoLibrary());

        TextView openLink = emptyAction("＋  Select videos / playlist");
        LinearLayout.LayoutParams linkParams = new LinearLayout.LayoutParams(-1, dp(46));
        linkParams.topMargin = dp(8);
        emptyContent.addView(openLink, linkParams);
        openLink.setOnClickListener(v -> openVideos());

        TextView network = emptyAction("↗  Play HTTPS / RTSP link");
        LinearLayout.LayoutParams networkParams = new LinearLayout.LayoutParams(-1, dp(44));
        networkParams.topMargin = dp(8);
        emptyContent.addView(network, networkParams);
        network.setOnClickListener(v -> openNetworkUrl());

        TextView continueLast = emptyAction("▶  Continue last video");
        LinearLayout.LayoutParams resumeParams = new LinearLayout.LayoutParams(-1, dp(44));
        resumeParams.topMargin = dp(8);
        emptyContent.addView(continueLast, resumeParams);
        continueLast.setOnClickListener(v -> resumeLastVideo());

        TextView library = emptyAction("★ Favorites     ·     ◷ History");
        LinearLayout.LayoutParams libraryParams = new LinearLayout.LayoutParams(-1, dp(44));
        libraryParams.topMargin = dp(8);
        emptyContent.addView(library, libraryParams);
        library.setOnClickListener(v -> showLibraryMenu());

        setContentView(rootPage);
        updateControlVisibility();
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable roundBackground(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private GradientDrawable gradientBackground(boolean top) {
        GradientDrawable drawable = new GradientDrawable(
                top ? GradientDrawable.Orientation.TOP_BOTTOM : GradientDrawable.Orientation.BOTTOM_TOP,
                top ? new int[]{0xCC000000, 0x88000000, 0x00000000}
                    : new int[]{0xCC000000, 0x99000000, 0x00000000});
        drawable.setCornerRadius(0);
        return drawable;
    }

    private TextView overlayButton(String label, int size, int widthDp, int heightDp) {
        TextView button = new TextView(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(size);
        button.setGravity(Gravity.CENTER);
        button.setMinWidth(dp(widthDp));
        button.setMinHeight(dp(heightDp));
        button.setPadding(dp(5), dp(3), dp(5), dp(3));
        button.setBackground(roundBackground(0x66000000, 28));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private TextView timeLabel(String value) {
        TextView label = new TextView(this);
        label.setText(value);
        label.setTextColor(Color.WHITE);
        label.setTextSize(12);
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        return label;
    }

    private TextView emptyAction(String value) {
        TextView action = overlayButton(value, 14, 220, 46);
        action.setBackground(roundBackground(0xCC202832, 16));
        return action;
    }

    private void addControl(LinearLayout parent, View view, int leftDp, int rightDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -1);
        params.leftMargin = dp(leftDp);
        params.rightMargin = dp(rightDp);
        parent.addView(view, params);
    }

    private void setupGestures() {
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent event) {
                gestureMode = 0;
                gestureStartX = event.getX();
                gestureStartY = event.getY();
                gestureStartPosition = controller == null ? 0L : Math.max(0L, controller.getCurrentPosition());
                gestureStartVolume = audioManager == null ? 0
                        : audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                WindowManager.LayoutParams attributes = getWindow().getAttributes();
                gestureStartBrightness = attributes.screenBrightness < 0
                        ? 0.55f : attributes.screenBrightness;
                return true;
            }

            @Override public boolean onSingleTapConfirmed(MotionEvent event) {
                if (screenLocked) {
                    showControls();
                    return true;
                }
                if (controlsVisible) hideControls();
                else showControls();
                return true;
            }

            @Override public boolean onDoubleTap(MotionEvent event) {
                if (screenLocked || controller == null || controller.getMediaItemCount() == 0) return true;
                long delta = event.getX() < playerView.getWidth() / 2f ? -10_000L : 10_000L;
                long duration = controller.getDuration();
                long target = Math.max(0L, controller.getCurrentPosition() + delta);
                if (duration > 0 && duration != C.TIME_UNSET) target = Math.min(duration, target);
                controller.seekTo(target);
                showGestureStatus(delta < 0 ? "−10 seconds" : "+10 seconds");
                showControls();
                return true;
            }

            @Override public boolean onScroll(MotionEvent first, MotionEvent current,
                                              float distanceX, float distanceY) {
                if (screenLocked || controller == null || controller.getCurrentMediaItem() == null) return true;
                float dx = current.getX() - first.getX();
                float dy = current.getY() - first.getY();
                if (gestureMode == 0) {
                    if (Math.abs(dx) > Math.abs(dy) * 1.15f) gestureMode = 3;
                    else if (first.getX() < playerView.getWidth() * 0.42f) gestureMode = 1;
                    else gestureMode = 2;
                    showControls();
                }
                if (gestureMode == 1) {
                    float value = gestureStartBrightness - (dy / Math.max(1f, playerView.getHeight())) * 1.2f;
                    applyWindowBrightness(value);
                    showGestureStatus("Brightness  " + Math.round(value * 100) + "%");
                } else if (gestureMode == 2) {
                    if (audioManager != null) {
                        int max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                        int value = Math.max(0, Math.min(max,
                                gestureStartVolume + Math.round(-dy / Math.max(1f, playerView.getHeight()) * max * 1.6f)));
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0);
                        showGestureStatus("Volume  " + Math.round(value * 100f / Math.max(1, max)) + "%");
                    }
                } else if (gestureMode == 3) {
                    long duration = controller.getDuration();
                    if (duration > 0 && duration != C.TIME_UNSET) {
                        long delta = Math.round((dx / Math.max(1f, playerView.getWidth())) * duration * 0.18f);
                        long target = Math.max(0L, Math.min(duration, gestureStartPosition + delta));
                        controller.seekTo(target);
                        showGestureStatus(formatTime(target) + " / " + formatTime(duration));
                    }
                }
                return true;
            }
        });

        pinchDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                videoZoom = Math.max(1f, Math.min(5f, videoZoom * detector.getScaleFactor()));
                View surface = playerView.getVideoSurfaceView();
                if (surface != null) { surface.setScaleX(videoZoom); surface.setScaleY(videoZoom); }
                showGestureStatus("Zoom " + String.format(java.util.Locale.US, "%.1f", videoZoom) + "×");
                return true;
            }
        });
        playerView.setOnTouchListener((view, event) -> {
            pinchDetector.onTouchEvent(event);
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                handler.postDelayed(activateHoldBoost, 450L);
            } else if (event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN
                    || event.getActionMasked() == MotionEvent.ACTION_MOVE && event.getPointerCount() > 1) {
                handler.removeCallbacks(activateHoldBoost);
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP
                    || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                handler.removeCallbacks(activateHoldBoost);
                if (holdBoostActive) {
                    if (controller != null) controller.setPlaybackParameters(new PlaybackParameters(speedBeforeHold));
                    holdBoostActive = false;
                }
            }
            if (event.getPointerCount() > 1 || pinchDetector.isInProgress()) return true;
            boolean handled = gestureDetector.onTouchEvent(event);
            if (event.getAction() == MotionEvent.ACTION_UP
                    || event.getAction() == MotionEvent.ACTION_CANCEL) {
                scheduleControlsAutoHide();
            }
            return handled;
        });
    }

    private void showGestureStatus(String message) {
        statusText.setText(message);
        statusText.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideControlsRunnable);
        handler.postDelayed(() -> {
            if (controller != null && controller.isPlaying()) scheduleControlsAutoHide();
        }, 850L);
    }

    private void applyWindowBrightness(float value) {
        float safe = Math.max(0.02f, Math.min(1f, value));
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.screenBrightness = safe;
        getWindow().setAttributes(params);
    }

    private void showDisplayControlsDialog() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(12), dp(22), dp(8));

        TextView brightnessLabel = new TextView(this);
        brightnessLabel.setText("Brightness");
        content.addView(brightnessLabel);
        SeekBar brightness = new SeekBar(this);
        brightness.setMax(100);
        float currentBrightness = getWindow().getAttributes().screenBrightness;
        brightness.setProgress(currentBrightness < 0 ? 55 : Math.round(currentBrightness * 100));
        content.addView(brightness);
        brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser) applyWindowBrightness(value / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        TextView volumeLabel = new TextView(this);
        volumeLabel.setText("Media volume");
        LinearLayout.LayoutParams volumeLabelParams = new LinearLayout.LayoutParams(-1, -2);
        volumeLabelParams.topMargin = dp(12);
        content.addView(volumeLabel, volumeLabelParams);
        SeekBar volume = new SeekBar(this);
        int max = audioManager == null ? 15 : audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        volume.setMax(Math.max(1, max));
        volume.setProgress(audioManager == null ? 0 : audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        content.addView(volume);
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser && audioManager != null) {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        new AlertDialog.Builder(this).setTitle("Display controls")
                .setView(content).setPositiveButton("Done", null).show();
    }

    private void togglePlayPause() {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            openVideos();
            return;
        }
        if (controller.isPlaying()) controller.pause();
        else controller.play();
        updatePlaybackUi();
    }

    private void updatePlaybackUi() {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            if (currentTimeText != null) currentTimeText.setText("00:00");
            if (remainingTimeText != null) remainingTimeText.setText("--:--");
            if (positionSeekBar != null) positionSeekBar.setProgress(0);
            if (playPauseButton != null) playPauseButton.setText("▶");
            return;
        }
        long duration = controller.getDuration();
        long position = Math.max(0L, controller.getCurrentPosition());
        if (currentTimeText != null) currentTimeText.setText(formatTime(position));
        if (remainingTimeText != null) {
            remainingTimeText.setText(duration > 0 && duration != C.TIME_UNSET
                    ? "-" + formatTime(Math.max(0L, duration - position)) : "--:--");
        }
        if (positionSeekBar != null && !isSeeking) {
            int progress = duration > 0 && duration != C.TIME_UNSET
                    ? (int) Math.min(1000L, position * 1000L / duration) : 0;
            positionSeekBar.setProgress(progress);
        }
        if (playPauseButton != null) playPauseButton.setText(controller.isPlaying() ? "Ⅱ" : "▶");
    }

    private void updateControlVisibility() {
        if (playerTools == null) return;
        if (inPictureInPicture) {
            playerTools.setVisibility(View.GONE);
            return;
        }
        boolean hasVideo = controller != null && controller.getCurrentMediaItem() != null;
        if (emptyState != null) emptyState.setVisibility(hasVideo ? View.GONE : View.VISIBLE);
        if (screenLocked) {
            topPanel.setVisibility(View.GONE);
            bottomPanel.setVisibility(View.GONE);
            lockButton.setVisibility(View.VISIBLE);
            lockButton.setText("🔒");
            if (displayToolsButton != null) displayToolsButton.setVisibility(View.GONE);
            if (statusText != null) statusText.setVisibility(View.GONE);
            return;
        }
        lockButton.setText("🔓");
        if (controlsVisible) {
            topPanel.setVisibility(View.VISIBLE);
            bottomPanel.setVisibility(hasVideo ? View.VISIBLE : View.GONE);
            lockButton.setVisibility(hasVideo ? View.VISIBLE : View.GONE);
            if (displayToolsButton != null) displayToolsButton.setVisibility(hasVideo ? View.VISIBLE : View.GONE);
            statusText.setVisibility(View.VISIBLE);
        } else {
            topPanel.setVisibility(View.GONE);
            bottomPanel.setVisibility(View.GONE);
            lockButton.setVisibility(View.GONE);
            if (displayToolsButton != null) displayToolsButton.setVisibility(View.GONE);
            statusText.setVisibility(View.GONE);
        }
        if (!hasVideo) {
            topPanel.setVisibility(View.GONE);
            bottomPanel.setVisibility(View.GONE);
            lockButton.setVisibility(View.GONE);
            if (displayToolsButton != null) displayToolsButton.setVisibility(View.GONE);
        }
    }

    private void showControls() {
        controlsVisible = true;
        updateControlVisibility();
        scheduleControlsAutoHide();
    }

    private void hideControls() {
        if (isSeeking || screenLocked || controller == null || !controller.isPlaying()) return;
        controlsVisible = false;
        updateControlVisibility();
    }

    private void scheduleControlsAutoHide() {
        handler.removeCallbacks(hideControlsRunnable);
        if (!screenLocked && controller != null && controller.isPlaying()) {
            handler.postDelayed(hideControlsRunnable, CONTROL_HIDE_DELAY_MS);
        }
    }

    private void toggleAudioOnly(TextView button) {
        audioOnly = !audioOnly;
        playerView.setVisibility(audioOnly ? View.INVISIBLE : View.VISIBLE);
        if (button != null) button.setText(audioOnly ? "▣" : "♫");
        toast(audioOnly ? "Audio-only playback enabled" : "Video display restored");
    }

    private void cycleAspectRatio() {
        if (resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT) {
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
            aspectButton.setText("▭");
            toast("Aspect ratio: Fill");
        } else if (resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FILL) {
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM;
            aspectButton.setText("⌕");
            toast("Aspect ratio: Zoom / Crop");
        } else {
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
            aspectButton.setText("↔");
            toast("Aspect ratio: Fit");
        }
        playerView.setResizeMode(resizeMode);
    }

    private void showPlayerMenu() {
        String[] options = {
                "All phone videos / folders", "Open videos / playlist", "Select audio track", "Select subtitle track",
                "Load external subtitle", "Playback speed", "Aspect ratio",
                "Repeat mode", "Shuffle on / off", "Current playlist",
                "Add / remove favorite", "Favorites", "Playback history",
                "Sleep timer", "Picture in Picture", "Rotate screen",
                "Display controls", "Stop playback", "Play HTTPS / RTSP link",
                "🎵 Background audio - exit player", "Audio-only screen (stay in player)",
                "⚡ Hold-to-fast-forward speed", "🔍 Reset pinch zoom"
        };
        new AlertDialog.Builder(this).setTitle("SR Video Player")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: openPhoneVideoLibrary(); break;
                        case 1: openVideos(); break;
                        case 2: chooseTrack(C.TRACK_TYPE_AUDIO); break;
                        case 3: chooseTrack(C.TRACK_TYPE_TEXT); break;
                        case 4: openSubtitle(); break;
                        case 5: chooseSpeed(); break;
                        case 6: chooseAspectRatio(); break;
                        case 7: chooseRepeatMode(); break;
                        case 8: toggleShuffle(); break;
                        case 9: showQueue(); break;
                        case 10: toggleFavorite(); break;
                        case 11: showFavorites(); break;
                        case 12: showHistory(); break;
                        case 13: chooseSleepTimer(); break;
                        case 14: enterPictureInPicture(); break;
                        case 15: toggleOrientation(); break;
                        case 16: showDisplayControlsDialog(); break;
                        case 17: stopPlayback(); break;
                        case 18: openNetworkUrl(); break;
                        case 19: exitPlayerKeepingAudio(); return;
                        case 20: toggleAudioOnly(null); break;
                        case 21: chooseHoldBoostSpeed(); break;
                        case 22: videoZoom = 1f;
                            View surface = playerView.getVideoSurfaceView();
                            if (surface != null) { surface.setScaleX(1f); surface.setScaleY(1f); }
                            break;
                    }
                    showControls();
                }).show();
    }

    private void showLibraryMenu() {
        String[] options = {"All phone videos", "Favorites", "Playback history", "Select videos"};
        new AlertDialog.Builder(this).setTitle("Video library")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) openPhoneVideoLibrary();
                    else if (which == 1) showFavorites();
                    else if (which == 2) showHistory();
                    else openVideos();
                }).show();
    }

    private void captureVideoFrame() {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            toast("আগে একটি ভিডিও চালু করুন।");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            toast("Screenshot requires Android 8.0 or later.");
            return;
        }
        View surface = playerView.getVideoSurfaceView();
        if (!(surface instanceof SurfaceView) || surface.getWidth() <= 0 || surface.getHeight() <= 0) {
            toast("এই ভিডিও Surface থেকে Screenshot নেওয়া যাচ্ছে না।");
            return;
        }
        Bitmap bitmap = Bitmap.createBitmap(surface.getWidth(), surface.getHeight(), Bitmap.Config.ARGB_8888);
        PixelCopy.request((SurfaceView) surface, bitmap, result -> {
            if (result != PixelCopy.SUCCESS) {
                bitmap.recycle();
                toast("Screenshot নেওয়া যায়নি। আবার চেষ্টা করুন।");
                return;
            }
            try {
                ContentValues values = new ContentValues();
                String name = "SR_Video_" + System.currentTimeMillis() + ".jpg";
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                            Environment.DIRECTORY_PICTURES + "/SR Smart Toolbox");
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                }
                Uri output = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (output == null) throw new IllegalStateException("Could not create image entry");
                try (OutputStream stream = getContentResolver().openOutputStream(output)) {
                    if (stream == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 92, stream)) {
                        throw new IllegalStateException("Could not write image");
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(output, done, null, null);
                }
                toast("Screenshot saved to Pictures / SR Smart Toolbox");
            } catch (Exception error) {
                toast("Screenshot সংরক্ষণ করা যায়নি।");
            } finally {
                bitmap.recycle();
            }
        }, handler);
    }

    @Override protected void onStart() {
        super.onStart();
        activityStarted = true;
        handler.removeCallbacks(savePositionRunnable);
        handler.removeCallbacks(progressUpdateRunnable);
        handler.post(savePositionRunnable);
        handler.post(progressUpdateRunnable);
        connectController();
    }

    private void connectController() {
        if (controllerFuture != null) return;
        SessionToken token = new SessionToken(this,
                new ComponentName(this, VideoPlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        final ListenableFuture<MediaController> requestedFuture = controllerFuture;
        requestedFuture.addListener(() -> {
            if (!activityStarted || requestedFuture != controllerFuture) {
                // onStop already releases any future that is no longer current.
                return;
            }
            try {
                controller = requestedFuture.get();
                playerView.setPlayer(controller);
                playerView.setKeepScreenOn(controller.isPlaying());
                controller.addListener(playerListener);
                syncPortraitVideoEdge();
                statusText.setText("Connected. Choose a video to start playback.");
                if (pendingItems != null && !pendingItems.isEmpty()) {
                    List<MediaItem> items = pendingItems;
                    pendingItems = null;
                    if (pendingResumePosition != C.TIME_UNSET && items.size() == 1) {
                        controller.setMediaItem(items.get(0), pendingResumePosition);
                        pendingResumePosition = C.TIME_UNSET;
                        controller.prepare();
                        controller.play();
                        setFullScreen(true);
                        showControls();
                    } else {
                        playItems(items);
                    }
                }
                updateNowPlaying();
                if (controller.getCurrentMediaItem() != null) setFullScreen(true);
            } catch (ExecutionException | InterruptedException error) {
                if (error instanceof InterruptedException) Thread.currentThread().interrupt();
                statusText.setText("Video service could not start. Please close and reopen the player.");
                Toast.makeText(this, "Could not connect to video playback service.", Toast.LENGTH_LONG).show();
                controllerFuture = null;
            } catch (RuntimeException error) {
                statusText.setText("Video service connection failed. Please retry.");
                Toast.makeText(this, "Could not connect to video playback service.", Toast.LENGTH_LONG).show();
                controllerFuture = null;
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void openPhoneVideoLibrary() {
        // Keep each video's saved position before navigating back to the library.
        saveResumePoint();
        startActivity(new Intent(this, VideoLibraryActivity.class));
    }

    private void openVideos() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Some providers label MKV/Matroska and less common containers as application/*.
        // Use the SAF picker broadly rather than hiding valid files behind video/* only.
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "video/*", "application/x-matroska", "video/x-matroska",
                "video/x-msvideo", "application/x-troff-msvideo",
                "application/vnd.apple.mpegurl", "application/x-mpegURL",
                "application/dash+xml", "application/vnd.ms-sstr+xml",
                "application/octet-stream"
        });
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_OPEN_VIDEOS);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "No file picker is available on this phone.", Toast.LENGTH_LONG).show();
        }
    }

    private void openSubtitle() {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            toast("আগে একটি ভিডিও চালু করুন।");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_OPEN_SUBTITLE);
        } catch (ActivityNotFoundException error) {
            toast("Subtitle picker পাওয়া যায়নি।");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_OPEN_VIDEOS) {
            List<Uri> uris = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    uris.add(data.getClipData().getItemAt(i).getUri());
                }
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            List<MediaItem> items = new ArrayList<>();
            for (Uri uri : uris) {
                takePersistableReadPermission(uri, data.getFlags());
                String title = getDisplayName(uri);
                items.add(createMediaItem(uri, title));
            }
            if (!items.isEmpty()) playItems(items);
        } else if (requestCode == REQUEST_OPEN_SUBTITLE && data.getData() != null) {
            Uri subtitleUri = data.getData();
            takePersistableReadPermission(subtitleUri, data.getFlags());
            attachSubtitle(subtitleUri);
        }
    }

    private void takePersistableReadPermission(Uri uri, int resultFlags) {
        try {
            int readFlag = resultFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            int persistableFlag = resultFlags & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION;
            if (readFlag != 0 && persistableFlag != 0) {
                getContentResolver().takePersistableUriPermission(uri, readFlag);
            }
        } catch (SecurityException | IllegalArgumentException ignored) {
            // Some document providers issue temporary grants only. Playback still works for this session.
        }
    }

    private void playItems(List<MediaItem> items) {
        if (controller == null) {
            pendingResumePosition = C.TIME_UNSET;
            pendingItems = new ArrayList<>(items);
            statusText.setText("Connecting to video service…");
            connectController();
            return;
        }
        if (items == null || items.isEmpty()) return;
        saveResumePoint();
        try {
            long start = C.TIME_UNSET;
            Uri uri = getUriFromItem(items.get(0));
            if (uri != null) {
                if (forceRestartNextSelection) {
                    // An explicit Restart removes this video's old bookmark.
                    VideoResumeStore.put(this, uri.toString(), 0L, 0L, false);
                } else {
                    long saved = VideoResumeStore.get(this, uri.toString());
                    if (VideoResumeLogic.shouldResume(saved, -1L)) start = saved;
                }
            }
            // Suppress a duplicate seek in the transition listener for this first item.
            skipAutoResumeForTransition = true;
            controller.setMediaItems(items, 0, start);
            forceRestartNextSelection = false;
            controller.prepare();
            controller.play();
            setFullScreen(true);
            statusText.setText(start > 0 ? "Resumed from " + formatTime(start)
                    : items.size() == 1 ? "Video loaded." : items.size() + " videos added to playlist.");
            updateNowPlaying();
            showControls();
        } catch (RuntimeException error) {
            forceRestartNextSelection = false;
            skipAutoResumeForTransition = false;
            statusText.setText("ভিডিওটি খোলা যায়নি। অন্য ফাইল নির্বাচন করুন।");
        }
    }

    private void openNetworkUrl() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://example.com/video.m3u8  or  rtsp://camera/stream");
        new AlertDialog.Builder(this)
                .setTitle("Play network video")
                .setMessage("Secure HTTPS / RTSP video URL, HLS (.m3u8) or DASH (.mpd)")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Play", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (!VideoPlayerLogic.isNetworkUrl(value)) {
                        toast("সঠিক HTTPS অথবা RTSP ভিডিও লিংক দিন।");
                        return;
                    }
                    Uri uri = Uri.parse(value);
                    MediaItem item = createMediaItem(uri, VideoPlayerLogic.titleFromUrl(value));
                    playItems(Collections.singletonList(item));
                }).show();
    }

    private void resumeLastVideo() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String savedUri = prefs.getString("last_uri", null);
        if (savedUri == null || savedUri.trim().isEmpty()) {
            toast("এখনো কোনো ভিডিওর Resume তথ্য নেই।");
            return;
        }
        try {
            Uri uri = Uri.parse(savedUri);
            long position = Math.max(0L, prefs.getLong("last_position", 0L));
            MediaItem item = createMediaItem(uri, prefs.getString("last_title", getDisplayName(uri)));
            if (controller == null) {
                pendingItems = Collections.singletonList(item);
                pendingResumePosition = position;
                connectController();
                return;
            }
            controller.setMediaItem(item, position);
            controller.prepare();
            controller.play();
            setFullScreen(true);
            showControls();
        } catch (SecurityException error) {
            toast("ফাইলের অনুমতি আর পাওয়া যাচ্ছে না। ভিডিওটি আবার নির্বাচন করুন।");
        } catch (RuntimeException error) {
            toast("শেষ ভিডিওটি পুনরায় খোলা যায়নি।");
        }
    }


    private void updateNowPlaying() {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            if (nowPlayingText != null) nowPlayingText.setText("SR Video Player");
            if (statusText != null) statusText.setText("Select a video to start playback");
            updateControlVisibility();
            updatePlaybackUi();
            return;
        }
        MediaItem item = controller.getCurrentMediaItem();
        String title = item.mediaMetadata.title == null
                ? getTitleFromItem(item) : item.mediaMetadata.title.toString();
        nowPlayingText.setText(title + "  ·  " +
                (controller.getCurrentMediaItemIndex() + 1) + "/" + controller.getMediaItemCount());
        long duration = controller.getDuration();
        statusText.setText(controller.isPlaying()
                ? "Playing  •  " + formatTime(controller.getCurrentPosition()) + " / " + formatTime(duration)
                : "Paused  •  " + formatTime(controller.getCurrentPosition()) + " / " + formatTime(duration));
        updateControlVisibility();
        updatePlaybackUi();
    }

    private String getTitleFromItem(MediaItem item) {
        try {
            Uri uri = getUriFromItem(item);
            if (uri != null) return getDisplayName(uri);
        } catch (Exception ignored) {}
        return "Video";
    }

    private MediaItem createMediaItem(Uri uri, String title) {
        MediaMetadata metadata = new MediaMetadata.Builder()
                .setTitle(title == null || title.trim().isEmpty() ? "Video" : title)
                .build();
        MediaItem.Builder builder = new MediaItem.Builder()
                .setUri(uri)
                // Keep the URI in mediaId as a fallback because session IPC may omit localConfiguration.
                .setMediaId(uri.toString())
                .setMediaMetadata(metadata);
        String mimeType = getContentResolver().getType(uri);
        if (mimeType != null) builder.setMimeType(mimeType);
        return builder.build();
    }

    private Uri getUriFromItem(MediaItem item) {
        if (item == null) return null;
        if (item.localConfiguration != null && item.localConfiguration.uri != null) {
            return item.localConfiguration.uri;
        }
        String mediaId = item.mediaId;
        if (mediaId != null && !mediaId.trim().isEmpty()) {
            Uri parsed = Uri.parse(mediaId);
            String scheme = parsed.getScheme();
            if ("content".equalsIgnoreCase(scheme) || "file".equalsIgnoreCase(scheme)
                    || "https".equalsIgnoreCase(scheme) || "rtsp".equalsIgnoreCase(scheme)) {
                return parsed;
            }
        }
        return null;
    }

    private String getDisplayName(Uri uri) {
        String result = uri.getLastPathSegment();
        try (android.database.Cursor cursor = getContentResolver().query(
                uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (column >= 0) result = cursor.getString(column);
            }
        } catch (Exception ignored) {}
        if (result == null || result.trim().isEmpty()) result = "Video";
        return result;
    }

    private void saveResumePoint() {
        if (controller == null || controller.getCurrentMediaItem() == null) return;
        // Do not accidentally erase a bookmark when another item is still preparing.
        if (controller.getPlaybackState() == Player.STATE_IDLE) return;
        MediaItem item = controller.getCurrentMediaItem();
        Uri uri = getUriFromItem(item);
        if (uri == null) return;
        long duration = controller.getDuration();
        boolean ended = playbackEnded || controller.getPlaybackState() == Player.STATE_ENDED;
        long position = Math.max(0L, controller.getCurrentPosition());
        // During a brief initial buffer, avoid erasing a useful saved bookmark
        // with an accidental zero before the player's first frame is ready.
        if (!ended && position < 2_000L
                && VideoResumeLogic.shouldResume(VideoResumeStore.get(this, uri.toString()), duration)) {
            return;
        }
        long saved = VideoResumeLogic.positionToSave(position, duration, ended);
        VideoResumeStore.put(this, uri.toString(), position, duration, ended);
        // Keep the existing one-tap Continue last video shortcut as well.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("last_uri", uri.toString())
                .putString("last_title", getTitleFromItem(item))
                .putLong("last_position", saved)
                .apply();
    }

    private void rememberHistory(MediaItem item) {
        Uri itemUri = getUriFromItem(item);
        if (itemUri == null) return;
        String uri = itemUri.toString();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> history = new HashSet<>(prefs.getStringSet("history", Collections.emptySet()));
        history.remove(uri);
        history.add(uri);
        if (history.size() > 30) {
            // Keep the newest set bounded. The set is only a convenience list; URI order is not promised.
            history.clear();
            history.add(uri);
        }
        prefs.edit().putStringSet("history", history).apply();
    }

    private void toggleFavorite() {
        MediaItem item = controller == null ? null : controller.getCurrentMediaItem();
        Uri itemUri = getUriFromItem(item);
        if (itemUri == null) {
            toast("আগে একটি ভিডিও চালু করুন।");
            return;
        }
        String uri = itemUri.toString();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> favorites = new HashSet<>(prefs.getStringSet("favorites", Collections.emptySet()));
        boolean removed = favorites.remove(uri);
        if (!removed) favorites.add(uri);
        prefs.edit().putStringSet("favorites", favorites).apply();
        toast(removed ? "Favorites থেকে সরানো হয়েছে।" : "Favorites-এ যোগ করা হয়েছে।");
    }

    private void showFavorites() {
        Set<String> favorites = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getStringSet("favorites", Collections.emptySet());
        if (favorites.isEmpty()) {
            toast("এখনো কোনো Favorite ভিডিও নেই।");
            return;
        }
        List<String> uris = new ArrayList<>(favorites);
        String[] labels = new String[uris.size()];
        for (int i = 0; i < uris.size(); i++) labels[i] = getDisplayName(Uri.parse(uris.get(i)));
        new AlertDialog.Builder(this).setTitle("Favorite videos")
                .setItems(labels, (dialog, which) -> {
                    Uri uri = Uri.parse(uris.get(which));
                    playItems(Collections.singletonList(createMediaItem(uri, labels[which])));
                })
                .setNegativeButton("Close", null).show();
    }

    private void showHistory() {
        Set<String> history = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getStringSet("history", Collections.emptySet());
        if (history.isEmpty()) {
            toast("এখনো কোনো Playback History নেই।");
            return;
        }
        List<String> uris = new ArrayList<>(history);
        String[] labels = new String[uris.size()];
        for (int i = 0; i < uris.size(); i++) labels[i] = getDisplayName(Uri.parse(uris.get(i)));
        new AlertDialog.Builder(this).setTitle("Playback history")
                .setItems(labels, (dialog, which) -> {
                    Uri uri = Uri.parse(uris.get(which));
                    playItems(Collections.singletonList(createMediaItem(uri, labels[which])));
                })
                .setNegativeButton("Close", null).show();
    }

    private void showQueue() {
        if (controller == null || controller.getMediaItemCount() == 0) {
            toast("Playlist খালি।");
            return;
        }
        int count = controller.getMediaItemCount();
        String[] labels = new String[count];
        for (int i = 0; i < count; i++) labels[i] = (i + 1) + ". " + getTitleFromItem(controller.getMediaItemAt(i));
        new AlertDialog.Builder(this).setTitle("Current playlist")
                .setSingleChoiceItems(labels, controller.getCurrentMediaItemIndex(), (dialog, which) -> {
                    saveResumePoint();
                    controller.seekTo(which, 0L);
                    controller.play();
                    dialog.dismiss();
                }).setNegativeButton("Close", null).show();
    }

    private void previousVideo() {
        if (controller == null || controller.getMediaItemCount() == 0) return;
        saveResumePoint();
        if (controller.hasPreviousMediaItem()) controller.seekToPreviousMediaItem();
        else controller.seekTo(0L);
    }

    private void nextVideo() {
        if (controller != null && controller.hasNextMediaItem()) {
            saveResumePoint();
            controller.seekToNextMediaItem();
        }
    }

    private void toggleShuffle() {
        if (controller == null) return;
        boolean enabled = !controller.getShuffleModeEnabled();
        controller.setShuffleModeEnabled(enabled);
        toast(enabled ? "Shuffle enabled" : "Shuffle disabled");
    }

    private void chooseRepeatMode() {
        if (controller == null) return;
        String[] modes = {"Off", "Repeat current video", "Repeat playlist"};
        new AlertDialog.Builder(this).setTitle("Repeat mode")
                .setSingleChoiceItems(modes, controller.getRepeatMode(), (dialog, which) -> {
                    int mode = which == 1 ? Player.REPEAT_MODE_ONE
                            : which == 2 ? Player.REPEAT_MODE_ALL : Player.REPEAT_MODE_OFF;
                    controller.setRepeatMode(mode);
                    dialog.dismiss();
                }).setNegativeButton("Cancel", null).show();
    }

    private void chooseHoldBoostSpeed() {
        float[] speeds = {2f, 2.5f, 3f, 4f, 5f};
        String[] labels = {"2×", "2.5×", "3×", "4×", "5×"};
        new AlertDialog.Builder(this).setTitle("Hold-to-fast-forward speed")
                .setSingleChoiceItems(labels, -1, (dialog, which) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putFloat("hold_boost_speed", speeds[which]).apply();
                    toast("Hold speed saved: " + labels[which]);
                    dialog.dismiss();
                }).setNegativeButton("Cancel", null).show();
    }

    private void chooseSpeed() {
        if (controller == null) return;
        float[] speeds = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f};
        String[] labels = {"0.5×", "0.75×", "1.0×", "1.25×", "1.5×", "1.75×", "2.0×", "2.5×", "3.0×"};
        new AlertDialog.Builder(this).setTitle("Playback speed")
                .setSingleChoiceItems(labels, -1, (dialog, which) -> {
                    controller.setPlaybackParameters(new PlaybackParameters(speeds[which]));
                    if (speedButton != null) speedButton.setText(labels[which].replace(".0×", "×"));
                    statusText.setText("Playback speed: " + labels[which]);
                    dialog.dismiss();
                }).setNegativeButton("Cancel", null).show();
    }

    private void chooseAspectRatio() {
        String[] labels = {"Fit", "Fill", "Zoom / Crop"};
        int[] modes = {AspectRatioFrameLayout.RESIZE_MODE_FIT,
                AspectRatioFrameLayout.RESIZE_MODE_FILL,
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM};
        new AlertDialog.Builder(this).setTitle("Video aspect ratio")
                .setSingleChoiceItems(labels, resizeMode == modes[0] ? 0 : resizeMode == modes[1] ? 1 : 2,
                        (dialog, which) -> {
                            resizeMode = modes[which];
                            playerView.setResizeMode(resizeMode);
                            if (aspectButton != null) {
                                aspectButton.setText(which == 0 ? "↔" : which == 1 ? "▭" : "⌕");
                            }
                            dialog.dismiss();
                        }).setNegativeButton("Cancel", null).show();
    }

    private void chooseTrack(int trackType) {
        if (controller == null || controller.getCurrentMediaItem() == null) {
            toast("আগে একটি ভিডিও চালু করুন।");
            return;
        }
        List<TrackChoice> choices = new ArrayList<>();
        if (trackType == C.TRACK_TYPE_TEXT) choices.add(TrackChoice.off());
        Tracks tracks = controller.getCurrentTracks();
        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() != trackType) continue;
            for (int i = 0; i < group.length; i++) {
                if (!group.isTrackSupported(i)) continue;
                Format format = group.getTrackFormat(i);
                String label = format.label;
                if (label == null || label.trim().isEmpty()) label = format.language;
                if (label == null || label.trim().isEmpty()) label = "Track " + (i + 1);
                if (format.sampleMimeType != null) label += "  ·  " + format.sampleMimeType;
                choices.add(new TrackChoice(group, i, label, false));
            }
        }
        if (choices.size() <= (trackType == C.TRACK_TYPE_TEXT ? 1 : 0)) {
            toast(trackType == C.TRACK_TYPE_AUDIO
                    ? "এই ভিডিওতে আলাদা Audio Track পাওয়া যায়নি।"
                    : "Subtitle Track পাওয়া যায়নি। External Subtitle যোগ করতে পারেন।");
            return;
        }
        String[] labels = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) labels[i] = choices.get(i).label;
        new AlertDialog.Builder(this)
                .setTitle(trackType == C.TRACK_TYPE_AUDIO ? "Select audio track" : "Select subtitle track")
                .setItems(labels, (dialog, which) -> applyTrackChoice(trackType, choices.get(which)))
                .setNegativeButton("Cancel", null).show();
    }

    private void applyTrackChoice(int trackType, TrackChoice choice) {
        TrackSelectionParameters.Builder builder =
                controller.getTrackSelectionParameters().buildUpon()
                        .clearOverridesOfType(trackType);
        if (choice.off) {
            builder.setTrackTypeDisabled(trackType, true);
        } else {
            builder.setTrackTypeDisabled(trackType, false);
            builder.addOverride(new TrackSelectionOverride(choice.group.getMediaTrackGroup(), choice.trackIndex));
        }
        controller.setTrackSelectionParameters(builder.build());
        toast(choice.off ? "Subtitles off" : "Track selected");
    }

    private void attachSubtitle(Uri subtitleUri) {
        MediaItem current = controller == null ? null : controller.getCurrentMediaItem();
        Uri currentUri = getUriFromItem(current);
        if (current == null || currentUri == null) {
            toast("বর্তমান ভিডিওর URI পাওয়া যায়নি।");
            return;
        }
        String name = getDisplayName(subtitleUri);
        String mime = VideoPlayerLogic.subtitleMimeType(name);
        if (mime == null) {
            toast("এই Subtitle ফরম্যাট সমর্থিত নয়। SRT, VTT, ASS বা TTML ব্যবহার করুন।");
            return;
        }
        try {
            MediaItem.SubtitleConfiguration subtitle =
                    new MediaItem.SubtitleConfiguration.Builder(subtitleUri)
                            .setMimeType(mime)
                            .setLanguage("und")
                            .setLabel(name)
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                            .build();
            long position = controller.getCurrentPosition();
            boolean wasPlaying = controller.getPlayWhenReady();
            MediaItem.Builder updatedBuilder = new MediaItem.Builder()
                    .setUri(currentUri)
                    .setMediaId(currentUri.toString())
                    .setMediaMetadata(current.mediaMetadata)
                    .setSubtitleConfigurations(Collections.singletonList(subtitle));
            String originalMimeType = getContentResolver().getType(currentUri);
            if (originalMimeType != null) updatedBuilder.setMimeType(originalMimeType);
            MediaItem updated = updatedBuilder.build();
            controller.setMediaItem(updated, position);
            controller.setTrackSelectionParameters(controller.getTrackSelectionParameters()
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .build());
            controller.prepare();
            controller.setPlayWhenReady(wasPlaying);
            toast("External subtitle যুক্ত হয়েছে।");
        } catch (RuntimeException error) {
            toast("Subtitle যুক্ত করা যায়নি। ফাইলটি পরীক্ষা করুন।");
        }
    }

    private void chooseSleepTimer() {
        String[] options = {"10 minutes", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "Cancel timer"};
        long[] durations = {10, 15, 30, 45, 60};
        new AlertDialog.Builder(this).setTitle("Sleep timer")
                .setItems(options, (dialog, which) -> {
                    if (sleepTimer != null) {
                        sleepTimer.cancel();
                        sleepTimer = null;
                    }
                    if (which == 5) {
                        VideoPlaybackService.cancelSleepTimer();
                        toast("Sleep timer cancelled.");
                        return;
                    }
                    long millis = durations[which] * 60_000L;
                    if (controller == null || !controller.isPlaying()) {
                        toast("Sleep timer চালু করতে আগে ভিডিও Play করুন।");
                        return;
                    }
                    if (!VideoPlaybackService.scheduleSleepTimer(millis)) {
                        toast("Video playback service is not ready. Start a video first.");
                        return;
                    }
                    sleepTimer = new CountDownTimer(millis, 1000L) {
                        @Override public void onTick(long remaining) {
                            statusText.setText("Sleep timer: " + (remaining / 60_000L) + "m " +
                                    ((remaining / 1000L) % 60L) + "s");
                        }
                        @Override public void onFinish() {
                            statusText.setText("Sleep timer finished. Background playback stopped.");
                            sleepTimer = null;
                        }
                    }.start();
                }).show();
    }

    private void toggleScreenLock() {
        screenLocked = !screenLocked;
        if (screenLocked) {
            handler.removeCallbacks(hideControlsRunnable);
            controlsVisible = true;
        } else {
            showControls();
        }
        updateControlVisibility();
        toast(screenLocked ? "Player controls locked. Tap the lock to unlock."
                : "Player controls unlocked.");
    }

    private void setFullScreen(boolean enabled) {
        if (fullScreen != enabled) {
            fullScreen = enabled;
            landscape = enabled;
            if (enabled) {
                if (screenLocked) screenLocked = false;
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            } else {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            }
        }
        if (enabled) {
            applyImmersiveSystemBars();
        } else {
            // Re-show the system bars for the next Activity, including the library.
            getWindow().getDecorView().setSystemUiVisibility(originalSystemUiVisibility);
            WindowCompat.getInsetsController(getWindow(), rootPage)
                    .show(WindowInsetsCompat.Type.systemBars());
        }
        updateControlVisibility();
    }

    private void applyImmersiveSystemBars() {
        if (!fullScreen || inPictureInPicture || rootPage == null) return;
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), rootPage);
        // Swiping down from the top reveals a temporary notification/status bar.
        // Android hides it again automatically when the transient overlay times out.
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        controller.hide(WindowInsetsCompat.Type.systemBars());
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && fullScreen && !isFinishing()) applyImmersiveSystemBars();
    }

    @android.annotation.TargetApi(33)
    private void registerSystemBack() {
        modernBackCallback = this::exitPlayerAndStop;
        getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, modernBackCallback);
    }

    @android.annotation.TargetApi(33)
    private void unregisterSystemBack() {
        if (modernBackCallback == null) return;
        getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(modernBackCallback);
        modernBackCallback = null;
    }

    private void disableAutoPictureInPictureOnExit() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                setPictureInPictureParams(new PictureInPictureParams.Builder()
                        .setAutoEnterEnabled(false).build());
            } catch (RuntimeException ignored) {
                // Some devices do not support changing PiP parameters when closing.
            }
        }
    }

    /** Normal back always stops the MediaSessionService player and saves the resume point. */
    private void exitPlayerAndStop() {
        if (explicitPlayerExit) return;
        explicitPlayerExit = true;
        exitingForBackgroundAudio = false;
        disableAutoPictureInPictureOnExit();
        if (VideoExitPolicy.shouldStopPlayback(exitingForBackgroundAudio)) {
            stopPlayback();
            // Also handles a MediaController connection still in flight.
            VideoPlaybackService.stopCurrentPlayback();
        }
        finish();
    }

    /** The music icon is the ONLY exit path that intentionally keeps audio playing. */
    private void exitPlayerKeepingAudio() {
        if (explicitPlayerExit) return;
        if (!VideoExitPolicy.canKeepAudio(
                controller != null && controller.getCurrentMediaItem() != null)) {
            toast("প্রথমে একটি ভিডিও চালু করুন, তারপর 🎵 বাটনে চাপ দিন।");
            return;
        }
        explicitPlayerExit = true;
        exitingForBackgroundAudio = true;
        disableAutoPictureInPictureOnExit();
        // Keep the MediaSessionService and its media notification active.
        // Releasing the Activity's controller in onStop does not stop the service.
        saveResumePoint();
        if (!controller.isPlaying()) controller.play();
        if (fullScreen) setFullScreen(false);
        toast("🎵 Background Audio চলছে। Notification থেকে Pause করতে পারবেন।");
        finish();
    }

    private void toggleOrientation() {
        landscape = !landscape;
        setRequestedOrientation(landscape
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
    }

    private void enterPictureInPicture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            toast("Picture-in-Picture requires Android 8.0 or later.");
            return;
        }
        if (controller == null || !controller.isPlaying()) {
            toast("আগে ভিডিও চালু করুন।");
            return;
        }
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            toast("এই ডিভাইসে Picture-in-Picture সমর্থিত নয়।");
            return;
        }
        try {
            wasFullScreenBeforePip = fullScreen;
            if (!fullScreen) setFullScreen(true);
            PictureInPictureParams.Builder builder =
                    new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) builder.setAutoEnterEnabled(true);
            boolean entered = enterPictureInPictureMode(builder.build());
            if (!entered && !wasFullScreenBeforePip) setFullScreen(false);
        } catch (IllegalStateException | IllegalArgumentException error) {
            if (!wasFullScreenBeforePip) setFullScreen(false);
            toast("Picture-in-Picture চালু করা যায়নি।");
        }
    }

    @Override public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (VideoExitPolicy.mayAutoEnterPictureInPicture(explicitPlayerExit)
                && !exitingForBackgroundAudio
                && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                && controller != null && controller.isPlaying()
                && getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            try {
                wasFullScreenBeforePip = fullScreen;
                if (!fullScreen) setFullScreen(true);
                boolean entered = enterPictureInPictureMode(new PictureInPictureParams.Builder()
                        .setAspectRatio(new Rational(16, 9)).build());
                if (!entered && !wasFullScreenBeforePip) setFullScreen(false);
            } catch (RuntimeException ignored) {
                if (!wasFullScreenBeforePip) setFullScreen(false);
            }
        }
    }

    @Override public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        inPictureInPicture = isInPictureInPictureMode;
        syncPortraitVideoEdge();
        if (playerTools != null) {
            playerTools.setVisibility(inPictureInPicture ? View.GONE : View.VISIBLE);
        }
        if (!inPictureInPicture) {
            if (!wasFullScreenBeforePip && fullScreen) setFullScreen(false);
            wasFullScreenBeforePip = false;
            showControls();
        }
    }

    private void stopPlayback() {
        VideoPlaybackService.cancelSleepTimer();
        if (sleepTimer != null) {
            sleepTimer.cancel();
            sleepTimer = null;
        }
        if (controller != null) {
            saveResumePoint();
            controller.stop();
            controller.clearMediaItems();
            statusText.setText("Playback stopped.");
            nowPlayingText.setText("SR Video Player");
        }
        screenLocked = false;
        setFullScreen(false);
        updateControlVisibility();
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    private String formatTime(long millis) {
        if (millis < 0 || millis == C.TIME_UNSET) return "--:--";
        long totalSeconds = millis / 1000L;
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        return hours > 0
                ? String.format(java.util.Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
                : String.format(java.util.Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    @Override protected void onPause() {
        if (portraitVideoEdgeActive) {
            portraitVideoEdgeActive = false;
            VideoPlaybackEdgeBridge.onStopped(this);
        }
        saveResumePoint();
        super.onPause();
    }

    @Override protected void onStop() {
        if (portraitVideoEdgeActive) {
            portraitVideoEdgeActive = false;
            VideoPlaybackEdgeBridge.onStopped(this);
        }
        activityStarted = false;
        handler.removeCallbacks(savePositionRunnable);
        handler.removeCallbacks(progressUpdateRunnable);
        handler.removeCallbacks(hideControlsRunnable);
        saveResumePoint();
        if (controller != null) {
            controller.removeListener(playerListener);
            playerView.setKeepScreenOn(false);
            playerView.setPlayer(null);
            controller = null;
        }
        if (controllerFuture != null) {
            MediaController.releaseFuture(controllerFuture);
            controllerFuture = null;
        }
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            unregisterSystemBack();
        }
        handler.removeCallbacks(savePositionRunnable);
        handler.removeCallbacks(progressUpdateRunnable);
        handler.removeCallbacks(hideControlsRunnable);
        if (sleepTimer != null) sleepTimer.cancel();
        super.onDestroy();
    }


    @Override public void onBackPressed() {
        if (inPictureInPicture) return;
        exitPlayerAndStop();
    }

    private static final class TrackChoice {
        final Tracks.Group group;
        final int trackIndex;
        final String label;
        final boolean off;

        TrackChoice(Tracks.Group group, int trackIndex, String label, boolean off) {
            this.group = group;
            this.trackIndex = trackIndex;
            this.label = label;
            this.off = off;
        }

        static TrackChoice off() {
            return new TrackChoice(null, -1, "Off", true);
        }
    }

    private boolean portraitVideoEdgeActive;

    private void syncPortraitVideoEdge() {
        boolean shouldPin = controller != null && controller.isPlaying()
                && !inPictureInPicture
                && getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT;
        if (shouldPin == portraitVideoEdgeActive) return;
        portraitVideoEdgeActive = shouldPin;
        if (shouldPin) VideoPlaybackEdgeBridge.onPlaying(this);
        else VideoPlaybackEdgeBridge.onStopped(this);
    }

    @Override protected void onResume() {
        super.onResume();
        syncPortraitVideoEdge();
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        srVideoEdgeConfigurationChanged(newConfig);
    }

    private void srVideoEdgeConfigurationChanged(android.content.res.Configuration config) {
        syncPortraitVideoEdge();
    }
}
