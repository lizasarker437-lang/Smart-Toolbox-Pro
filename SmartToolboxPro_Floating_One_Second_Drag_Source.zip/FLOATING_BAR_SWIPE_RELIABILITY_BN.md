# SR Smart Toolbox Pro — Floating Bar Swipe Reliability

**Release:** 1.5.9-alpha35 (`versionCode 35`)

## কী ঠিক করা হয়েছে
- **Home Screen, SR অ্যাপের ভেতর, YouTube, Gallery, Browser বা অন্যান্য অ্যাপে** Floating Icon/Edge Bar দৃশ্যমান থাকলে সেটির ওপর আঙুল দিয়ে Slide বা Tap করলে Quick Controls Menu খোলার ব্যবস্থা উন্নত করা হয়েছে। এটি নিজের অ্যাপের স্ক্রিনে সীমাবদ্ধ নয়; FloatingControlService-এর System Overlay-এর Touch Handling আপডেট হয়েছে।
- **ছোট Edge Tab:** বাম/ডান কিনারার ওপর দিয়ে ভেতরের দিকে, ওপরের দিকে বা নিচের দিকে Slide করলে Menu খুলবে। Tap-ও কাজ করবে। এখন আঙুল ওঠার (`ACTION_UP`) **আগে Edge Handle সরানো হয় না**, যাতে Android-এর চলমান Touch Event হারিয়ে না যায়।
- **বড় ST Floating Bubble:** Tap অথবা দ্রুত ভেতরের দিকে/উপর-নিচে Slide করলে Menu খুলবে। Bubble **অন্য জায়গায় সরাতে** আঙুল কিছুক্ষণ (প্রায় ০.৫ সেকেন্ড) চেপে রেখে Drag করতে হবে।
- **Touch Target:** Edge Tab দেখতে আগের মতো সরু হলেও Tap/Slide ধরার অদৃশ্য জায়গা ৪৪dp চওড়া ও ৯২dp উঁচু করা হয়েছে, যাতে আঙুল দিয়ে সহজে ব্যবহার করা যায়।
- **Animation fallback:** Edge Tab-এর Reveal Animation কোনো কারণে বন্ধ হলে একবার Menu Open করার চেষ্টা হবে। Menu সফলভাবে খুললে ওই fallback বাতিল হবে, যাতে ব্যবহারকারী বন্ধ করার পর আবার খুলে না যায়।
- **Portrait Edge — ALL Apps**, আগের Theme, Scheduler Notepad, Video Player, Group Scheduler, Auto-Hide ও Floating Menu-এর কন্ট্রোল রেখে পরিবর্তন করা হয়েছে।

## ব্যবহার
1. Android-এর **Display over other apps** Permission দিন।
2. **Floating Icon Settings → Keep floating sidebar available** চালু রাখুন।
3. **Open quick controls by tapping or sliding the floating bar** চালু রাখুন।
4. প্রয়োজনমতো **Portrait Edge — ALL apps** চালু রাখুন।
5. Home, Chrome বা YouTube-এ Floating Bar-এর **দৃশ্যমান ট্যাবের ওপর থেকে** Slide করুন। Menu খুলে যাওয়ার পর Night Screen/Volume Boost/Other Quick Controls পাওয়া যাবে।

## বাস্তব সীমা
- Android-এর System Gesture Navigation, Secure/Protected Windows, OEM Overlay Restrictions, Permission বন্ধ থাকা বা Service বন্ধ হয়ে গেলে কোনো তৃতীয় পক্ষের Overlay সব অবস্থায় ১০০% Touch Event পায় না। তাই সব ফোনে সর্বদা কাজের গ্যারান্টি দেওয়া সম্ভব নয়।
- অন্য অ্যাপের স্ক্রিনের **যেকোনো জায়গা থেকে** Swipe করে মেনু খোলার ব্যবস্থা নয়; Swipe শুরু করতে হবে **Floating Bar/Icon-এর Touch Area** থেকে। অন্য অ্যাপের সাধারণ Touch Events ইচ্ছাকৃতভাবে পর্যবেক্ষণ করা হয় না।
- User যদি Floating Menu নিজে Settings থেকে OFF করেন, Slide করে জোর করে Menu খোলা হবে না।
- Panel ৩ সেকেন্ড Idle থাকলে আগের মতো Close হতে পারে; এটি পূর্বের নির্ধারিত আচরণ।

## যাচাই
- `FloatingBarGestureLogicTest`: **২৫টি** Java Gesture Test PASS।
- আগের `EdgeSwipeLogicTest`: **৯টি** PASS।
- GitHub Workflow-এর সমস্ত স্থানীয় source/unit validation steps PASS।
- Java AST, Android XML ও YAML Checks PASS।
- **পূর্ণ Gradle APK Build এবং বাস্তব ফোনে Gesture Test এই পরিবেশে করা হয়নি** (Android SDK/Gradle অনুপস্থিত)। GitHub Actions-এ Build ও ফোনে পরীক্ষা করতে হবে।
