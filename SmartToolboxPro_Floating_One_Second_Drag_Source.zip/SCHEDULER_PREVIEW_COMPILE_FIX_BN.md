# Scheduler Preview Compile Fix — 1.5.4-alpha30

## Root cause
`MessageSchedulerActivity.java` called `SchedulerDisplayLogic.messagePreview(entry.message, 100)`, but `SchedulerDisplayLogic` did not declare that method. Java therefore stopped at `:app:compileDebugJavaWithJavac` with `cannot find symbol`.

## Fix
Added `SchedulerDisplayLogic.messagePreview(String, int)` as a small adapter to the existing shared `MessageScheduleLogic.messagePreview(String, int)`. This reuses the established whitespace normalization and truncation behavior rather than duplicating formatting logic.

Added regression cases for:
- leading/trailing whitespace and repeated whitespace;
- truncation with an ellipsis;
- null input.

Added a GitHub Actions source guard requiring the method declaration.

## Local verification
- SchedulerDisplayLogicTest: 21 checks PASS.
- RecipientSelectionLogicTest: 8 checks PASS.
- SchedulerTemplateLogicTest: 7 checks PASS.
- GroupScheduleLogicTest: 14 checks PASS.
- All 13 workflow pure-Java compile/test steps: PASS.
- Java AST syntax / duplicate-field scan: 48 files PASS.
- Six additional source / manifest / workflow static checks: PASS.

## Important boundary
This workspace has no Android SDK or Gradle executable, so `:app:assembleDebug` was not run locally. A successful GitHub Actions Android build and real-device testing are still required before treating the APK as release-ready.
