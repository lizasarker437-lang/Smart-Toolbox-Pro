package com.smarttoolbox.pro;

public final class FloatingOpenModeLogicTest {
    private static int n;
    private static void ok(boolean value, String label) { n++; if (!value) throw new AssertionError(label); }
    private static boolean open(boolean tap, boolean swipe, boolean panel, boolean dragged,
                                boolean movedEarly, long elapsed, float dx, float dy) {
        return FloatingOpenModeLogic.shouldOpen(tap, swipe, panel, dragged, movedEarly,
                elapsed, dx, dy, 10, 18);
    }
    public static void main(String[] args) {
        ok(FloatingOpenModeLogic.HOLD_TO_MOVE_MS == 2000, "exact two-second hold");
        ok(!FloatingOpenModeLogic.startDrag(1999, false, 200, 1, 10), "early large move not drag");
        ok(FloatingOpenModeLogic.startDrag(2000, false, 12, 0, 10), "two-second stationary press and move");
        ok(FloatingOpenModeLogic.startDrag(2500, false, 0, -30, 10), "vertical drag after hold");
        ok(!FloatingOpenModeLogic.startDrag(2500, true, 50, 0, 10), "early swipe never becomes drag");
        ok(!FloatingOpenModeLogic.startDrag(2500, false, 1, 1, 10), "jitter not drag");
        ok(FloatingOpenModeLogic.movedTooEarly(1999, 13, 0, 10), "record early motion");
        ok(!FloatingOpenModeLogic.movedTooEarly(2000, 15, 0, 10), "long press armed");
        ok(!FloatingOpenModeLogic.movedTooEarly(900, 2, 3, 10), "jitter safe");
        ok(open(true,false,true,false,false,150,0,0), "tap-only opens tap");
        ok(!open(false,true,true,false,false,150,0,0), "swipe-only blocks tap");
        ok(open(false,true,true,false,true,250,30,0), "swipe-only opens horizontal swipe");
        ok(open(false,true,true,false,true,350,0,-40), "swipe-only opens vertical swipe");
        ok(!open(true,false,true,false,true,250,30,0), "tap-only blocks swipe");
        ok(open(true,true,true,false,false,150,0,0), "both enabled tap");
        ok(open(true,true,true,false,true,250,-30,0), "both enabled swipe");
        ok(!open(false,false,true,false,false,150,0,0), "both off tap blocked");
        ok(!open(false,false,true,false,true,300,40,0), "both off swipe blocked");
        ok(!open(true,true,false,false,false,100,0,0), "master panel disabled");
        ok(!open(true,true,true,true,false,2300,45,0), "moving not open");
        ok(!open(true,true,true,false,false,2300,0,0), "stationary hold release not tap");
        ok(open(false,true,true,false,true,2500,60,0), "slow early swipe stays swipe, not drag");
        ok(!open(false,true,true,false,true,250,10,0), "not enough swipe");
        ok(!open(true,true,true,false,false,-100,0,0), "negative elapsed safe");
        ok(!open(true,false,true,false,false,2000,0,0), "2-second release not tap");
        ok(FloatingOpenModeLogic.PREF_TAP.equals("floating.open.tap"), "tap preference stable");
        ok(FloatingOpenModeLogic.PREF_SWIPE.equals("floating.open.swipe"), "swipe preference stable");
        System.out.println(n + " independent tap/swipe and two-second drag tests passed");
    }
}
